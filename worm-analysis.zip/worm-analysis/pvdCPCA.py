#!/usr/bin/env python

from __future__ import print_function

from estimateK import estimateK
from worm_parse import pvdparse, ptsFromVtu
from sys import argv
import os
import numpy as np
from numpy.linalg import norm
from math import sqrt
from sklearn.decomposition import PCA
from sklearn.utils import check_array
from xwToMs import xwToMs, xwToM
from msToXw import msToXw
from pvdSD import self_distance

import sys

DIMENSION=5
SD_THRESH=0

def eprint(*args, **kwargs):
	   print(*args, file=sys.stderr, **kwargs)

def printn(*args, **kwargs):
	sys.stdout.write(*args, **kwargs)


# obsolete. probably
def appendworms_complex(Ms, pvdfn, i, end):
	vtuindex = pvdparse(pvdfn)
	dir = os.path.dirname(pvdfn)
	x = iter(vtuindex)
	for ii in range(i):
		t=x.next()
	while(i<end):
		try:
			t = x.next()
		except StopIteration:
			break

		f=t.get('file')
		X,W,ign=ptsFromVtu(dir+'/'+f)

		s=self_distance(X)
		if s<SD_THRESH:
			eprint("too small self distance in frame " +str(i) +":", s)
		else:

			M, t = xwToM(X,W, complex=True)
			Ms.append(M)

		i+=1

if __name__=="__main__":
	pvdfn=argv[1]

	i = 0
	end = 99999
	if(len(argv)>2):
		i = int(argv[2])
	if(len(argv)>3):
		end=int(argv[3])

	Ms=[]

	appendworms_complex(Ms, pvdfn, i, end)
#	print (len(Ms[0]))
#	print(Ms[0][0:2])
#	sys.exit(0)


	print("# PCA from ", len(Ms))
	pca = PCA(n_components=DIMENSION)
	Ms = check_array(Ms, ensure_2d=True, copy=pca.copy)

	pca._fit_full(Ms, DIMENSION)

#	print(pca.explained_variance_ratio_)
#	print(pca.components_)

	for c in pca.components_:
#		print("# norm", norm(c))

		space=""
		for i in c:
			printn(space)
			printn(str(i.real))
			space=" "
		for i in c:
			printn(space)
			printn(str(i.imag))
		print("")

#	print()
#	print()
#	for c in pca.components_:
#		for d in pca.components_:
#			printn(str(np.dot(c,d))+" ")
#
#		print()
#
			
