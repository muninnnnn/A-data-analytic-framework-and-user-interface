import sys
import xml.etree.ElementTree

import parameters
parameters = parameters.parserDict( sys.argv )

basename = parameters['pvd_dir'] + '/'
badframes_fn = parameters['bad_frames_file']

mainPvd = xml.etree.ElementTree.parse( basename + 'skeletons_worm.pvd').getroot()[0].findall('DataSet')

trial_id = os.path.basename( os.path.normpath( basename ) )

# read list of bad frames
badframes = []
file = open( badframes_fn )
lines = file.readlines()

try:
    for line in lines:
        if trial_id in line:
            print line
            ff = line.split(':')[-1].split(',')
            if len(ff) == 0:
                break
            for fff in ff:
                if '-' in fff:
                    start,end = fff.split('-')
                    badframes = badframes + list( xrange( int(start), int(end)+1 ) )
                else:
                    badframes = badframes + [int(fff)]
except:
    pass

file.close()

myPvdStruct = [ [ step.get('timestep'),
                  step.get('file'),
                  step.get('group'),
                  step.get('part') ] for step in mainPvd ]

outfile = open( basename + 'skeltons_worm_goodframes.pvd', 'w' )
outfile.write('<?xml version="1.0"?>\n')
outfile.write('<VTKFile type="Collection" version="0.1" byte_order="LittleEndian">\n')
outfile.write('  <Collection>\n')

for i,step in enumerate(myPvdStruct):
    timestep, file, group, part = step

    outfile.write( '    ' )
    if i in badframes:
        outfile.write('<!-- ')
    outfile.write('<DataSet timestep=\"{}\" group=\"{}\" part=\"{}\" file=\"{}\"/>'.format( timestep, group, part, file ) )
    if i in badframes:
        outfile.write('-->')
    outfile.write('\n')

outfile.write('  </Collection>\n')
outfile.write('</VTKFile>\n')

outfile.close()
print 'output', basename + 'skeltons_worm_goodframes.pvd'
