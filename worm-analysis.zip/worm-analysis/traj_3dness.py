#!/usr/bin/env python
from sys import argv
from sys import stdout
from worm_parse import pvdparse
from error import printn, eprint
import numpy as np
from math import exp
from numpy.linalg import norm

from persistence_fit import fit_rescale
from sklearn.decomposition import PCA

import matplotlib as mpl
mpl.use('agg')

DIMENSION = 3
pca = PCA(n_components=DIMENSION)
steps = 100
do_plot = False

def get_3D(c):
	L = len(c)
	step=L//steps
	D = []
	D.append(np.zeros(DIMENSION))
	D.append(np.zeros(DIMENSION))
	for windowsize in range(DIMENSION, L, step):
		s = 0
		pcadata = []
		r = np.zeros(DIMENSION)
#		print("ws", windowsize)
		print(windowsize)
		howmany = L-windowsize
		for left_end in range(howmany):
			pcadata = c[left_end:left_end+windowsize]

			pcadata = np.array(pcadata)
			# "3dness"??
			pca.fit(pcadata, DIMENSION)
			r += pca.explained_variance_ratio_

		numbers=r/float(howmany)
		D.append(numbers)
		print(numbers)
	return D

from dataparse import datafile_by_index

def getC(fn):
	c = []
	if(fn[-3:]=="out"):
		data = datafile_by_index(fn, [1,"centroidx", "centroidy", "centroidz"])
		for i in data:
			a = np.array([i[1], i[2], i[3]])
			c.append(a)
	else:
		a = pvdparse(fn)
		for n,i in enumerate(a):
			w = i.get_worm()
			c.append(w.center_of_gravity())
	return c

def do_it(data, plt, clr):

	#fit = [ exp(w[1])*(i)**w[0] for i in range(M) ]
	#plt.plot(fit, 'r--', color=clr);

if __name__ == "__main__":
	i=1
	raw_out=False

	while(argv[i][0]=='-'):
		if(argv[i]=='-r'):
			raw_out = True
		if(argv[i]=='-o'):
			i+=1
			outfile = argv[i]
		i+=1


	D=[]
	mycolors=[ (0,0,1),  (1,0,0),  (0,1,0),  (1,1,0),   (0,1,1),   (1,0,1)] \
	        +[ (0,0,.5), (.5,0,0), (0,.5,0), (.5,.5,0), (0,.5,.5), (.5,0,.5)] \
			  +[ (0,0,0), (0,0,0)]
	myci=iter(mycolors)
	clr = next(myci)

	data = []

	if(do_plot):
		from matplotlib import pyplot as plt
		ax = plt.gca()
		ax.set_ylim([0,1.])
	else:
		ax = None

	for fn in argv[3:]:
		eprint("doing ", fn)
		c = getC(fn)
		d = get_3D(c)
		data.append(d)

#/	print("shape", data.shape)
	for chunk in data:
		chunk=np.transpose(chunk)
		for i in chunk:
			ax.plot(i, color=clr);
			clr = next(myci)

	if(raw_out):
		assert(len(data)==1)
		for i, x in enumerate(data0):
			print(i, x)


	if(do_plot):
		pass
	elif(outfile):
		plt.savefig( outfile )
	else:
		plt.show()
