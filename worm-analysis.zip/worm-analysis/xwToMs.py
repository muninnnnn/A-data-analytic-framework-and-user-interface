#!/usr/bin/env python
import numpy as np
from numpy.linalg import norm
from numpy import zeros
from sys import argv
import os
from math import atan2, sin, cos
from error import eprint

def convert_3d(x, y):
    return [ [x[0], y[0]],
               [x[1], y[1]],
               [x[2], y[2]] ]

def an_orthonormal(x):
    if(abs(x[0])<1e-20):
        return np.array([1.,0.,0.])
    if(abs(x[1])<1e-20):
        return np.array([0.,1.,0.])

    X=np.array([ x[1], -x[0], 0. ])
    return X/norm(X)

def decompose( M1, M2, W ):
    nPoints = len(W);
    m1 = np.zeros( nPoints )
    m2 = np.zeros( nPoints )
    for j in range(1, nPoints-1):
        m1[j] = np.dot(M1[j], W[j])
        m2[j] = np.dot(M2[j], W[j])
    return m1, m2

# rotate sth the peak curvature is in that plane.
from util import normalize_peakplane

def xwToMs( X, W ):
    nPoints = len(X)

    tau = [ (X[1] - X[0])/norm(X[1]-X[0]) ]
    M1 = [ an_orthonormal(tau[0]) ]
    M2 = [ np.cross( tau[0], M1[0] ) ]

    m10 = []
    m20 = []

    for j in range(nPoints-1):
        q = norm( X[j+1] - X[j] )
        tauNew = ( X[j+1] - X[j] ) / q

        t = np.arcsin( - np.dot( tauNew, M2[j] ) )
        p = np.arctan2( np.dot( tauNew, M1[j] ), np.dot( tauNew, tau[j] ) )

        M1new = M1[j] * np.cos(p) \
                - tau[j] * np.sin(p)

        M2new = M2[j] * np.cos(t) \
                + M1[j] * np.sin(p) * np.sin(t) \
                + tau[j] * np.cos(p)*np.sin(t)

        tau.append(tauNew)
        M1.append(M1new)
        M2.append(M2new)

        m1new = p/q
        m2new = -t/q

        m10.append( m1new )
        m20.append( m2new )

    m10.append(0)
    m20.append(0)

    m1,m2,theta = normalize_peakplane( m10, m20 )

    return m1, m2, theta

def cXwToMs( X, W ):
	M1, M2 = cFindFrame(X)
	m10, m20 = decompose(M1, M2, W)
	#print("DEBUG", M1, "\nDBG2", M2)
	m1, m2, theta = normalize_peakplane(m10, m20)
	#print("norm, " , theta)

#	a1=np.average(m1)
#	a2=np.average(m2)
#	print a1
#	print a2
#
#	for x in np.nditer(m1, op_flags=['readwrite']):
#		x[...]+=1
#	for x in np.nditer(m2, op_flags=['readwrite']):
#		x[...]+=1

	return m1, m2, theta

def xwToM(X, W, cplx=False):
    m1, m2, t=xwToMs(X, W)
    if(cplx):
        m = m1 + 1j*m2
        return m, t
    M = np.concatenate(( m1, m2) )
    return M, t

def findFrame( X ):
    nPoints = len(X)
    tau = []
    M1 = []
    M2 = []
    for j in range(nPoints-1):
        tauJtilde = X[j+1] - X[j]
        tau.append( tauJtilde / norm( tauJtilde ) )

        if( j == 0 ):
            M1tilde = an_orthonormal(tau[0])
            M1.append(M1tilde)
        else:

            # BUG: call nextFrame
            M1tilde = M1[-1] - np.dot(tau[-1], M1[-1]) * tau[-1]
            M1.append(M1tilde / norm(M1tilde));

        # print "t", tau[-1]
        # print "M", M1[-1]
        M2.append(np.cross(tau[-1], M1[-1]))

    return tau, M1, M2

# create curvature from X, starting from center
def cFindFrame( X ):
    nPoints = len(X)
    dims = (nPoints, 3)
    tau = [0] * (nPoints -1)
    M1 = [0] * (nPoints -1)
    M2 = [0] * (nPoints -1)

    tauJtilde = X[64] - X[63]
    tau[63] = tauJtilde / norm( tauJtilde )

    M1tilde = an_orthonormal(tau[63])
    M1[63] = M1tilde
    M2[63] = np.cross(tau[63], M1[63])
    for j in range(63, nPoints-1, 1):
#        tauJtilde = X[j+1] - X[j]
#        tau[j] = tauJtilde / norm( tauJtilde )

        if (j == 63):
    #        M1tilde = an_orthonormal(tau[63])
    #        M1[63] = M1tilde
    #        M2[63] = np.cross(tau[63], M1[63])
            pass
        else:
            # BUG: call nextFrame
            M1[j], M2[j] = nextFrame(M1[j-1], M2[j-1], X[j+1]-X[j])

            #M1tilde = M1[j-1] - np.dot(tau[j-1], M1[j-1]) * tau[j-1]
            #M1[j] = M1tilde / norm(M1tilde)
        #M2[j] = np.cross(tau[j-1], M1[j-1])

        # print "t", tau[-1]
        # print "M", M1[-1]

    # 62 to 0
    for j in range(int(nPoints/2)-2, -1, -1):
        M1[j], M2[j] = nextFrame(M1[j+1], M2[j+1], X[j+1]-X[j])
    return M1, M2

# M1 M2 the normals at current point.
# tauJtilde, the tangent at the next point.
def nextFrame(M1, M2, tauJtilde):
    # nPoints = len(X)

    tau = tauJtilde / norm( tauJtilde )

#		if( j == 0 ):
#			M1tilde = an_orthonormal(tau[0])
#			M1.append(M1tilde)
    M1tilde = M1 - np.dot(tau, M1) * tau
    M1new = (M1tilde / norm(M1tilde));
    M2new = np.cross(tau, M1new)

    #print np.dot(M1new, tau)
    #print np.dot(M2new, tau)

    return M1new, M2new

if __name__=="__main__":
	pvdfn=argv[1]

	from worm_parse import pvdparse, ptsFromVtu
	#	eprint("pvd", pvdfn)
	#	vtuindex = pvdparse(pvdfn)
	#	dir=os.path.dirname(pvdfn)
	#
	#	eprint("hmmm")
	#
	#	x = iter(vtuindex)
	#	t = next(x)
#	from worm_parse import pvdparse, ptsFromVtu
#	vtuindex=pvdparse(pvdfn)
#	dir=os.path.dirname(pvdfn)
#
#	x=iter(vtuindex)
#	t=x.next()
#
#	if(len(argv)>2):
#	    fn=int(argv[2])
#	    print("#frame" , fn)
#	    for i in range(int(argv[2])):
#	        t = x.next()

	f=argv[1]

	X,W,ign = ptsFromVtu(f)

	m1, m2, nu = xwToMs(X, W)
#	for i in range(len(m1)):
#	    print(i, m1[i], m2[i])

	# pLot with frames

	from matplotlib import pyplot as plt
	from matplotlib import gridspec
	from mpl_toolkits.mplot3d import Axes3D

	fig = plt.figure(facecolor='white')
	gs = gridspec.GridSpec(3, 4)
	ax0 = fig.add_subplot(gs[0:3,0:3], projection='3d')

	for j in range(len(X)-1):
	    ax0.plot( *convert_3d( X[j], X[j+1]),
	                    color = 'green' , linewidth=3)

#leaveplane
# 	ax0.view_init(elev=50., azim=-10)
	# plt.xticks([])

	# plt.yticks()

#leaveplane
# 	ax0.view_init(elev=50., azim=-10)
	# plt.xticks([])
	ax0.set_xticklabels([])
	ax0.set_yticklabels([])
	ax0.set_zticklabels([])
	# plt.yticks()
	tau = X[1] - X[0]
	tau = tau / norm( tau )

	M1 = an_orthonormal(tau)
#	M1 = np.array([1.,2.,2.])
	M1 = M1 - np.dot(tau, M1) * tau
	M1 = M1 / norm(M1)
	M2 = np.cross(tau, M1)

	from util import XtoW
	W = XtoW(X)
	s = 0.01
	for i in range(1, len(X)-2):
		tau = X[i+1] - X[i]
		M1, M2 = nextFrame(M1, M2, tau)

		if(not i % 5):
			ax0.plot( *convert_3d(X[i], X[i] + s*np.dot(M1, W[i])*M1),
							color = 'blue' , linewidth=3)
			ax0.plot( *convert_3d(X[i], X[i] + s*np.dot(M2, W[i])*M2),
							color = 'red' , linewidth=3)
			ax0.plot( *convert_3d(X[i], X[i] + W[i]*s),
							color = 'grey' , linewidth=3)

	plt.show()
	fig.savefig("m1m2.pdf")


# this is zero...
def total_twist(X, W):
	W1 = W[0]
	X1 = X[0]

	t = 0
	for x,w in zip(X[1:], W[1:]):
		#eprInt("w", w)
		n = np.cross(W1, X1-x)

		t += np.dot(n, w)

		W1 = w
		X1 = x
	return t

def garbage():
	tau = X[1]-X[0]
	tau = tau / norm( tau )

	M1 = an_orthonormal(tau)
#	M1 = np.array([1.,2.,2.])
	M1 = M1 - np.dot(tau, M1) * tau
	M1 = M1 / norm(M1)
	M2 = np.cross(tau, M1)
	t = 0
	import cmath
	for i in range(1, len(X)-2):
		tau = X[i+1] - X[i]
		M1, M2 = nextFrame(M1, M2, tau)

	return t


def more_garbage():
    M1 = M1 - np.dot(tau, M1) * tau
    M1 = M1 / norm(M1)
    M2 = np.cross(tau, M1)
    for i in range(1, len(X)-2):
        tau = X[i+1] - X[i]
        M1, M2 = nextFrame(M1, M2, tau)

        if(not i % 5):
            ax0.plot( *convert_3d(X[i], X[i] + .01*np.dot(M1, W[i])*M1),
                            color = 'blue' , linewidth=3)
            ax0.plot( *convert_3d(X[i], X[i] + .01*np.dot(M2, W[i])*M2),
                            color = 'red' , linewidth=3)
            ax0.plot( *convert_3d(X[i], X[i] + W[i]*.01),
                            color = 'grey' , linewidth=3)

    print(nu)
    plt.show()
    fig.savefig("m1m2.pdf")


###  doesntwork_vim:ts=8:sw=2:et:?!?!
