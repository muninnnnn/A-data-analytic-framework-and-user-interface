from matplotlib import pyplot as plt
from matplotlib import _cntr as cntr
import colormaps
plt.close('all')

import numpy as np
import sys
import os

import scipy as sp
import scipy.interpolate
from scipy.ndimage import filters

import parameters
parameters = parameters.parserDict( sys.argv )

basename = parameters['pvd_dir'] + '/'
outdir = parameters['output_dir'] + '/'
start_frame = int(parameters['start_frame'])
end_frame = int(parameters['end_frame'])

testContours=False

if not os.path.exists(outdir):
    os.makedirs(outdir)
trial_id = os.path.basename( os.path.normpath( basename ) )

import worm_parse
mainPvd = worm_parse.pvdparse( basename + 'skeletons_worm.pvd')
if start_frame < 0:
    start_frame = 0
if end_frame < 0 or end_frame >= len(mainPvd):
    end_frame = len(mainPvd)
timeStepRange = [ _  for _ in xrange( start_frame, end_frame ) ]
timeSteps = end_frame - start_frame

print 'read pvd file:', basename + 'skeletons_worm.pvd'

def norm( v ):
    s = sum( [_*_ for _ in v] )
    return np.sqrt(s)

# do plotting here
nPts = 128
nTimes = len(mainPvd)
p = np.zeros( (nPts, nTimes) )
pk = np.zeros( (nPts, nTimes, 2) )
wMaxMin = [False,False]

print 'computing curvature'
#for i in range(nTimes):
for i in timeStepRange:
    if i % timeSteps == 0:
        print i,'/',nTimes

    try:
        time = float(mainPvd[i].get('timestep'))
        fn = basename + mainPvd[i].get('file')
        pts,W,U = worm_parse.ptsFromVtu( fn )
    except:
        print i, 'not in range'
        continue

    wMags = []

    for j,w in enumerate(W):
        wMag = np.sqrt( w[0]*w[0] + w[1]*w[1] + w[2]*w[2] )
        p[ j, i ] = wMag
        wMags.append( wMag )
    wMags.sort()

    m = wMags[9*len(wMags)/10]
    if wMaxMin[0]:
        wMaxMin[0] = max( wMaxMin[0], m )
    else:
        wMaxMin[0] = m

print 'decomposing curvature'
#for i in range(nTimes):
E1 = [ 1,0,0 ]
for i in timeStepRange:
    if i % timeSteps == 0:
        print i,'/',nTimes

    time = mainPvd[i].get('timestep')
    fn = basename + mainPvd[i].get('file')
    pts,W,U = worm_parse.ptsFromVtu( fn )

    T, M1, M2 = [], [], []
    K1, K2 = [], []
    for j in range(len(pts)-1):
        t = pts[j+1] - pts[j]
        t = t / norm(t)
        T.append(t)

        if j == 0:
            n1 = np.cross( t, np.cross( E1, t ) )
            m = n1 / norm(n1)
            m2 = np.cross( t, m )

            M1.append( m )
            M2.append( m2 )

            k1 = np.dot( W[0], m )
            k2 = np.dot( W[0], m2 )
            K1.append( k1 )
            K2.append( k2 )
            theta = np.arctan2( k2, k1 )

            pk[ j, i ] = ( k1, k2 )

            E1 = m

        m = np.cross( t, np.cross( m, t ) )
        m = m / norm(m)
        m2 = np.cross( t, m )

        M1.append(m)
        M2.append(m2)

        k1 = np.dot( W[j+1], m )
        k2 = np.dot( W[j+1], m2 )
        K1.append( k1 )
        K2.append( k2 )
        theta = np.arctan2( k2, k1 )

    # jStar = np.argmax( [ k1**2 + k2**2 for k1,k2 in zip(K1,K2)] )
    # thetaStar = np.arctan2( -K2[jStar], K1[jStar] )

    # for j in range(len(pts)-1):
    #     k1 = np.cos(thetaStar) * K1[j] - np.sin(thetaStar) * K2[j]
    #     k2 = np.sin(thetaStar) * K1[j] + np.cos(thetaStar) * K2[j]
    #     K1[j] = k1
    #     K2[j] = k2

        pk[ j, i ] = ( k1, k2 )

nPlts = timeSteps / min( 500, timeSteps ) + 1

print 'saving curvature-time heat maps'
if 1:
    fig = plt.figure(1)
    # 307.28987 pt
    fig_width = 307.28987 / 72.0
    fig_height = fig_width / 2.0
    f, axarr = plt.subplots( nPlts )

    if nPlts == 1: axarr = [axarr]

    fullRange = timeSteps
    myExtent = [ start_frame/25.0, end_frame/25.0, 0, 1 ]

    for pp in range(nPlts):
        myRange = timeStepRange[ (fullRange-1) * pp / ( nPlts + 1 ) :
                                 (fullRange-1) * (pp+1) / ( nPlts + 1 ) ]
        try:
            myExtent = [ min( myRange ) / 25.0, max( myRange ) / 25.0, 0, 1 ]
        except:
            print fullRange, pp, nPlts
            print timeStepRange[0], timeStepRange[-1]
            print myRange
            exit(1)

        cax = axarr[pp].imshow( p[:, myRange ],
                                interpolation='bilinear',
                                extent=myExtent, cmap=colormaps.viridis, aspect='auto',
                                vmin=0, vmax=wMaxMin[0] )
        axarr[pp].set_ylabel('Body coordinate')
    axarr[pp].set_xlabel('Time (s)')

    plt.colorbar(cax)
    plt.suptitle( '{} : Range {}-{} '.format(trial_id, 0, wMaxMin[0]) )
    plt.savefig('{0}/curvature.pdf'.format(outdir))

    fig = plt.figure(3)
    f, axarr = plt.subplots( nPlts )
    if nPlts == 1: axarr = [axarr]

    for pp in range(nPlts):
        myRange = timeStepRange[ (fullRange-1) * pp / ( nPlts + 1 ) :
                                 (fullRange-1) * (pp+1) / ( nPlts + 1 ) ]
        myExtent = [ min( [ m for m in myRange ] ) / 25.0, max( [ m for m in myRange] ) / 25.0, 0, 1 ]

        cax = axarr[pp].imshow( pk[:, myRange, 0 ],
                          interpolation='bilinear',
                          extent=myExtent, cmap='bwr', aspect='auto',
                          vmin=-wMaxMin[0], vmax=wMaxMin[0] )
        axarr[pp].set_ylabel('Body coordinate')
    axarr[pp].set_xlabel('Time (s)')


    plt.suptitle( trial_id )
    plt.savefig('{0}/curvature_m1.pdf'.format(outdir))

    fig = plt.figure(3)
    f, axarr = plt.subplots( nPlts )
    if nPlts == 1: axarr = [axarr]

    for pp in range(nPlts):
        myRange = timeStepRange[ (fullRange-1) * pp / ( nPlts + 1 ) :
                                 (fullRange-1) * (pp+1) / ( nPlts + 1 ) ]
        myExtent = [ min( [ m for m in myRange ] ) / 25.0, max( [ m for m in myRange] ) / 25.0, 0, 1 ]

        axarr[pp].imshow( pk[:, myRange, 1 ],
                          interpolation='bilinear',
                          extent=myExtent, cmap='bwr', aspect='auto',
                          vmin=-wMaxMin[0], vmax=wMaxMin[0] )
        axarr[pp].set_ylabel('Body coordinate')
        axarr[pp].set_xlabel('Time (s)')

    plt.suptitle( trial_id )
    plt.savefig('{0}/curvature_m2.pdf'.format(outdir))

if testContours:
    def findContours( mat, value=0.0 ):
        _x, _y = np.mgrid[:mat.shape[0], :mat.shape[1]]
        c = cntr.Cntr(_y, _x, mat)
        cs = c.trace( value )
        return cs[:len(cs)/2]

    m1CurvatureMat = pk[20:128-20, timeStepRange, 0 ]
    m2CurvatureMat = pk[20:128-20, timeStepRange, 1 ]
    curvatureMat = p[20:128-20, timeStepRange]

    fig = plt.figure(0)
    plt.clf()

    plt.imshow( m2CurvatureMat,
                interpolation='bilinear', cmap='PiYG', aspect='auto',
                vmin=-wMaxMin[0], vmax=wMaxMin[0] )

    # plt.contour( m1CurvatureMat, [0.0], colors='r' )
    # cs = plt.contour( m2CurvatureMat, [0.0], colors='b' )

    def fit(contour):
        P = np.polyfit( [ x for x,y in contour ], [ y for x,y in contour ], 1 )
        return -P[1]/P[0]

    def contourDist(a,b):
        Pa = np.polyfit( [ x for x,y in a ], [ y for x,y in a ], 1 )
        Pb = np.polyfit( [ x for x,y in b ], [ y for x,y in b ], 1 )

        p0a = [ -Pa[1] / Pa[0], 0 ]
        p0b = [ -Pb[1] / Pb[0], 0 ]
        p1a = [ ( 128-40 -Pa[1]) / Pa[0], 128-40 ]
        p1b = [ ( 128-40 -Pb[1]) / Pb[0], 128-40 ]
        xDist = (( p0a[0] - p0b[0] ) + ( p1a[0] - p1b[0] ) )/ 2.0

        midx = (( p0a[0] + p0b[0] ) + ( p1a[0] + p1b[0] ) ) / 4.0
        yDist = (Pa[0] - Pb[0] )*midx + (Pa[1] - Pb[1])

        return (xDist/25.0,yDist/128.0)

    print '# fitting to zeros of m1(red), m2(blue), |kappa| (black)'
    # for mat,c in zip([ m1CurvatureMat, m2CurvatureMat, curvatureMat ],'rbk'):
    for mat,c in zip([ m2CurvatureMat ],'b'):
        mm = np.mean(mat)
        ans = findContours( mat )
        ans.sort( key=fit )

        contours = []
        print '** Polyfit fits **'
        for j,contour in enumerate(ans):
            if len(contour) < 20:
                continue
            plt.figure(1)
            plt.clf()
            plt.imshow( m2CurvatureMat,
                        interpolation='bilinear', cmap='PiYG', aspect='auto',
                        vmin=-wMaxMin[0], vmax=wMaxMin[0] )

            for cc in contours:
                P = np.polyfit( [ x for x,y in cc ], [ y for x,y in cc ], 1 )
                p0 = [ -P[1] / P[0], 0 ]
                p1 = [ (  128-40 - P[1] ) / P[0],  128-40 ]
                plt.plot( [ p0[0], p1[0] ], [p0[1], p1[1] ], '{}'.format(c), alpha=0.25 )
            P = np.polyfit( [ x for x,y in contour ], [ y for x,y in contour ], 1 )
            p0 = [ -P[1] / P[0], 0 ]
            p1 = [ (  128-40 - P[1] ) / P[0],  128-40 ]
            plt.plot( [ x for x,y in contour ], [ y for x,y in contour ], 'k--' )
            plt.plot( [ p0[0], p1[0] ], [p0[1], p1[1] ], '{}'.format(c) )
            plt.axis([max(0,min(p0[0],p1[0])-25),min(timeStepRange[-1]-timeStepRange[0],max(p0[0],p1[0])+25),0,128-40])
            plt.title('{0}, {1} x + {2}'.format( len(contour), P[0], P[1] ))
            plt.savefig('tmp.pdf')

            q = raw_input()
            try:
                if int(q) == 1:
                    contours.append(contour)
                    plt.figure(0)
                    plt.plot( [ p0[0], p1[0] ], [p0[1], p1[1] ], '{}'.format(c) )
                    print len(contour), ',', P
                if int(q) < 0:
                    break
            except:
                pass
        print '** end **'

        print '** Undulation parameter estimates ** (time sec,dist mm)'
        for j in range(len(contours)-1):
            print j,contourDist( contours[j], contours[j+1] )
        print '** end **'

    plt.figure(0)
    plt.axis([0,timeStepRange[-1]-timeStepRange[0],0,128-40])
    plt.axes().set_aspect('equal', 'datalim')
    plt.title( trial_id )
    plt.savefig('{0}/m1m2-contour.pdf'.format(outdir))

# planarity

plt.figure(40)
areas = []
for i in range(nTimes):
    K1 = [ k1 for k1, k2 in pk[ :, i ] ]
    K2 = [ k2 for k1, k2 in pk[ :, i ] ]

    area = 0.0
    for j in range(len(K1)-1):
        f1 = ( K1[j] + K1[j+1] ) / 2.0
        f2 = ( K2[j] + K2[j+1] ) / 2.0
        nutilde = [ -K2[j+1] + K2[j], K1[j+1] - K1[j] ]
        area = area + 0.5 * ( f1 * nutilde[0] + f2 * nutilde[1] )
    areas.append( abs(area) )

plt.plot( np.linspace( 0, len(areas)/25.0, len(areas) ), areas )
plt.savefig('{0}/curvature-area.png'.format(outdir))
