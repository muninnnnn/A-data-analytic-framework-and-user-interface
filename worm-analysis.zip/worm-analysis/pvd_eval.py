#!/usr/bin/env python

from estimateK import estimateK
from worm_parse import pvdparse, ptsFromVtu
from sys import argv
import os
from pvdTD import total_displacement
from util import tail

import sys

pvdfn=argv[1]

vtuindex=pvdparse(pvdfn)
dir=os.path.dirname(pvdfn)
name=os.path.basename(pvdfn)

x=iter(vtuindex)
t=x.next()
f=t.get('file')


w0=ptsFromVtu(dir+'/'+f)[0]
i=j=0
sum_K=0.
sum_TK=0.
T=0.
en=0.

print "#number td, avgk, kq, energy"

while(True):
	w1=w0
	try:
		t=x.next()
	except StopIteration:
		break

	f=t.get('file')
	w0=ptsFromVtu(dir+'/'+f)[0]

	td=total_displacement(w0, w1)
	T+=td

	efn='energy_frame_'+str(i)+'.txt'
	en=0

	try:
		ef=open(dir+'/'+efn, 'r')
		el=tail(ef,1)[0]
		es=el.split(",")
		for ii in (1,2,3,4,5):
			en+=float(es[ii])
	except IOError:
		en=1e99
	
	K=TK=0
	kq=0

# K, TK, coll
	est=[0, 0, 0]

	if(td<1 or td>20):
#		print "SKIP", td
		pass
	else:
#		print "call est"
		est=estimateK(w0, w1)
		kq=abs(est[-1])
		if( kq  > .5 ):
			K=est[0]
			TK=est[1]
			j+=1
			sum_K+=K
			sum_TK+=abs(TK)

	print i, td, K, TK, kq, en
	i+=1;

print "# ", name
print "# number frames ", i
print "# avg TD ", T/i
print "# number considered ", j
print "# subset_average K: ", sum_K/j
print "# subset_average TK: ", sum_TK/j
