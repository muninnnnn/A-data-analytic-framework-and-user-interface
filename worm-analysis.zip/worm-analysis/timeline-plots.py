import glob
from matplotlib import cm
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import os
import parameters
import sys

def parseFn( full_fn ):
    fn = os.path.basename( full_fn )
    data = fn.split('_')
    strain = data[0]
    media = float(data[1]+data[2][:2])/100.0
    date = data[3]
    trial = data[4]
    datatype = data[5]

    trialId = strain + '_' + '{}pc'.format(media).replace('.','_') + '_' + date + '_' + trial

    return strain, media, date, trial, datatype, trialId

def readPostureFile( fn ):
    file = open(fn,'r')
    frames, times, planeFits, lineFits, totalCurvatures = [], [], [], [], []

    for line in file.readlines():
        if '#' == line[0]:
            continue
        else:
            data = line.split(',')
            myFrame = int(float(data[0]))
            frames.append(myFrame)
            myTime = float(data[1])
            times.append(myTime)
            myPlaneFit = float(data[2])
            planeFits.append(myPlaneFit)
            myLineFit = float(data[3])
            lineFits.append(myLineFit)
            myTotalCurvature = float(data[4])
            totalCurvatures.append(myTotalCurvature)

    file.close()

    return frames, times, planeFits, lineFits, totalCurvatures

def readTrajectoryFile( fn ):
    data = np.loadtxt(fn, delimiter=',')

    frame_number = data.T[0]
    time = data.T[1]
    x = data.T[2]
    y = data.T[3]
    z = data.T[4]
    speed = data.T[5]
    distance = data.T[6]
    cumulative_distance = data.T[7]
    turn_rate = data.T[8]
    turn_radii = data.T[9]
    return frame_number,time,x,y,z,speed,distance,cumulative_distance,turn_rate,turn_radii

def readPersistFile( fn ):
    data = np.loadtxt( fn, delimiter=',' )

    frame_number = data.T[0]
    time = data.T[1]
    dists = {}
    for j,n in enumerate( [1,2,4,8,16,32,64] ):
        dists[ n ] = data.T[j+2]

    ang = {}
    for j,n in enumerate( [1,2,4,8,16,32,64] ):
        ang[ n ] = data.T[9+3*j:9+3*(j+1)]

    return time, frame_number, dists, ang

def mySplitPlot( xx, yy, **kwargs ):
    N = len(xx)
    nPlots = N / min(250,N)

    for pp in range(nPlots):
        plt.subplot( nPlots, 1, pp+1 )
        plt.plot( xx[ (pp*N) / (nPlots+1) :  ((pp+1)*N) / (nPlots+1) ],
                        yy[ (pp*N) / (nPlots+1) :  ((pp+1)*N) / (nPlots+1) ],
                  **kwargs )

def plotSphere( ax ):
    # Create a sphere
    r = 1
    pi = np.pi
    cos = np.cos
    sin = np.sin
    phi, theta = np.mgrid[0.0:pi:100j, 0.0:2.0*pi:100j]
    x = r*sin(phi)*cos(theta)
    y = r*sin(phi)*sin(theta)
    z = r*cos(phi)

    ax.plot_surface( x, y, z,  rstride=1, cstride=1, color='w', alpha=0.9, linewidth=0)

def cart2sph(x,y,z):
    XsqPlusYsq = x**2 + y**2
    r = np.sqrt(XsqPlusYsq + z**2)               # r
    elev = np.arctan2(z,np.sqrt(XsqPlusYsq))     # theta
    az = np.arctan2(y,x)                           # phi
    return r, elev, az

if 1 or __name__ == "__main__":
    parameters = parameters.parserDict( sys.argv )

    #basedir = parameters['base_dir']
    basedir = '/home/csunix/scstr/biosys2/3D_Data/analysis/223137/'
    #outdir = parameters['output_dir']
    outdir = 'tmp'

    for file in sorted( glob.glob( basedir + '*.csv')):
        strain, media, date, trial, datatype, trialId = parseFn( file )

        if datatype == 'traj':

            frame_number,times,x,y,z,speed,distance,cumulative_distance,turn_rate,turn_radii = readTrajectoryFile( file )
            for data, title in zip( [ speed, distance,cumulative_distance,turn_rate,turn_radii ],
                                    [ 'speed', 'distance','cumulative_distance','turn_rate','turn_radii' ]):
                fig = plt.figure(0)
                plt.clf()
                mySplitPlot( times, data )
                plt.suptitle( trialId + ':' + title )

                plt.savefig( os.path.join( outdir, trialId + '_' + title + '.pdf' ) )
                print 'saving',os.path.join( outdir, trialId + '_' + title + '.pdf' )
                break

            fig = plt.figure(0)
            plt.clf()
            ax = fig.gca(projection='3d')
            nPlots = len(times) / min(500,len(times)) + 1
            for j,t in enumerate( times ):
                if j == 0:
                    continue
                c = t / times[ len(times) / nPlots ]
                while c > 1: c = c - 1
                ax.plot( [ x[j-1], x[j] ], [y[j-1], y[j]], [z[j-1],z[j]], color=cm.hsv( c ) )
            plt.title( trialId + ':' + 'trajectory' )
            plt.savefig( os.path.join( outdir, trialId + '_' + 'trajectory.pdf' ) )
            print 'saving',os.path.join( outdir, trialId + '_' + 'trajectory' + '.pdf' )

        if datatype == 'global':
            pass

        if datatype == 'persist':
            time, frame_number, dists, ang = readPersistFile( file )

            plt.figure(0)
            plt.clf()
            for k, val in sorted(dists.iteritems()):
                mySplitPlot( time, val, label='{}'.format(k) )
            plt.legend()
            plt.title( trialId + ':' + 'persistence' )
            plt.savefig( os.path.join( outdir, trialId + '_' + 'persist.pdf' ) )
            print 'saving',os.path.join( outdir, trialId + '_' + 'persist' + '.pdf' )

            fig = plt.figure(0)
            plt.clf()
            ax = fig.gca(projection='3d')
            plotSphere( ax )
            for k, val in sorted(ang.iteritems()):
                ax.plot( val[0,:], val[1,:], val[2,:], label='{}'.format(k) )
                if not np.isnan(val[0,:]).all():
                    m = [ -np.nanmean( val[0,:] ), -np.nanmean( val[1,:] ), -np.nanmean( val[2,:] ) ]

            r,ev,az = cart2sph( m[0], m[1], m[2] )
            ax.view_init(elev=ev, azim=az)
            plt.title( trialId + ':' + 'persistence angle' )
            plt.legend()
            plt.savefig( os.path.join( outdir, trialId + '_' + 'persist_ang.pdf' ) )
            print 'saving',os.path.join( outdir, trialId + '_' + 'persist_ang' + '.pdf' )

        if datatype == 'posture':
            frames, times, planeFits, lineFits, totalCurvatures = readPostureFile( file )
            for data,title in zip( [planeFits, lineFits, totalCurvatures ],
                                   ['Plane_fit', 'Line_fit', 'Total_curvature']):
                fig = plt.figure(0)
                plt.clf()
                mySplitPlot( times, data )
                plt.suptitle( trialId + ':' + title )

                plt.savefig( os.path.join( outdir, trialId + '_' + title + '.pdf' ) )
                print 'saving',os.path.join( outdir, trialId + '_' + title + '.pdf' )
