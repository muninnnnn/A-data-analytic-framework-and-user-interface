#!/usr/bin/env python

# Creates a vtu file from a parametric curve
# vtu has 128 equidistant points with total length 1
#
# Usage: python syntheticWormCreator.py
#
#
# Author: Patrick Fox
# 1/8/17
#

from __future__ import print_function
from vtu import print_vtu
import numpy as np
from math import cos, sin

if __name__=="__main__":
	X=[]

	for i in range(128):
		x = float(i)
		X.append([x/280, cos(x/11)/13., sin(x/11)/13.])

	X=np.array(X)
	print_vtu(X)
