#!/usr/bin/env python3

from __future__ import print_function

from sys import argv, exit
import cmath
import sys

import matplotlib as mpl
mpl.use('agg')

try:
        import scipy.ndimage.interpolation as ndii
except ImportError:
        import ndimage.interpolation as ndii

from taulambda import lowpass, taulambda

from matplotlib import pyplot as plt
from matplotlib import gridspec
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import numpy
import math
from numpy import arange
from matplotlib.backend_bases import NavigationToolbar2, Event
from matplotlib.ticker import MaxNLocator

import xml.etree.ElementTree
from worm_parse import gait as gait_

from gait import row_is, row_has

import os

import parameters
# parameters = parameters.parser( sys.argv )

from frame_tags import frame_tags
from frame_tags import tagindicator
from error import eprint
from worm_collect import worm_collect

basename = '.'
outdir = '.'
fs = 25.
nPts = 128 # BUG, should be automatic
numrows=80
segment_length = 15

def plot_freq_ann(cur_ax, tend, basef, baselam):

    if( not basef):
        return
    L = int( tend * basef)
    #eprint("freqann L", L, "tend", tend, "basef", basef)
    col='#00ff00'
#    cur_ax.scatter( [0], [ .5 ] , color=col, marker='.', s=2)
#    if(L):
#        cur_ax.scatter( np.arange(L)/L*tend, [.5]*L, color=col,
#                        marker='.', s=3)

    direction=np.array ([ 1. , -basef*baselam ])
    direction/=np.linalg.norm(direction) * 4.

    for i in np.arange(L+1)/float(L)*tend:
#        print("center", i)
        center = np.array([i,.5])
        low = center-direction
        hi = center+direction

        cur_ax.plot( [low[0], hi[0]] , [low[1], hi[1]], color='#00ff00')


from util import find_angle



def datadump(d, fn):
    f=open(fn,"w")
    f.write("#. "+str(len(d)) + "\n")

    for i,x in enumerate(d):
        f.write(str(i) + " " + str(x) + "\n")

    f.close()


class posture_indicator:
        def __init__(self, ft):
                self.ft_ = ft
        
        def __call__(self, number):
                tt = self.ft_.get_tag(number)
                if(not gait_(tt)):
                    return False
                elif(gait_stuff):
                    if row_has(tt, gait_stuff):
                        return self.ft_.get_tag(number)
                    return False

                elif(gait_mask):
                    if row_is(tt, gait_mask):
                        return self.ft_.get_tag(number)
                    return False

                else:
                    return self.ft_.get_tag(number)
                    # print("nogait")
                # return gait_(tt)


plt.close('all')

def gaitcolor(worm):
    if( worm.is_planar()):
        gaitColor = (0,1,0)
    elif( worm.is_helix()):
        gaitColor = (1,0,0)
    else:
        gaitColor = (0,0,0)
    return gaitColor

def dircolor(d):
    if( d == WORM_FWD ):
        dirColor = (1,0,0)
    elif( d == WORM_BACK ):
        dirColor = (0,1,0)
    elif( d == WORM_STILL ):
        dirColor = (0,0,1)
    else:
        dirColor = (0,0,0)
    return dirColor

def unwrap(m, window):
    if(type(window)!=int):
        eprint("unwrap error", window)
        window=int(window)

    if(not len(m)):
        return
    sign=1.
    thresh=3.
    z=np.zeros(len(m))
    z[0] = 1.
    for j,i in enumerate(m):
        if j==0:
            continue
        switch = ( 1 - 2 * np.all( i<= m[j-window:j+window]))
        z[j]= switch * z[j-1]

    m*=z
# maybe later
def dunno():
    if 0: # whats this?
        plt.figure(10)
        plt.clf()
        ax = plt.subplot(111, projection='polar')

        for j in range( len( K1 ) - 1 ):
            K1_ = [ K1[j], K1[j+1] ]
            K2_ = [ K2[j], K2[j+1] ]
            u = U[j]

            theta = np.arctan2( K2[j], K1[j] )
            color= myanglemap( K1[j], K2[j] )

            # headTail(u)

            plt.plot( [ np.arctan2( k2, k1 ) for k1, k2 in zip(K1_, K2_) ],
                      [ np.sqrt( k1**2 + k2**2 ) for k1, k2 in zip(K1_, K2_) ],
                      '.-', color=color )

        ax.set_ylim( 0, wMaxMin[0] )
        ax.set_title('Time: {0}'.format(time) )
        plt.savefig( '{1}/k1k2_{0:06d}.pdf'.format(i, outdir) )

        fig = plt.figure(11)
        plt.clf()
        ax = fig.gca(projection='3d')
        for u, k1, k2 in zip( U, K1, K2 ):
            theta = np.arctan2( k2, k1 )
            color=anglemap( 0.5 + 0.5 * theta / np.pi )
            ax.plot( [u,u], [0,k1], [0,k2], color=color )
        ax.plot( U, np.zeros( len(U) ), np.zeros( len(U) ), 'r' )
        ax.plot( U, K1, K2, 'g' )
        ax.set_xlim3d( 0, 1 )
        ax.set_ylim3d( -wMaxMin[0], wMaxMin[0] )
        ax.set_zlim3d( -wMaxMin[0], wMaxMin[0] )
        ax.set_title('Time: {0}'.format(time) )

        plt.savefig( '{1}/uk1k2_{0:06d}.pdf'.format(i,outdir) )

fig_width = 307.28987 / 72.0
fig_height = fig_width / 2.0

from matplotlib.backends.backend_pdf import PdfPages

pp = 0
plots_per_page = 3
pagenumber = 0
f, axarr = plt.subplots( plots_per_page )
fig = plt.figure(1)

from scipy.ndimage import correlate
import imageio

def rgb2gray(rgb):
    return np.dot(rgb[...,:3], [0.299/256., 0.587/256., 0.114/256.])

from scipy.fftpack import fftn, ifftn
from numpy import fft

def phase_correlation(a, b):
    G_a = np.fft.fft2(a)
    G_b = np.fft.fft2(b)
    conj_b = np.ma.conjugate(G_b)
    R = G_a*conj_b
    R /= np.absolute(R)
    r = np.fft.ifft2(R).real
    return r

import scipy.signal as ss

def guess_base_frequency(fftdata, number=0):

   rows, cols=fftdata.shape
   # print(fftdata.shape, rows, cols)

   fftdata = fftdata[:rows//2,:cols//2]
   fftabs = np.abs(fftdata)


   rowsum = np.sum(fftabs, axis=0)
   rowsum[0]=0.
   # eprint("rss", rowsum.shape)
   # datadump(rowsum, "fft"+str(number)+".out")

   arg = np.argmax(rowsum)
   #eprint("gbf", fftdata.shape, "arg", arg)

   if(arg>5):
       d=arg*2
       upw=np.sum(rowsum[d-1:d+2])
       dwn=rowsum[arg//2]*3.

       # if(upw>dwn):
       #  print("higher peak right", d)
       #  arg=d




   numberofseconds = cols/fs
   fmin = 1./numberofseconds
   peakf = arg * fmin
#   eprint("gbf", fftdata.shape, "arg", arg,"peak", peakf)

   return peakf, arg


def corrstuff(data, targetf=0, number=0):
    L = nPts//4
    #print("NPTS", nPts, data.shape)
    # lambdascale = float(nPts)/numrows ## BUG
    tdata = np.copy(data[nPts//2-L:nPts//2+L,:])
    tdata -= np.mean(tdata)
    fftdata = fft.fft2(tdata)

    peakf, bfi = guess_base_frequency(fftdata, number)

    fftabs = np.abs(fftdata)
    fftabs /= np.mean(fftabs)

    col = fftdata[:,bfi-1:bfi+2]
 #   print("SHAPE", fftdata.shape)
 
    ratios = col[1:-1,:]/col[2:,:]
 
    abscol=np.abs(col)
    anglecol = np.angle(col)
    acm = np.angle(col)[:,1]
 
   # datadump(abscol[:,1], "lam"+str(number)+".out")
   # datadump(anglecol[:,1], "lamang"+str(number)+".out")

    xi_out = find_angle(abscol[:,1]) * numrows
#    print("ANGLEGUESS", xi_out)

    k_out = xi_out / np.pi

    return peakf, -1./k_out


def obsolete_mess():

    eprint("corellating...", data.shape)
    if 0:
        cdata = correlate(data, data)
    if 0:
        cdata = phase_correlation(data, data)
    if 0:
        cdata = ss.correlate2d(data, data, mode='same')
    if 1:
        # m=np.mean(data)
        # data-=m
        eprint("idata shape", idata.shape)
        idatac = np.conjugate(idata)
        cdata = fft.ifft2(idata*idatac).real
        cdata = np.roll(cdata, len(cdata[0])//2, axis=1)
        cdata = np.roll(cdata, L, axis=0)
        # cdata = cdata[0:L,:]
    if 0:
        cdata = fft.fft2(data)
        ccdata = cdata.conj()

    idata = idata[0:L,:len(idata[0])//2]
    idatac = idatac[0:L,:len(idatac[0])//2]

    fmin = 25./len(data[0])/2.
    fmax = fmin*len(idata[0])
    eprint("frange", fmin, fmax)

    #fwin_center = int(targetf/fmax*len(idata[0]))
    #print("fwin center:", targetf, fwin_center)
    #eprint("idata shape", idata.shape)

    # lpc, lb=logpolar(center)
    # lpcf, lb=logpolar(center[::-1,:])

    # eprint("corr...", lpc.shape, lpcf.shape)
  #  ac = ss.correlate2d(lpc,lpcf)
  #  eprint("corr", ac, "mean", np.mean(ac))
  #  ac/=np.mean(ac)
  #  imageio.imsave("CORR_ac0"+str(number)+".png", ac)

    mag = idata*idatac
    # mag[0][0] = 0.
    mymag = np.sqrt(mag.real)
    #mymag_fwin = mymag[L:,fwin_center-10:fwin_center+11]
    idata_fwin = idata[:,fwin_center-1:fwin_center+2]

    #frow = np.argmax(mymag_fwin[0])
    #eprint("FROW", frow)
    #mm=idata_fwin[0][frow]

    #mymag_fwin = mymag_fwin[1:,frow-1:frow+2]
    #idata_fwin = idata_fwin[:,frow-1:frow+2]

#    idata_fwin /= mm # needed?

    logmag = np.log(mymag)
    # imageio.imsave("CORR_mag_"+str(number)+".png", logmag[:,0:100])
    imageio.imsave("CORR_mag_"+str(number)+".png", mymag[:,:])
    imageio.imsave("CORR_logmag_"+str(number)+".png", logmag[:,:])
 #   imageio.imsave("CORR_angle_"+str(number)+".png", np.angle(idata_ratio))
    imageio.imsave("CORR_angle_raw_"+str(number)+".png", np.angle(idata))
    imageio.imsave("CORR_angle_fwin_"+str(number)+".png", np.angle(idata_fwin))
    imageio.imsave("CORR_dangle"+str(number)+".png", np.diff(np.angle(idata)))

    imageio.imsave("CORR_dangle_fwin"+str(number)+".png", np.diff(np.angle(idata_fwin), axis=0))

    idata_ratio = idata_fwin[1:,:]/idata_fwin[:-1,:]
    imageio.imsave("CORR_rat_fwin_"+str(number)+".png", np.angle(idata_ratio))

    sumof_it=0
    for x in idata_ratio:
        for xx in x:
            sumof_it += xx

    eprint("idatasum", sumof_it, np.angle(sumof_it))


    return peakf, np.angle(sumof_it)

    # ang = ang*logmag
    #imageio.imsave("CORR_dangle_"+str(number)+".png", dang[:L,0:10])
    #LLZ=len(cdata)//2
    #imageio.imsave("CORR_"+str(number)+".png", cdata)
    # imageio.imsave("CORR_log0"+str(number)+".png", lpc)
    # imageio.imsave("CORR_log1"+str(number)+".png", lpcf)
    # imageio.imsave("CORR_p_"+str(number)+".png", np.angle(cdata))
    # imageio.imsave("CORR_r_"+str(number)+".png", np.log(cdata.real))
    # imageio.imsave("CORR_i_"+str(number)+".png", np.log(cdata.imag))

def curvplot(magchunk, wData, wDir, fr, gaitstring):
    global pp
    global pagenumber
    global f
    global axarr
    global fig
    if(fr[1]-fr[0] < fs*min_duration):
        print("tooshort", fr[0],fr[1], "need", min_duration)
        return
    eprint("curveplot", pp, fr, gaitstring)

    # flush page
    if(pp and not pp % plots_per_page):
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close()
        f, axarr = plt.subplots( plots_per_page )
        fig = plt.figure(1)
        pagenumber += 1

    curax=axarr[pp%plots_per_page]


    mf="?"
    basef = baselam = 0
    if(magchunk.shape[1]):
        try:
            basef, baselam = corrstuff(magchunk, number=pp)
            unwrap_window = int(6 // basef)
        except:
            unwrap_window = 5
        # print("window", basef, unwrap_window)

        wss = wData[:,2]
        avg_wave_speed = np.sum(wss)/(len(wss)-1)

        if(do_plot):
            mf, lf = do_curvplot(magchunk, wData, wDir, curax, unwrap_window, basef=basef,
                    baselam=baselam)

    title = str(fr) + ", " + gaitstring + ", " + str(concentration) + \
            "% basef {0:.2f}, lambda {1:.2f}, aws {2:.2f}".format(basef, baselam, avg_wave_speed)
    print(concentration, fr[1] - fr[0], gaitstring, basef/2., 2*baselam ) # HERE
    curax.set_title(title)

    pp += 1

def do_curvplot(magchunk, wData, wDir, cur_ax, unwrap_window, basef=0, baselam=0):
    timeSteps = len(wData)
  #  print("do_cp", magchunk.shape)
    assert(magchunk.shape[1])


    if(1): # for pp in [0]: # range(nPlts):
        x2 = cur_ax.twinx()
        cur_ax.set_ylim(-.11, 1)
        tend=max(segment_length, timeSteps/fs)
        cur_ax.set_xlim(0, tend)
        # eprint("Plot...", pp, timeSteps, len(wDir), "\n")
        cur_ax.imshow( magchunk, interpolation='bilinear',
                    extent=[ 0, timeSteps / fs,
                             0, 1 ], cmap='Blues', aspect='auto',
                    vmin=0, vmax=wMaxMin[0] )

        # move up...
        if(wrapped_curvature):
            basef /= 2.
            baselam *= 2.

        plot_freq_ann(cur_ax, timeSteps/fs, basef, baselam)
        #### hilbertstuff(magchunk)
        m0 = np.array(magchunk[nPts//4])
        m1 = np.array(magchunk[nPts//2])
        m2 = np.array(magchunk[3*nPts//4])
        #m0 = np.array(magchunk[63-3])
        #m1 = np.array(magchunk[63])
        #m2 = np.array(magchunk[63+3])

        MM = [m0, m1, m2]

        for m0 in MM:
            unwrap(m0, unwrap_window)
            # lowpass(m0)

        aw = 15
        ifall, lf = taulambda(MM, aw=aw)

        ub = len(wDir)

        dirColors = wDir
        cur_ax.scatter( arange(timeSteps)/fs,
                        [ -.05 ] * ub , c=dirColors, marker='.', s=.1)
        gaitColors = list(zip(*wData))[0]

        cur_ax.scatter( arange(timeSteps)/fs,
                         [ -.10 ] * ub , c=gaitColors, marker='.', s=.1)
        cur_ax.set_ylabel('Body coordinate')
        cur_ax.set_xlabel('Time (s)')

        #cur_ax.plot( np.aRray(range(2000))/fs, magchunk[63] )
#        cur_ax.plot( np.arange(len(m0))/fs, .75+MM[0]/100, color='red', linewidth=.2 )
#        cur_ax.plot( np.arange(len(m0))/fs, .5 +MM[1]/100, color='red', linewidth=.2 )
#        cur_ax.plot( np.arange(len(m0))/fs, .25+MM[2]/100, color='red', linewidth=.2 )

        IDX_PLAN = 1
        IDX_LIN = 3
        planarities=list(zip(*wData))[IDX_PLAN]
        linearities=list(zip(*wData))[IDX_LIN]
        L=len(planarities)
        x2.plot( np.arange(L)/fs, planarities, color='yellow', linewidth=.4 )
        x2.plot( np.arange(L)/fs, linearities, color='red', linewidth=.4 )
        mf = np.mean(ifall)

# cur_ax.plot( np.arange(len(lf))/fs, lf, color='green', linewidth=.2 )

        return mf, lf
       # axarr[pp].plot( if0/100. )


if(0): # maybe later
    fig = plt.figure(2)
    f, axarr = plt.subplots( nPlts )
    if nPlts == 1: axarr = [axarr]

    for pp in range(nPlts):
        eprint("plot...", pp, "\n")
        axarr[pp].imshow( p2[:,pp * timeSteps: (pp+1) * timeSteps ],
                              interpolation='bilinear',
                              extent=[ pp * timeSteps / fs, (pp+1) * timeSteps / fs,
                                       0, 1 ], aspect='auto')
        axarr[pp].set_ylabel('Body coordinate')
        axarr[pp].set_xlabel('Time (s)')

    plt.savefig('{0}/curvature_angle.pdf'.format(outdir), facecolor=fig.get_facecolor())


nCam = 3
camRange = range( 0, nCam )

eprint('read pvd file:', basename + 'skeletons_worm.pvd')

from worm_parse import ptsFromVtu
from worm_parse import WORM_FWD, WORM_BACK, WORM_ERROR, WORM_STILL

from util import norm

# do plotting here
nTimes = 99999 # len(mainPvd)
wMaxMin = [False,False]

timeSteps = min(2000, nTimes)

headTail = mpl.cm.get_cmap('cool')

from colormaps import mkcmap

anglemap = mkcmap()

def myanglemapRT( R, T ):
    if T < -np.pi or T > np.pi:
        print( 'theta = ', T, ' in wrong range: theta in [0,2pi]')
        exit()
 
    if R < 0 or R > 1:
        R = max( min( R, 1.0 ), 0 )

    c = anglemap( 0.5 + 0.5 * T / np.pi )
    return tuple( [ _ * R for _ in c ][:-1] )

def myanglemap( k1, k2 ):
    theta = np.arctan2( k2, k1 )
    rad = np.sqrt( k1*k1 + k2*k2 ) / wMaxMin[0]
    return myanglemapRT( rad, theta )

################### TODO: cleanup
# can only do one tagfile at a time...

do_plot = True
gait_mask = 0
gait_stuff = 0
size_thresh = 0
min_duration = 0

wrapped_curvature = False
concentration = 0
include_all = False

RUN_ID="000000" # use env?!

i=1
base="."
while(argv[i][0]=="-"):
    if argv[i]=="-s":
        i += 1
        min_duration = float(argv[i])
    elif argv[i]=="-w":
        wrapped_curvature = True
    elif argv[i]=="-a":
        include_all = True
    elif argv[i]=="-p":
        do_pdf = True
    elif argv[i]=="-R":
        i += 1
        RUN_ID = argv[i]
    elif argv[i]=="-c":
        i += 1
        concentration = float(argv[i])
    elif argv[i]=="-m":
        i += 1
        gait_mask = int(argv[i])
        print("GM", gait_mask)
    elif argv[i]=="-r":
        i += 1
        gait_stuff = int(argv[i])
    elif argv[i]=="-S":
        i += 1
        segment_length = float(argv[i])
    elif argv[i]=="-b":
        i += 1
        base = argv[i]
    elif argv[i]=="-n":
        do_plot = False
    else:
        eprint("unknown arg", argv[i])
        exit(1)
    i += 1


def frames_per_line():
        return fs*segment_length

E1 = np.array( [1,0,0] )

fi = argv[i]
use_tags = False

if fi[-4:] == ".csv":
    use_tags = True
else:
    include_all = True


if use_tags:
    T = frame_tags(fi)
    concentration = T.get_concentration()
    I = posture_indicator(T)

    videodir="/nobackup/scsfsa/output-curve/" + RUN_ID
    wormpvd = videodir+"/"+T.videofilename()+"/skeletons_worm.pvd"

    if(T.videofilename()==""):
        eprint("somethings wrong with", fi)
        eprint("no videofilename")
        sys.exit(1)
else:
    from worm_collect import dummywl
    wormpvd = fi
    I = dummywl

eprint("reading in " + wormpvd)

pdf = PdfPages(base + 'curvature.pdf') #(, facecolor=fig.get_facecolor())

try:
    WL = worm_collect(wormpvd, 0, 999999, I, all_frames=include_all)
except FileNotFoundError:
    eprint("cannot wormcollect", wormpvd)
    sys.exit(1)



if WL.timestep():
    fs=1./WL.timestep()
    print("overriding fs", fs)


MAG = np.zeros( (2*nPts, nTimes) )
pk = np.zeros( (nPts, nTimes, 2) )
p2 = np.zeros( (nPts, nTimes, 3) )

wDir = []
wData = []
i = 0
framenum=framenum1=endfn=0
oldgait = None
fn=fn1=0
gaitstring = "unknown"
istart = ii = 0
w1 = None
wMags = []
for ii, worm in enumerate(WL):
    if i % timeSteps == 0:
        eprint("thing", i, '/', nTimes)


    time = .01 # mainPvd[i].get('timestep')
    pts = worm.pts()
    W = worm.W()
    nPts = len(W);
    U = worm.U()

    gait = worm.gait()
    fn = worm.get_framenumber()

    if(include_all):
        newchunk = not i%frames_per_line()
    else: # make it tag dependent
        newchunk = gait!=oldgait or fn1+1!=fn

    fn1 = fn
    if newchunk:
        if(ii):
            wd = np.array(wData)
            curvplot(MAG[:nPts,:ii-istart], wd, wDir, [endfn, framenum], gaitstring)
        istart = i
        framenum1 = endfn
        endfn = worm.get_framenumber()
        wMags = []
        wData = []
        wDir = []
        # endfn = i

    gaitstring = str(worm.gait())

    # this seems to work
    framenum = worm.get_framenumber()

    oldgait = gait

    # if( worm.direction()  == )
    d = worm.direction()
    dirColor = dircolor(d)
    wDir.append( dirColor )
    gaitColor = gaitcolor(worm)
    try:
        linearity = worm.dist_to_line()
        planarity = worm.dist_to_plane()
        wavespeed = worm.wave_speed(w1)
    except ValueError:
        eprint("ERROR in frame ", i)
        break

    wData.append( [ gaitColor, planarity, wavespeed, linearity ] )

    # the midline curvature
    for j, w in enumerate(W):
        wMag = np.linalg.norm( w[0:3] )
        MAG[ j, i-istart ] = wMag

        wMags.append( wMag )

    wMags.sort()

    m = wMags[9*len(wMags)//10]
    if wMaxMin[0]:
        wMaxMin[0] = max( wMaxMin[0], m )
    else:
        wMaxMin[0] = m

    #print(m)

    w1 = worm
    i += 1

if(ii):
    wd = np.array(wData)
    eprint("last chunk", ii, wd.shape)
    chnk = MAG[:nPts,:ii-istart]

    if(len(chnk)):
        curvplot(chnk, wd, wDir, [endfn, worm.get_framenumber()], gaitstring)

i = 0
for ii, worm in enumerate(WL):
    if i % timeSteps == 0:
        print(i, '/', nTimes)

    gait = worm.gait()
    print(ii, gait)
    if gait!=oldgait:
        print("======================")
    oldgait = gait

    time = .01
    pts = worm.pts()
    W = worm.W()
    U = worm.U()

    T, M1, M2 = [], [], []
    K1, K2 = [], []

    #what's this?
    for j in []: # range(len(pts)-1):
        t = pts[j+1] - pts[j]
        t = t / norm(t)
        T.append(t)

        if j == 0:
            n1 = np.cross( t, np.cross( E1, t ) )
            m = n1 / norm(n1)
            m2 = np.cross( t, m )

            M1.append( m )
            M2.append( m2 )

            k1 = np.dot( W[0], m )
            k2 = np.dot( W[0], m2 )
            K1.append( k1 )
            K2.append( k2 )
            theta = np.arctan2( k2, k1 )

            p2[ j, i ] = myanglemap( k1, k2 )
            pk[ j, i ] = ( k1, k2 )

            E1 = m

        m = np.cross( t, np.cross( m, t ) )
        m = m / norm(m)
        m2 = np.cross( t, m )

        M1.append(m)
        M2.append(m2)

        k1 = np.dot( W[j+1], m )
        k2 = np.dot( W[j+1], m2 )
        K1.append( k1 )
        K2.append( k2 )
        theta = np.arctan2( k2, k1 )
        p2[ j, i ] = myanglemap( k1, k2 )
        pk[ j, i ] = ( k1, k2 )
    i+=1

if do_plot:
    fig.tight_layout()
    pdf.savefig(fig)
    pdf.close()


# doesn't work
exit(0)

fig = plt.figure(0, facecolor='white')
gs = gridspec.GridSpec(2, 3)
ax0 = fig.add_subplot( gs[0:2,0:2], projection='3d')
axBar = fig.add_subplot( gs[0,2] )
axPolar = fig.add_subplot( gs[1,2] )


i = 0
for ii, worm in enumerate(WL):
    print(ii)
    if i % timeSteps == 0:
        print(i, '/', nTimes)

    gait = worm.gait()
    print(ii, gait)
    if gait!=oldgait:
        print("======================")
    oldgait = gait

    time = .01 # mainPvd[i].get('timestep')

    pts = worm.pts()
    W = worm.W()
    U = worm.U()

    ax0.cla()
    ax0.set_xlabel('mm')
    ax0.set_ylabel('mm')
    ax0.set_zlabel('mm')

    for j in range(len(pts)-1):
        xx = [ pts[j+1][0], pts[j][0] ]
        yy = [ pts[j+1][1], pts[j][1] ]
        zz = [ pts[j+1][2], pts[j][2] ]

        k1, k2 = pk[ j, i ]
        color = p2[ j, i ]
        theta = np.arctan2( k2, k1 )
        ax0.plot( xx, yy, zz, color=color, linewidth=5 )

    minx = min( [ pt[0] for pt in pts ] )
    maxx = max( [ pt[0] for pt in pts ] )
    miny = min( [ pt[1] for pt in pts ] )
    maxy = max( [ pt[1] for pt in pts ] )
    minz = min( [ pt[2] for pt in pts ] )
    maxz = max( [ pt[2] for pt in pts ] )

    maxRange = max( [ maxx-minx, maxy-miny, maxz-minz] ) / 2.0

    newxRange = [ (minx+maxx)/2.0 - maxRange,  (minx+maxx)/2.0 + maxRange ]
    newyRange = [ (miny+maxy)/2.0 - maxRange,  (miny+maxy)/2.0 + maxRange ]
    newzRange = [ (minz+maxz)/2.0 - maxRange,  (minz+maxz)/2.0 + maxRange ]

    for xb, yb, zb in zip( newxRange, newyRange, newzRange ):
        ax0.plot( [xb], [yb], [zb], 'w' )

    ax0.set_xticks( np.linspace( np.ceil( newxRange[0]/0.25)*0.25,
                                 np.floor( newxRange[1]/0.25)*0.25,
                                 int( np.floor( newxRange[1]/0.25) - np.ceil( newxRange[0]/0.25) )+1,
                                 endpoint=True ) )
    ax0.set_yticks( np.linspace( np.ceil( newyRange[0]/0.25)*0.25,
                                 np.floor( newyRange[1]/0.25)*0.25,
                                 int( np.floor( newyRange[1]/0.25) - np.ceil( newyRange[0]/0.25) )+1,
                                 endpoint=True ) )
    ax0.set_zticks( np.linspace( np.ceil( newzRange[0]/0.25)*0.25,
                                 np.floor( newzRange[1]/0.25)*0.25,
                                 int( np.floor( newzRange[1]/0.25) - np.ceil( newzRange[0]/0.25) )+1,
                                 endpoint=True ) )

    rr = 50
    imStart = i - rr
    imEnd = i + rr
    if i < rr:
        imStart = 0
        imEnd = 2*rr
    if i > nTimes - rr:
        imStart = nTimes - 2*rr
        imEnd = nTimes

    myP2 = np.copy( p2 )
    myP2[:,i] = (1,1,1)

    axBar.cla()
    axBar.imshow( myP2[:, imStart:imEnd ],
                  interpolation='bilinear',
                  extent=[ imStart / fs, imEnd / fs,
                           0, 1 ], aspect='auto')
    axBar.set_ylabel('Body coordinate')
    axBar.yaxis.set_ticks( [0.0, 1.0] )
    axBar.xaxis.set_ticks( range( int(np.ceil(imStart/fs)), int(np.ceil(imEnd/fs)) ) )
    axBar.axis( [ imStart/fs, imEnd / fs, 0.0, 1.0 ] )
    axBar.set_xlabel('Time (s)')

    axPolar.cla()

    polarIm = np.zeros( (50, 50, 3 ) )
    for jj,kx in enumerate(np.linspace( -wMaxMin[0], wMaxMin[0], 50 )):
        for ii,ky in enumerate(np.linspace( -wMaxMin[0], wMaxMin[0], 50 )):
            polarIm[ ii, jj ] = myanglemap( kx, ky )

    axPolar.imshow( polarIm,
                    extent=[ -wMaxMin[0], wMaxMin[0], -wMaxMin[0], wMaxMin[0]] )
    axPolar.plot( [ k1 for k1, k2 in pk[ :, i ] ],
                  [ k2 for k1, k2 in pk[ :, i ] ], 'w.-', linewidth=2 )
    axPolar.set_xlim( -wMaxMin[0], wMaxMin[0] )
    axPolar.set_ylim( -wMaxMin[0], wMaxMin[0] )
    axPolar.set_xlabel('$k_1$ (mm${}^{-1}$)')
    axPolar.set_ylabel('$k_2$ (mm${}^{-1}$)')

    for R in np.linspace( 0, wMaxMin[0], 4 ):
        axPolar.plot( R * np.cos( np.linspace( 0, 2.0*np.pi ) ),
                      R * np.sin( np.linspace( 0, 2.0*np.pi ) ), 'k--' )
    # axPolar.yaxis.set_major_locator( MaxNLocator(3) )
    # axPolar.grid(True)

    fn = '{1}/all_{0:06d}.pdf'.format(i, outdir)
    print( 'saving', fn)

    if do_plot:
        fig.tight_layout()
        plt.savefig( fn )
    i+=1

# vim:ts=8:sw=4:et
