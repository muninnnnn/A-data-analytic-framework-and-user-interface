#!/usr/bin/env python
from sys import argv
import numpy as np
from scipy import stats
from math import sqrt
from numpy.linalg import norm

def estimateK(w0, w1, dt=1.):
	l=len(w0)

	# the displacement
	dx=np.empty([l,3])
	# the tangent
	t=np.empty([l-1,3])

########### toms K (don't get it)
	velocity=np.empty([l,3])
	integral=0.
	tauIntegral=0.

	for i in range(l-1):
		velocity[i] = (w0[i] - w1[i])/ dt
		velocity2 = (w0[i+1] - w1[i+1])/ dt

		tauTilde = w1[i+1] - w1[i]
		q = np.linalg.norm( tauTilde )
		tau = tauTilde / q

		velocityi = ( velocity[i] + velocity2 ) / 2.0
		integral = integral + velocityi * q * dt
		tauVelocity = np.dot( velocityi, tau ) * tau
		tauIntegral = tauIntegral + tauVelocity * q * dt

	II = np.dot( integral, integral )
	IItau = np.dot( integral, tauIntegral )

	TK = - IItau / ( II - IItau)
	# TK = 1.0 / ( 1.0 - II / IItau )


#	print norm( integral ), norm( tauIntegral ) 
	eo= norm( TK * integral + ( 1.0 - TK ) * tauIntegral )
########### toms K

	for i in xrange(0,l-1):
		dx[i] = (w0[i]-w1[i] + w0[i+1]-w1[i+1])/2.
		# dx[i] = w0[i] - w1[i]

		# tangent.
		tdir = (w0[i] + w1[i] - w0[i+1] - w1[i+1])
		t[i] = tdir / norm(tdir)

#	dx[-1]=w0[-1]-w1[-1]

	# normal displacement
	nd=np.zeros([l-1,3])
	# tang displacement
	td=np.zeros([l-1,3])

	TD=np.zeros(3)
	ND=np.zeros(3)

	for i in xrange(0,l-2):

		p=np.dot(t[i].transpose(), dx[i])
		td[i] = p*t[i]
		nd[i] = dx[i]-td[i]

		# print i, td[i][0], nd[i][0]
		TD+=td[i]
		ND+=nd[i]

#	print "tangential drag", TD, ND
#	print "TD", TD
#	print "ND", ND
#	print "ratios", ND/TD

	dot=1e-9
	try:
		TDS = np.dot(TD, TD)
		NDS = np.dot(ND, ND)
		TDN=sqrt(TDS)
		NDN=sqrt(NDS)
#		print NDN/TDN

		dot=np.dot(TD, ND)
		# c=1 => same direction
		# c=0 => orthogonal, bad.
		# c<0 => something wrong?
		c = -dot/TDN/NDN
#		print "coll", c
		K =  TDN / NDN
		
		return [ (K, TK), (c, eo) ]
	except ZeroDivisionError:
		return [ (0,0), (999,-999)]

if __name__=="__main__":
	fw0="4pc/skeletons_worm_000404.vtu"
	fw1="4pc/skeletons_worm_000403.vtu"

	fw0="typical/worm_004930.vtu"
	fw1="typical/worm_004920.vtu"

	from worm_parse import ptsFromVtu
	w0=ptsFromVtu(fw0)[0]
	w1=ptsFromVtu(fw1)[0]

	print(estimateK(w0, w1))

	#w1=np.array([[0,0,0], [0,0,1./3.], [0,0,2./3.]])
	#w0=np.array([[1,0,1./3.], [1,0,2./3.], [1,0,3./3.]])
	# print estimateK(w0, w1)
