
SEARCHTOKEN="</VTKFile>"
TOKEN="</Collection></VTKFile>"
addendtags(){
   find $1 -name '*.pvd' |
   while read p; do
      tail -n 1 "$p" | grep -q "$SEARCHTOKEN" || \
         echo "$TOKEN" >> $p
   done
}

while [ $# -gt 0 ]; do
	echo doing $1
	addendtags "$1"
   shift
done
