#!/bin/bash

# ---------- set arc parameters for pbs ----------

# Set current working directory
#$ -cwd
#Use current environment variables/ modules
#$ -V
#Request one hour of runtime
#$ -l h_rt=48:00:00
#$ -l h_vmem=100G
#Email at the beginning and end of the job
#$ -m be
# Tell SGE that this is an array job, with "tasks" numbered from 1 to 150

#$ -t 2-140
# 1.25
##$ -t 106-113

## 1.5
##$ -t 64-69

##$ -t 69

# 98: the LONG clip

# set -e

# error out on unset variables
# http://redsymbol.net/articles/unofficial-bash-strict-mode/
set -uo pipefail
set -x
set -e

# yuck?!
# set -e
LAYOUT=all
LAYOUT=2D

VIDEODIR="/nobackup/scsrih/video"

# ignore bad gait
EXTRA_PC_ARGS=-a


# this is madness.
#  IFS=$'\n\t'

PYTHONFLAGS=-O

# ---------- parameters from csv ----------

# specify params file
csv_file="../worm-data/run_info.csv"
# csv_file="4_00.csv"
run_date="${1-}" # not the run date.
# today=`date +%Y%m%d_%H%M%S`

if [ -z ${run_date} ]; then
	echo need \"run date\" >&2
	exit 1
fi

if [ -z "${SGE_TASK_ID-}" ]; then
	#BUG: figure out task number.
	exec qsub $0 $@
fi

shift

# extract parameters
lineid=$((${SGE_TASK_ID}+1))
csv_line=`sed "${lineid}q;d" ${csv_file} | sed 's/\r$//' | sed -e "s#scsrih/output#$USER/output#"`
OLDIFS="$IFS"
IFS=',' read -ra params <<< "$csv_line"
IFS="$OLDIFS"

echo ${params[*]}

CURVE_PREFIX_PRE=`dirname ${params[7]}`
CURVE_PREFIX_POST=`basename ${params[7]}`
CONCENTRATION=${params[8]}
CURVE_PREFIX="${CURVE_PREFIX_PRE}/${run_date}/${CURVE_PREFIX_POST}/"

CALIBRATION_FILE="${params[3]}"
CALIBRATION_DIR=../worm-data/calib

if [ ${CALIBRATION_FILE:0:1} != "/" ]; then
	CALIBRATION_FILE="$CALIBRATION_DIR/$CALIBRATION_FILE"
fi

TAGFILE=../worm-data/tags/${CURVE_PREFIX_POST}.csv
TAGARG=--tags=${TAGFILE}

echo curve_prefix ${CURVE_PREFIX}

find ${CURVE_PREFIX} -maxdepth 1 -type d | while read line; do
# --------------------------------------------------

curve_pvd_dir="${line}"
curve_wp_dir="/nobackup/scsfsa/output-curve/00/${CURVE_PREFIX_POST}"

echo curve_pvd_dir ${curve_pvd_dir}
echo curve_wp_dir ${curve_wp_dir}


VIDEO0="${params[0]}"
VIDEO1="${params[1]}"
VIDEO2="${params[2]}"

if [ ${VIDEO0:0:1} != "/" ]; then
	VIDEO0="$VIDEODIR/$VIDEO0"
fi
if [ ${VIDEO1:0:1} != "/" ]; then
	VIDEO1="$VIDEODIR/$VIDEO1"
fi
if [ ${VIDEO2:0:1} != "/" ]; then
	VIDEO2="$VIDEODIR/$VIDEO2"
fi

output_dir=/nobackup/scsfsa/valid_vids/${run_date}

# # skip if directory already exists
# if [ -d "$output_dir" ]; then
#     echo "${output_dir} already exists skipping input from ${line}"
#     continue
# fi

mkdir -p ${output_dir}

[ -f run.settings ] && source run.settings

# make temp frame dir
tmpdir=${TMPDIR-/nobackup/${USER}}

if [ -f ${curve_pvd_dir}/skeletons_worm.txt ]; then
	PVD=txt;
elif [ -f ${curve_pvd_dir}/skeletons_worm.pvd ]; then
	PVD=pvd;
else
	:
fi

# for f in ${curve_pvd_dir}/skel*.txt; do
#	./txt2pvd.py $f || :
#done

# for f in ${curve_pvd_dir}/*.pvd
# do
# 	echo "verifying xml file ${f}"
#    python validate-xml.py ${f}
# done

echo "creating image sequence..."


HACKcsv(){
echo "hacking extra file"
if [ -f ${curve_pvd_dir}/distance_cam${1}_frame_0.csv ]; then
	echo already there.
else
	echo HACK. the actual csv is in a different place. probably
	cp ${curve_pvd_dir}/distance_cam${1}_frame_1.csv \
	   ${curve_pvd_dir}/distance_cam${1}_frame_0.csv || :
fi
}
HACKcsv 0
HACKcsv 1
HACKcsv 2

# convert video to image sequence
# ffmpeg -i ${VIDEO0} ${frame_dir}/Cam1_%06d.png
# ffmpeg -i ${VIDEO1} ${frame_dir}/Cam2_%06d.png
# ffmpeg -i ${VIDEO2} ${frame_dir}/Cam3_%06d.png

echo "creating validation plots..."

PCAFILE=4pc_all_10.pca 
PCAFILE=pcaout/4_00_tagged.pca

PCAFILE=${CONCENTRATION}pc_HT_CF.pca
echo PCAFILE=${PCAFILE}


PCAARGS=
if [ -f $PCAFILE ]; then
	PCAARGS=${PCAARGS}\ -p\ $PCAFILE
fi

test -f ${VIDEO0}
test -f ${VIDEO1}
test -f ${VIDEO2}

# curve validation plot (to png)
python $PYTHONFLAGS \
./worm-movie.py -s ${SGE_TASK_ID}_ \
	 ${PCAARGS} ${TAGARG} \
	 -x ${VIDEO0} -y ${VIDEO1} -z ${VIDEO2} \
	 -C ${CALIBRATION_FILE} \
    -L ${LAYOUT} \
	 -w ${curve_pvd_dir}/skeletons_worm.pvd \
    --wpdir=${curve_wp_dir} \
    --pvddir=${curve_pvd_dir} \
	 --framesdir=${output_dir} --outdir=${output_dir} \
	 ${EXTRA_PC_ARGS-} $@

done
