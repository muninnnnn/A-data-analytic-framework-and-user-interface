
from scipy.signal import hilbert
import numpy as np
from scipy import signal

def lowpass_simple(m):
    m[0] = m[0]/2.
    for i in range(1,len(m)):
        m[i] = (m[i]+m[i-1])*.5

def lowpass(m):
    b, a = signal.butter(3, 0.125)
    y = signal.filtfilt(b, a, m) # , padlen=150)
    for i in range(len(m)):
        m[i]=y[i]

def average(m):
    b, a = signal.butter(3, 0.125)
    y = signal.filtfilt(b, a, m) # , padlen=150)
    for i in range(len(m)):
        m[i]=y[i]

def moving_average(a, n=3) :
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n

def moving_average_pad(a, n=3) :
	if(len(a)<n//2):
		return a
	a = np.pad(a, n//2, 'reflect')
	ret = np.cumsum(a, dtype=float)
	ret[n:] = ret[n:] - ret[:-n]
	return ret[n - 1:] / n


# compute instantaneous frequency and lambda
# BUG: size mess, "aw" hack..
def taulambda(MM, fs=25., aw=31):
        # m0 = m0 * M0
        H = [ hilbert(m0) for m0 in MM ]
        IP = [ np.unwrap(np.angle(h0)) for h0 in H ]
        IF = [ np.diff(ip0) * fs/2./np.pi for ip0 in IP ]

        IF=[moving_average_pad(x, aw) for x in IF]

        ifall=(IF[0]+IF[1]+IF[2])/3.

        deltap = IP[2]-IP[0]
        dpf = moving_average_pad(deltap, aw)

        lammda = 1./(ifall* dpf[1:] * 2.)
        lf = moving_average_pad(lammda, aw)

        return ifall, lf

def taulambda_hacked(MM, fs=25., aw=31):
	# m0 = m0 * M0
	H = [ hilbert(m0) for m0 in MM ]
	h0 = H[0]
	
	IP = [ np.unwrap(np.angle(h0)) for h0 in H ]
	IF = [ np.diff(ip0) * fs/2./np.pi for ip0 in IP ]
	
	IF=[moving_average_pad(x, aw) for x in IF]
	
	ifall=(IF[0]+IF[1]+IF[2])/3.
	
	deltap = IP[2]-IP[0]
	dpf = moving_average_pad(deltap, aw)
	
	denom = ifall* dpf[1:] * 2.
	for i, x in enumerate(denom):
		if abs(x)<1e-20:
			denom[i] = 1e-20

	lammda = 1./denom
	
	lf = moving_average(lammda, aw)
	
	return ifall, lf
