import glob
from matplotlib import cm
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import os
import parameters
import sys

from matplotlib import rcParams
rcParams['axes.labelsize'] = 21
rcParams['xtick.labelsize'] = 21
rcParams['ytick.labelsize'] = 21
rcParams['legend.fontsize'] = 10

from matplotlib import rcParams
rcParams['font.family'] = 'sans'
rcParams['font.serif'] = ['Computer Modern Roman']
rcParams['text.usetex'] = True

golden_ratio  = (np.sqrt(5) - 1.0) / 2.0  # because it looks good

fig_width_in  = 5.90551
fig_height_in = fig_width_in * golden_ratio   # figure height in inches
fig_dims    = [fig_width_in, fig_height_in] # fig dims as a list

from matplotlib.ticker import MaxNLocator
my_locator = MaxNLocator(4)

def parseFn( full_fn ):
    fn = os.path.basename( full_fn )
    data = fn.split('_')
    strain = data[0]
    media = float(data[1]+data[2][:2])/100.0
    date = data[3]
    trial = data[4]
    datatype = data[5]

    trialId = strain + '_' + '{}pc'.format(media).replace('.','_') + '_' + date + '_' + trial

    return strain, media, date, trial, datatype, trialId

def readTrajectoryFile( fn ):
    data = np.loadtxt(fn, delimiter=',')

    frame_number = data.T[0]
    time = data.T[1]
    x = data.T[2]
    y = data.T[3]
    z = data.T[4]
    speed = data.T[5]
    distance = data.T[6]
    cumulative_distance = data.T[7]
    turn_rate = data.T[8]
    turn_radii = data.T[9]
    return frame_number,time,x,y,z,speed,distance,cumulative_distance,turn_rate,turn_radii

# use plot_trajectory.py?
if 1 or __name__ == "__main__":
    parameters = parameters.parserDict( sys.argv )

    #basedir = parameters['base_dir']
    basedir = '/home/csunix/scstr/biosys2/3D_Data/analysis/223137/'
    #outdir = parameters['output_dir']
    outdir = 'traj_pretty'

    for file in sorted( glob.glob( basedir + '*.csv')):
        strain, media, date, trial, datatype, trialId = parseFn( file )

        if datatype == 'traj':

            frame_number,times,x,y,z,speed,distance,cumulative_distance,turn_rate,turn_radii = readTrajectoryFile( file )

            fig = plt.figure(figsize=fig_dims)
            ax = fig.gca(projection='3d')
            nPlots = len(times) / min(500,len(times)) + 1
            for j,t in enumerate( times ):
                if j == 0:
                    continue
                c = t / times[ len(times) / nPlots ]
                while c > 1: c = c - 1
                ax.plot( [ x[j-1], x[j] ], [y[j-1], y[j]], [z[j-1],z[j]], color=cm.hsv( c ) )
            # plt.title( trialId + ':' + 'trajectory' )

            ax.set_xlabel('(mm)')
            ax.set_ylabel('(mm)')
            ax.set_zlabel('(mm)')

            ax.xaxis.set_major_locator( MaxNLocator(4) )
            ax.yaxis.set_major_locator( MaxNLocator(4) )
            ax.zaxis.set_major_locator( MaxNLocator(4) )


            plt.savefig( os.path.join( outdir, trialId + '_' + 'trajectory.pdf' ) )
            print 'saving',os.path.join( outdir, trialId + '_' + 'trajectory' + '.pdf' )
            plt.savefig( os.path.join( outdir, trialId + '_' + 'trajectory.png' ) )
            print 'saving',os.path.join( outdir, trialId + '_' + 'trajectory' + '.png' )
