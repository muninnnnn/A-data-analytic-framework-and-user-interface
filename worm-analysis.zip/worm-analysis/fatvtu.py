#!/usr/bin/env python

from plot_surface import do_file
from sys import argv

do_file(argv[1], 0, argv[1]+"_cyl.vtk")
