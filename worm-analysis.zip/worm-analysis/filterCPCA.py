#!/usr/bin/env python
from __future__ import print_function
from sys import argv
from msToXw import msToXw
import numpy as np
from math import sqrt
from eigenworm import readEwMs
from error import printn
from numpy.linalg import norm
from numpy import array
from worm_pca import dump_pca


def realize(P, i):
	firstconj = np.conj(P[i])
	fcp = subspace_project(firstconj, P[i:])

	assert norm((firstconj + P[i]).imag) < 1e-15

	startworm = P[i] + fcp
	startworm /= norm(startworm)

	return extend_to_onb(list(P[:i]) + [startworm], P[i+1:])

# compute the distance of q to span(P)
def subspace_distance(P, q):
	for p in P:
		q -= np.dot(q, np.conj(p)) * p

	return norm(q)

def subspace_project(q, P):
	ret = np.zeros_like(q)
	for p in P:
		c = np.dot(q, np.conj(p))
		ret += c* p
	return ret

# gramschmidt
def extend_to_onb(V, B):
	for b in B:
		for v in V:
			b -= np.dot(b, np.conj(v)) * v
		b = b / norm(b)
		V.append(b)
	return array(V)

if __name__=="__main__":
	from numpy.linalg import norm

	cplx=False
	i=1
	if(argv[i] == '-c'):
		cplx=True
		i+=1

	filename = argv[i]
	prefix = filename
	P = readEwMs(filename, cplx)
	index = 0

	B = P
	B=realize(B, 0)
	B=realize(B, 1)
	B=realize(B, 2)
	B=realize(B, 3)
	B=realize(B, 4)
	B=realize(B, 5)
	B=realize(B, 6)
	B=realize(B, 7)
	B=realize(B, 8)

	dump_pca(B, True)
