from error import eprint

def stringtogait(t):
	ret = 0
	if t=="helix" or t=="helical":
		ret= 1
	elif t=="struggle":
		ret= 2
	elif t=="planar":
		ret= 4
	elif t=="turn":
		ret= 8
	elif t=="3d" or t=="3D":
		ret= 16
	elif t=="coiled" or t=="coil":
		ret= 32
	elif t=="weather":
		ret= 64
	elif t=="still":
		ret= 128
	elif t=="loop":
		ret= 256
	elif t=="lasso":
		ret= 512
	elif t=="fwd":
		ret= 1024
	elif t=="turn":
		ret= 2048
	elif t=="bwd":
		ret= 4096
	elif t=="back":
		ret= 4096
	elif t=="still":
		ret= 8192
	elif t=="search":
		ret= 8192 *2
	elif t!="":
		eprint("error gait " + t)
		ret= 65536

	return ret


def listtogait(l):
	g=0

	for i in l[:3]:
		g|=stringtogait(i)
	return g

def row_is_planar(r):
	for i in r[:3]: # 4 is comment
		if stringtogait(i) == 4:
			return True
	return False

def row_is(r, n ):
	a = listtogait(r);
	
	return n == a

def row_has(r, n ):
	a = listtogait(r);
	
	return a == a | n

if __name__=="__main__":
	assert(row_is(["planar"], 4))
	assert(row_is(["fwd"], 1024))
	assert(not row_is(["planar", "fwd"], 1024))
	assert(not row_is(["fwd"], 1028))

	assert(not row_has(["fwd"], 1028))
	assert(row_has(["fwd", "planar"], 1028))
	assert(not row_has(["planar"], 1028))
	assert(row_has(["planar"], 4))
	assert(row_has(["fwd"], 1024))
