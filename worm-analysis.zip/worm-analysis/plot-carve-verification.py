import matplotlib as mpl
mpl.use('agg')

from matplotlib import pyplot as plt
from matplotlib import gridspec
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from matplotlib.backend_bases import NavigationToolbar2, Event
import matplotlib.image as mpimg
import xml.etree.ElementTree
import sys

import parameters
parameters = parameters.parser( sys.argv )

pvdBasename = parameters.pvd_dir + '/'
frameBasename = parameters.frame_dir + '/'
outdir = parameters.output_dir + '/'

# Set up axes and plot some awesome science

nCam = 3
camRange = range( 0, nCam )

fig = plt.figure(facecolor='white')

gs = gridspec.GridSpec(3, 4)
ax0 = fig.add_subplot(gs[0:3,0:3], projection='3d')
camAxs = [ fig.add_subplot(gs[c,3]) for c in camRange ]

def setupAxis( cam, ax, i ):
    if cam < 0:
        ax0.set_xlabel( 'mm' )
        ax0.set_ylabel( 'mm' )
        ax0.set_zlabel( 'mm' )
        # ax.view_init(elev=20., azim=70 + i)
        # ax.grid(False)
    else:
        ax.set_xlabel( 'Pixels' )
        ax.set_ylabel( 'Pixels' )
        # ax.set_title( "Camera View {0}".format(cam+1), fontsize=9 )

gs.update(wspace=0.5, hspace=0.5)

mainPvd = xml.etree.ElementTree.parse( pvdBasename + '3d-points.pvd').getroot()[0].findall('DataSet')
otherPvds = [ xml.etree.ElementTree.parse( pvdBasename + '3d-points_cam{0}-projection.pvd'.format(c)).getroot() for c in camRange ]
def frames(i):
    return [ mpimg.imread( frameBasename + '/Cam{0}_{1:06d}.png'.format(c+1,i+1) ) for c in camRange ]

im0 = None
ims = [ None for _ in camRange ]

def ptsFromVtu( filename ):
    file = open(filename)

    readingPoints = False
    ptsData = []

    for line in file.readlines():
        if '<Points>' in line:
            readingPoints = True
            continue
        if '</Points>' in line:
            readingPoints = False
            continue

        if '</DataArray>' in line:
            readingPoints = False
            continue

        if readingPoints and not 'DataArray' in line:
            for d in line.split():
                ptsData.append( float(d) )

    nPts = len(ptsData)//3

    X = [ np.array(ptsData[3*j:3*(j+1)]) for j in range(nPts) ]
    return X

# set initial values
minx = 0
maxx = 0
miny = 0
maxy = 0
minz = 0
maxz = 0
xmiddle = 0
ymiddle = 0
xyrange = 0

for i,a in enumerate(mainPvd):
    # get main points
    ax0.cla()
    setupAxis( -1, ax0, i )

    time = mainPvd[i].get('timestep')
    fn = pvdBasename + mainPvd[i].get('file')
    pts = ptsFromVtu( fn )

    try:
        x,y,z = zip(*pts)
    except:
        x,y,z = [],[],[]

    ax0.set_title('Time: {0}'.format(time) )
    ax0.plot( x, y, z, 'r.' )

    # update bounding region if possible
    if( len(pts) > 0 ):
        minx = min( [ pt[0] for pt in pts ] )
        maxx = max( [ pt[0] for pt in pts ] )
        miny = min( [ pt[1] for pt in pts ] )
        maxy = max( [ pt[1] for pt in pts ] )
        minz = min( [ pt[2] for pt in pts ] )
        maxz = max( [ pt[2] for pt in pts ] )

    maxRange = max( [ maxx-minx, maxy-miny, maxz-minz] ) / 2.0

    newxRange = [ (minx+maxx)/2.0 - maxRange,  (minx+maxx)/2.0 + maxRange ]
    newyRange = [ (miny+maxy)/2.0 - maxRange,  (miny+maxy)/2.0 + maxRange ]
    newzRange = [ (minz+maxz)/2.0 - maxRange,  (minz+maxz)/2.0 + maxRange ]

    for xb, yb, zb in zip( newxRange, newyRange, newzRange ):
        ax0.plot( [xb], [yb], [zb], 'w' )

    ax0.set_xticks( np.linspace( np.ceil( newxRange[0]/0.25)*0.25,
                                 np.floor( newxRange[1]/0.25)*0.25,
                                 int( np.floor( newxRange[1]/0.25) - np.ceil( newxRange[0]/0.25) )+1,
                                 endpoint=True ) )
    ax0.set_yticks( np.linspace( np.ceil( newyRange[0]/0.25)*0.25,
                                 np.floor( newyRange[1]/0.25)*0.25,
                                 int( np.floor( newyRange[1]/0.25) - np.ceil( newyRange[0]/0.25) )+1,
                                 endpoint=True ) )
    ax0.set_zticks( np.linspace( np.ceil( newzRange[0]/0.25)*0.25,
                                 np.floor( newzRange[1]/0.25)*0.25,
                                 int( np.floor( newzRange[1]/0.25) - np.ceil( newzRange[0]/0.25) )+1,
                                 endpoint=True ) )

    # 2d projections
    # for cam, cap, pvds, im, ax in zip( camRange, caps, otherPvds, ims, camAxs ):
    for cam, f, pvds, im, ax in zip( camRange, frames(i), otherPvds, ims, camAxs ):
        # get frame background
        # r,frame = cap.read()
        # frame = np.zeros((2048,2048,3), np.uint8)
        frame = f.copy()

        ax.cla()
        setupAxis( cam, ax, i )

        # read silhouettes
        try:
            with open( pvdBasename + '/3d-points_cam_silhouette{0}_{1}.csv'.format(cam,i)) as file:
                for line in file.readlines():
                    d = line.split(',')
                    x,y = [int(d[0]),int(d[1])]
                    frame[ y, x ] = 0.75 * frame[y,x] + [0.0,0.0,0.25]
        except:
            print 'unable to find silhouette data'

        pvd = pvds[0].findall('DataSet')[i]
        fn = pvdBasename + pvd.get('file')
        pts = ptsFromVtu( fn )
        try:
            x,y,z = zip(*pts)
        except:
            continue

        if len(pts) > 0:
            xmiddle = (max(x)+min(x)) / 2
            ymiddle = (max(y)+min(y)) / 2
            xyrange = max( [ max(x) - min(x), max(y) - min(y) ] ) + 10
            xxrange = [ xmiddle - xyrange, xmiddle + xyrange ]
            yyrange = [ ymiddle - xyrange, ymiddle + xyrange ]

        for xx,yy in zip(x,y):
            frame[ int(yy), int(xx) ] = [1.0,0.0,0.0]

        im = ax.imshow( frame )

        if 2*xyrange > 100:
            ax.xaxis.set_ticks( np.arange(0, 2048, 100) )
            ax.yaxis.set_ticks( np.arange(0, 2048, 100) )
        elif 2*xyrange > 50:
            ax.xaxis.set_ticks( np.arange(0, 2048, 50) )
            ax.yaxis.set_ticks( np.arange(0, 2048, 50) )
        else:
            ax.xaxis.set_ticks( np.arange(0, 2048, 25) )
            ax.yaxis.set_ticks( np.arange(0, 2048, 25) )

        ax.axis( xxrange + yyrange )

    plt.draw()

    # fig.tight_layout()
    plt.savefig('{1}/frame_{0:06d}.png'.format(i,outdir) )
    print 'saved', '{1}/frame_{0:06d}.png'.format(i,outdir)
