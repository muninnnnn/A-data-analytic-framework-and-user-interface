#!/usr/bin/env python

from error import eprint
from matplotlib import pyplot as plt
import numpy as np
import sys
import xml.etree.ElementTree
from util import XtoW

from worm_parse import ptsFromVtu
#def ptsFromVtu( filename ):
#    file = open(filename)
#
#    readingPoints = False
#    ptsData = []
#    readingW = False
#    WData = []
#    readingU = False
#    UData = []
#
#    for line in file.readlines():
#        if '<Points>' in line:
#            readingPoints = True
#            continue
#        if '</Points>' in line:
#            readingPoints = False
#            continue
#
#        if '<DataArray type="Float32" Name="W" NumberOfComponents="3">' in line:
#            readingW = True
#            continue
#
#        if '<DataArray type="Float32" Name="u" NumberOfComponents="1">' in line:
#            readingU = True
#            continue
#
#        if '</DataArray>' in line:
#            readingPoints = False
#            readingW = False
#            readingU = False
#            continue
#
#        if readingPoints and not 'DataArray' in line:
#            for d in line.split():
#                ptsData.append( float(d) )
#
#        if readingW and not 'DataArray' in line:
#            for d in line.split():
#                WData.append( float(d) )
#
#        if readingU and not 'DataArray' in line:
#            for d in line.split():
#                UData.append( float(d) )
#
#    nPts = len(ptsData)/3
#
#    X = [ np.array(ptsData[3*j:3*(j+1)]) for j in range(nPts) ]
#    W = [ np.array(WData[3*j:3*(j+1)]) for j in range(nPts) ]
#    U = UData
#
#    return [ X, W, U ]
#
#
#    print len(pts)

def norm( v ):
    s = sum( [_*_ for _ in v] )
    return np.sqrt(s)


def Rad( u, N ):
    D = 80e-3
    q = ( u - 0.5 ) / ( 0.5 + 0.2/N )
    return D/2.0*abs( np.sin( np.arccos( q ) ) )


outdir="."

from worm_parse import worm
def do_file(fn, k=0, outfn="cylinder.vtk"):
    eprint("doing file "+ fn)
    myworm = worm(fn)
    pts = myworm.pts()
    W = myworm.W()
    W = XtoW(pts)
    N = len(W)
    U = [ float(i)/float(N) for i in xrange(N) ]
    assert(N)

    T = np.linspace( 0, 2.0*np.pi, N, endpoint=True )

    pts3d = []
    Kangle = []
    from xwToMs import an_orthonormal
    E1 = an_orthonormal(pts[1]-pts[0])

    for j in range(N-1):
        t = pts[j+1] - pts[j]
        t = t / norm(t)

        if j == 0:
            n1 = np.cross( t, np.cross( E1, t ) )
            m1 = n1 / norm(n1)
            assert(norm(n1))
            assert(n1[0]==n1[0])
            assert(m1[0]==m1[0])
            m2 = np.cross( t, m1 )


            k1 = np.dot( W[j], m1 )
            k2 = np.dot( W[j], m2 )
            Kangle.append( np.arctan2( k1, k2 ) )

            for theta in T:
                #+ Rad(U[j], N) * ( np.cos(theta) * m1 + np.sin(theta) * m2 )
                newPt = pts[j] + Rad(U[j], N) * ( np.cos(theta) * m1 + np.sin(theta) * m2 )
                assert(newPt[0]==newPt[0])
                pts3d.append( newPt )

        m1 = np.cross( t, np.cross( m1, t ) )
        m1 = m1 / norm(m1)
        m2 = np.cross( t, m1 )
        k1 = np.dot( W[j], m1 )
        k2 = np.dot( W[j], m2 )
        Kangle.append( np.arctan2( k1, k2 ) )

        for theta in T:
            newPt = pts[j+1] + Rad(U[j+1], N) * ( np.cos(theta) * m1 + np.sin(theta) * m2 )
            pts3d.append( newPt )


    nPts = N
    cells = []
    for i in range(nPts-1):
        for j in range(nPts-1):
            cell = [ i+j*nPts, (i+1)+j*nPts,  (i+1)+(j+1)*nPts,  i+(j+1)*nPts ]
            cells.append(cell)


    with open( outfn,'w') as file:
        file.write('# vtk DataFile Version 2.0\n')
        file.write('my cool data\n')
        file.write('ASCII\n')
        file.write('DATASET UNSTRUCTURED_GRID\n')
        file.write('POINTS {0} float'.format( len(pts3d) ) )
        for pt in pts3d:
            file.write('  {0} {1} {2}'.format(pt[0],pt[1],pt[2]))
        file.write('\n')
        file.write('CELLS {0} {1}'.format( len(cells), 5*len(cells) ) )
        for c in cells:
            file.write('  4 {0} {1} {2} {3}'.format(c[0],c[1],c[2],c[3]))

        file.write('CELL_TYPES {0}'.format( len(cells) ) )
        for c in cells:
            file.write('  9')
        file.write('\n')

        file.write('POINT_DATA {0}\n'.format( len(pts3d) ) )
        file.write('VECTORS curvature float\n')
        for j in range(nPts):
            for theta in T:
                w = W[j]
                file.write( '  {0} {1} {2}'.format(w[0],w[1],w[2]))
        file.write('\n')

        file.write('SCALARS curvature_angle float 1\n')
        file.write('LOOKUP_TABLE default\n')
        for j in range(nPts):
            for theta in T:
                kangle = Kangle[j]
                file.write( '  {0}'.format(kangle))
        file.write('\n')

        file.write('TEXTURE_COORDINATES cylindrical_polar 2 float\n')
        for j in range(nPts):
            for theta in T:
                file.write('  {0} {1}\n'.format(U[j],theta))

        print 'written {0}'.format(outfn)

if __name__=="__main__":
	untested()

	import parameters
	parameters = parameters.parser( sys.argv )

	basename = parameters.pvd_dir + '/'
	outdir = parameters.output_dir + '/'

	mainPvd = xml.etree.ElementTree.parse( basename + 'skeletons_worm.pvd').getroot()[0].findall('DataSet')
	print 'read pvd file:', basename + 'skeletons_worm.pvd'

	E1 = np.array([1,0,0])
	for k,f in enumerate(mainPvd):
	    fn = basename + f.get('file')
	    outfn = outdir + '/' + 'cylinder_{0:06d}.vtk'.format(k)
	    do_file(fn, k, outfn)

# vim:ts=8:sw=4:et
