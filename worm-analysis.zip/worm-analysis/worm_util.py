
import numpy as np

def worm_length(x):
	if(not len(x)):
		return 0
	i=iter(x);
	last=next(i);
	L=0

	while(True):
		try:
			cur=next(i)
		except:
			break

		L+=np.linalg.norm(last-cur)
		last=cur
	return L


