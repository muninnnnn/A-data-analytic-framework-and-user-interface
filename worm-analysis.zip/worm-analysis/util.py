from error import eprint
import time
import numpy as np
import cmath
from numpy.lib.stride_tricks import as_strided

def _check_arg(x, xname):
	x = np.asarray(x)
	if x.ndim != 1:
		raise ValueError('%s must be one-dimensional.' % xname)
	return x

def fargmax(a):

	i = np.argmax(a)
	c = a[i-2:i+3]
	c/=np.sum(c)

	if(len(c)<5):
		# throw?
		return float('NaN')

	return i +c[2]-2*c[0]-c[1]+2*c[3]

# found on so
def correlate(x, y, maxlag):
    """
    Cross correlation with a maximum number of lags.

    `x` and `y` must be one-dimensional numpy arrays with the same length.

    This computes the same result as
        numpy.correlate(x, y, mode='full')[len(a)-maxlag-1:len(a)+maxlag]

    The return vaue has length 2*maxlag + 1.
    """
    x = _check_arg(x, 'x')
    y = _check_arg(y, 'y')
    py = np.pad(y.conj(), 2*maxlag, mode='constant')
    T = as_strided(py[2*maxlag:], shape=(2*maxlag+1, len(y) + 2*maxlag),
                   strides=(-py.strides[0], py.strides[0]))
    px = np.pad(x, maxlag, mode='constant')
    return T.dot(px)

def find_shift(a,b,maxlag=5):
	c=correlate(a,b,maxlag=maxlag)
	return fargmax(c)-maxlag-1

def find_angle(arr):
#   assert(not len(arr) % 2)

   i=np.argmax(arr)

   c=0.+0j
   for i, x in enumerate(arr):
      pos=float(i)/float(len(arr))
      c += cmath.exp(1j*pos*2.*np.pi) * x

   return np.angle(c)

def norm( v ):
	s = sum( [_*_ for _ in v] )
	return np.sqrt(s)

def maxindex_sq(l1, l2):
	r = 0
	m = l1[0]**2 + l2[0]**2
	
	for i in range(1, len(l1)):
		t = l1[i]**2 + l2[i]**2
		if t > m:
			m = t
			r = i
	return r

from math import atan2, sin, cos
def normalize_peakplane( m10, m20=[] ):

	if len(m20)==0:
		m20 = m10.imag
		m10 = m10.real
	j = maxindex_sq(m10, m20)
#	 print("MAXIND",j, m20[j], m10[j])
	theta = atan2( -m20[j], m10[j] );
	
	st=sin(theta)
	ct=cos(theta)
	
	m1 = np.array( [ ct * m10[k] - st * m20[k] for k in range(len(m10)) ] )
	m2 = np.array( [ st * m10[k] + ct * m20[k] for k in range(len(m10)) ] )
	
	return m1, m2, theta

def worm_center(w):
	a=np.zeros(3)
	cnt=0
	for i in w:
		cnt+=1
		a+=i
	a/=cnt
	return a

def tail(f, n, offset=0):
    """Reads a n lines from f with an offset of offset lines."""
    avg_line_length = 74
    to_read = n + offset
    while 1:
        try:
            f.seek(-(avg_line_length * to_read), 2)
        except IOError:
            # woops.  apparently file is smaller than what we want
            # to step back, go to the beginning instead
            f.seek(0)
        pos = f.tell()
        lines = f.read().splitlines()
        if len(lines) >= to_read or pos == 0:
            return lines[-to_read:offset and -offset or None]
        avg_line_length *= 1.3

def XtoW(X):
	wl = len(X)
	q = np.array( [0] + [ norm( X[i+1] - X[i] ) for i in range(wl-1) ] + [0] )
	M = np.array( [ .5*(q[i] + q[i+1]) for i in range(wl) ] )
	SX = np.array( [ (X[i] - X[i-1])/q[i] - (X[i+1] - X[i]) / q[i+1] for i in range(1, wl-1) ] )

#	print "M", M[0:3]
	W = np.zeros((wl,3))
	for i in range(1, wl-1):
		W[i] = - SX[i-1]/M[i]

#	print "q", q[0:3]
#	print "SX", SX
#	print "W", W[0:3]
	return W

# patricks worm rotator
# input: 2 numpy matrices with points (rows? cols?)
# output a rotation matrix
def rigid_transform_3D(A, B):
    start_time = time.time()
    assert len(A) == len(B)

    N = A.shape[0]; # total points

    centroid_A = np.mean(A, axis=0)
    centroid_B = np.mean(B, axis=0)

    # centre the points
    AA = A - np.tile(centroid_A, (N, 1))
    BB = B - np.tile(centroid_B, (N, 1))

    # dot is matrix multiplication for array
    H = np.transpose(AA) * BB

    U, S, Vt = np.linalg.svd(H)

    R = Vt.T * U.T

    # special reflection case
    if np.linalg.det(R) < 0:
       eprint("Reflection detected")
       Vt[2,:] *= -1
       R = Vt.T * U.T

    t = -R*centroid_A.T + centroid_B.T
    end_time = time.time()
    #eprint( "Enlapsed time: ", end_time - start_time)
    return R, t

def phase(mcv):
	import math
	ma = math.atan2(mcv.imag, mcv.real)
	return ma

