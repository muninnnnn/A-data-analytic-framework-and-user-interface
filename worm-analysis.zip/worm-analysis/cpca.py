#!/usr/bin/env python

import numpy as np

def ccov(X):
	"""
	complex covariance matrix. same as np.cov on real arrays.
	"""
	F=X.shape[1]
	return np.dot(X, np.conj(X.T))/(F-1.)

class PCA:
	def __init__(self):
		self._componets=[]

	def fit_full_(self, X):
		XT = X.T
		cc = ccov(XT)

		eigenvalues, eigenvectors = np.linalg.eig(cc)

		sort = eigenvalues.argsort()[::-1]
		eigenvalues = eigenvalues[sort]
		eigenvectors = eigenvectors[:,sort]

		# scikit style
		self.explained_variance_ = eigenvalues
		self.components_ = eigenvectors

def testit(phase):
	s = phase

	a = np.array([ 1j,0.,1. ] )
	b = s*np.array([ 0.,1.,0 ] )
	c = np.array([ -1.,0,0. ])
	d = np.array([ 0,-1,0.0000 ] )
	e = s*np.array([ 1.,0.,-1. ] )
	f = np.array([ -1.,0.,0.0000 ] )/s

	X = np.array([a,b,c,d,e,f])

	p = PCA()
	p.fit_full_(X)
	print(s)
	print p.explained_variance_
	print p.components_[0]

if __name__=="__main__":
	from math import cos, sin

	for i in range(10):
		s = sin(i)*1j + cos(i)
		testit(s)
