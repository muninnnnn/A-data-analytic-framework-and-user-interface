#!/usr/bin/env python
from sys import argv
from msToXw import msToXw
from vtu import print_vtu
from eigenworm import readEwMs

import numpy as np

if __name__=="__main__":

                pcaworms=readEwMs(argv[1])[1]
                numpca=len(pcaworms)
                print("number of pcaworms", numpca)

                for i,pca in enumerate(pcaworms):
                        print("len", len(pca))
                        m1 = pca.real
                        m2 = pca.imag

                        for j,l in [ [0,64.] ]: # enumerate(np.linspace(0,100,100)):
                                X, W = msToXw(l*m1,l*m2)
                                # plotwithframes(X,W,ax0,color=(l/100.0,0,0))
                                outfile= argv[1] + str(i) + '_' + str(l) + '.vtu'
                                with open( outfile, 'w' ) as f:
                                        print("writing to", outfile)
                                        print_vtu( X, f )


