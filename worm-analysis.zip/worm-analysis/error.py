
from __future__ import print_function

import sys

def eprint(*args, **kwargs):
	   print(*args, file=sys.stderr, **kwargs)

def printn(*args, **kwargs):
	for i in args: # , **kwargs)
		sys.stdout.write(str(i)) # , **kwargs)


class except_bad(BaseException):
	pass
