#!/usr/bin/env python

from __future__ import print_function
from worm_parse import pvdparse, wormindex
from sys import argv


def do_it(filename):
	index = wormindex(filename)
	o = open(filename[:-3]+"pvd", "w")

	o.write('<?xml version="1.0"?><VTKFile type="Collection" version="0.1" byte_order="LittleEndian"><Collection>\n')

	for i in index:
		o.write("<DataSet")

# BUG: paraview wantd "timestep"?
		o.write( ' timestep="' + i._dict["time"] + '"' )
		for j in i._dict.items():
			if j[0]=="filename":
				o.write( ' file="' + j[1] + '"' )
			elif j[0]!="time":
				o.write( " " + j[0] + '="' + j[1] + '"' )
		o.write( ' part="0"' )
		o.write( ' group=""' )

#     <DataSet timestep="0" group="" part="0"
             # file="projected_skeletons_cam1_worm_000000.vtu"/>
		o.write("/>\n")

	o.write("</Collection></VTKFile>\n")

for i in (argv[1:]):
	if(i[-3:] == "txt"):
		print("doing", i)
		do_it(i)
	else:
		print("cowardly refusing to touch", i)
