from numpy import array, zeros_like
from error import eprint
from xwToMs import normalize_peakplane

# read eigenworm ms.
def readEwMs(filename, force_cplx=False, normalize=False):

	f = open(filename)
	cplx=force_cplx

	PCAs=[]
	mean=[]
	for line in f:
		if line[:9]=='# COMPLEX':
			cplx = True
		elif line[:7] == '# mean ':
			line = line[7:]
			meanraw = array( [ float(x) for x in line.split(" ") ] )

			s = len(meanraw)
			assert(s==256) # incomplete

			ar = meanraw[0:s//2]
			ai = meanraw[s//2:]

			# ar, ai, t = normalize_peakplane(ar, ai)
			# print t

			mean=ar + 1j*ai
			continue
		else:
			pass

		if line[0]=='#':
			continue
		else:
			pass
	
		# print line[0:40]
		arr=array( [ float(x) for x in line.split(" ") ] )

		if cplx:
			eprint("eigenworm, complex, normalize_peakplane...")
			s = len(arr)
			assert(not s%2)
			ar = arr[0:s//2]
			ai = arr[s//2:]

			ar, ai, t = normalize_peakplane(ar, ai)
			# print t

			arr=ar + 1j*ai

		# print len(arr)
		PCAs.append( arr )

	A = array(PCAs)
	if(not len(mean)):
		mean = zeros_like(A[0])
	return mean, A
