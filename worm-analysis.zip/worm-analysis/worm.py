#!/usr/bin/env python3

# HACK
from worm_parse import *
from math import sqrt

import numpy as np

from worm_parse import ptsFromVtu
from util import find_shift

class worm:
	def __init__(self, fn, tags=None):
		self._coeffs=[]
		self._fn = fn
		self._len = None
		self._Xr=[]
		self.X, self._W, self._U, self._data = wormFromVTU( fn )

		self._has_tags = bool(tags)
		self._flip = isflipped(tags)
		self._gait = gait(tags)
		self._good_cog = good_cog(tags)
		# self._direction = direction(tags)
		self._pca_var_r = None

		if self._flip:
			# eprint("flipping worm in parse")
			self.X = self.X[::-1]
			self._W = self._W[::-1]
			self._U = self._U[::-1]
		else:
			pass

	def get_value(self, key):
		try:
			return self._data[key]
		except:
			eprint("i do not know", key)
			throw

	def length(self):
		if not self._len:
			self._len = 0.
			last = None
			for i in self.pts():
				if not last is None:
					self._len+=np.linalg.norm(last-i)
				last=i;

		return self._len

	def flipped(self):
		return self._flip

	def has_tags(self):
		return self._has_tags

	def direction(self):
		if(self._gait & 128):
			return WORM_STILL
		elif(self._gait & 1024):
			return WORM_FWD
		elif(self._gait & 4096):
			return WORM_BACK
		else:
			# eprint("no direction here?!\n")
			return WORM_ERROR

	def gait(self):
		return self._gait

	def is_planar(self):
		return self._gait & 4
	def is_helix(self):
		return self._gait & 1

	def directionstring(self):
		if(self._gait & 128):
			return "still"
		elif(self._gait & 1024):
			return ">"
		elif(self._gait & 2096):
			return "<"
		else:
			return "?"

	def gaitstring(self):
		s=""
		if self._gait==256:
			return "invalid gait"
		for i in range(5):
			if self._gait & (2**i):
				# eprint("found gait", i)
				s += " " + gaitname[i]
		if s=="":
			s = "no gait " + str(self._gait)
		return s

	def U(self):
		return self._U
	def W(self):
		if len(self._W)==0:
			self._W = XtoW(self.pts())
		elif len(self._W[0])==0:
			self._W = XtoW(self.pts())

		return self._W

	def pts(self):
		return self.X
	# BUG
	# def X(self):
	#	return self._X

	def Mt(self, cplx=False):
		M, t = xwToM(self.X, self._W, cplx)
		return M, t

	def total_twist(self):
		return total_twist(self.pts(), self.W())

	def max_curvature(self):
		m = 0;
		for i in self.W():
			if norm(i)>m:
				m = norm(i)
		return m

	def set_framenumber(self, x):
		self._framenumber=x
	def get_framenumber(self):
		return self._framenumber


	def pcamidline(self):
		if(self._pca_var_r is None):

			points = self.pts()
			# not necessary, really
			# points /= self.length()

			pca = PCA(n_components=3)
			pca.fit(points, 3)

			# these sum to 1
			self._pca_var_r = pca.explained_variance_ratio_
			self._pca_var = pca.explained_variance_
			self._pca_sv = pca.singular_values_

	def planarity(self):
		self.pcamidline()
		r = self._pca_var_r

		return r[2]/np.sqrt(r[1]*r[0])

	def dist_to_plane(self):
		self.pcamidline()
		r = self._pca_var

		return sqrt(r[2]/ ( r[0] + r[1] ) )

	def dist_to_line(self):
		self.pcamidline()
		r = self._pca_var

		return sqrt( ( r[2]+r[1]) / r[0] )

	def linearity(self):
		self.pcamidline()
		r = self._pca_var_r
		return np.sqrt(r[1]*r[2]) / r[0]

	def wave_speed(self, w1):
		if(w1 is None):
			return float('NaN')

		m0 = np.linalg.norm(self.W(),axis=1)
		m1 = np.linalg.norm(w1.W(),axis=1)

		s = find_shift(m0,m1,30)/128.
		return s

	def oldplanarity(self):
		points=self.pts()
		mean = np.mean(points, axis=0)

		from soPCA import PCA
		w, v = PCA(points, True)
		normal = v[:,2]
		#print("normal", normal, len(points))

		err = 0.
		for p in points:
			delta = p - mean
			sp = np.dot(delta, normal)
			err += sp*sp

		return err
			
	def framecomm(self, prev):
		from xwToMs import nextFrame, an_orthonormal
		Xo =  prev.pts() ## <= DEBUGGING. need prev here.
		X = self.pts()

		# start with v=(0,1,0) in prev worm bishop frame
		vb = np.array([0.,1.,0.])

		# space frame of prev worm
		tauso = Xo[1] - Xo[0]
		tauso = tauso/norm(tauso)
		n1so = an_orthonormal(tauso)
		n2so = np.cross(tauso, n1so)

		# shift through time. incomplete. need 3 worms...
		tauth = X[1] - X[0]
		tauth = tauth/norm(tauth)
		n1th = an_orthonormal(tauth)
		n2th = np.cross(tauth, n1th)


		Tvb = np.array(  [
			np.dot(tauth, n1so),
			np.dot(n1th, n1so),
			np.dot(n2th, n1so),
			])

		# move the frame along the previous worm.
		x1 = Xo[0]
		for x in Xo[2:]:
			n1so, n2so = nextFrame(n1so, n2so, x - x1)
			x1 = x

		x1 = X[0]
		for x in X[2:]:
			n1th, n2th = nextFrame(n1th, n2th, x - x1)
			x1 = x

		Svb = [0.,1.,0.]
		Sv = n1th # v shifted along the worm
		TSv = n1th # Sv shifted through time (incomplete)
		
		tautail = (X[-1] - X[-2])
		tautail = tautail/norm(tautail)
		STv = Tvb[0] * tautail + Tvb[1] * n1th + Tvb[2] * n2th

		return TSv, STv


	def pca_coeffs(self, pcasys, cplx=False):
		assert(len(pcasys)==2)
		pcamean = pcasys[0]
		pcaworms = pcasys[1]
		if np.iscomplexobj(pcaworms):
			#eprint("got complex eigenworms")
			cplx=True
		elif cplx:
			eprint("force complex")
			pw=[]
			for PW in pcaworms:
				pw.append(PW[:nh] - 1j*PW[nh:])
			pcaworms=pw
		else:
			eprint("real eigenworms")

		M, j = xwToM(self.X, self._W, cplx)
		M -= pcamean

		if cplx:
			n = len(M)

			# eprint(n,len(pcaworms[0]))
			assert(n==len(pcaworms[0]))

			coeffs=[]
			for PW in pcaworms:
				coeffs.append( np.dot(np.conj(PW), M) )

			coeffs=np.array(coeffs)
			return coeffs

		else: # real
			coeffs=np.array( [ np.dot(PW, M) for PW in pcaworms ] )
			return coeffs

	# toms new reconstruct from head
	def pca_reconstruct_tom(self, pcasys, cplx=False):
		pcamean = pcasys[0]
		pcaworms = pcasys[1]
		X = self.pts()

		if np.iscomplexobj(pcaworms):
			cplx = True

		#print("PTS\n", X[:3])
		m1, m2, nu = xwToMs(X, self._W)
		
		Mproj = m1+1j*m2 # for bypass

		if(len(pcaworms)):
			#if !self._coeffs
			coeffs = self.pca_coeffs(pcasys, cplx)
			Mproj = np.zeros_like(pcaworms[0])
			Mproj += pcamean

			for i in range(len(coeffs)):
				Mproj = Mproj + coeffs[i] * pcaworms[i]
		else:
			cplx=True

		l = len(X)
		mid1 = l//2
		mid2 = mid1-1

		tau = X[1] - X[0]
		tau *= l-1
		Xr, w = mToXw(Mproj, tau, nu, X[0])

		self._Xr = Xr;
		return Xr

	def pca_reconstruct(self, pcasys, cplx=False):
		pcamean = pcasys[0]
		pcaworms = pcasys[1]
		X = self.pts()

		if np.iscomplexobj(pcaworms):
			cplx = True

		#print("PTS\n", X[:3])
		m1, m2, nu = cXwToMs(X, self._W)
		
		Mproj = m1+1j*m2 # for bypass

		if(len(pcaworms)):
			#if !self._coeffs
			coeffs = self.pca_coeffs(pcasys, cplx)
			Mproj = np.zeros_like(pcaworms[0])
			Mproj += pcamean

			for i in range(len(coeffs)):
				Mproj = Mproj + coeffs[i] * pcaworms[i]
		else:
			cplx=True

		l = len(X)
		mid1 = l//2
		mid2 = mid1-1

		tau = X[mid1] - X[mid2]
		center = (X[mid1] + X[mid2]) / 2.
		tau *= l-1
		Xr, w = cMToXw(Mproj, tau, nu, center)

		self._Xr = Xr;
		return Xr

	def pca_quality(self, pcaworms):
		if not len(self._Xr):
			self._Xr = self.pca_reconstruct(pcaworms)

		return point_distance(self.X, self._Xr)
		return total_displacement(self.X, self._Xr)

	def rigid_quality(self, pcaworms=[]):
		if len(pcaworms):
			self._Xr = self.pca_reconstruct_tom(pcaworms)

		pts = np.matrix(self.pts())
		reconstruction = np.matrix(self._Xr)
		r, t = rigid_transform_3D(reconstruction, pts)

		optimal = (r*self._Xr.T) + np.tile(t, (1, len(self._Xr)))
		optimal = np.array(optimal.T)

		return point_distance(self.X, optimal)

	def head(self):
		return self.pts[0]
	def tail(self):
		return self.pts[-1]
	def good_cog(self):
		return self._good_cog
	def centroid(self, ignore_bad=False):
		if ignore_bad:
			pass
		elif not self._good_cog:
			raise except_bad()

		c = np.zeros(3)
		for i in self.X:
			c += i
		if not len(self.pts()):
			eprint("ERROR in " + self._fn)
			return c
		return c/self.N()

	def center_of_gravity(self, ignore_bad=False):
		return self.centroid(ignore_bad)
	
	def N(self):
		return len(self.pts())
	def center(self):
		eprint("deprecated, use cog")
		return self.center_of_gravity()

	def XWU(self):
		return self.X, self._W, self._U

if __name__ == "__main__":
	from sys import argv
	fn = argv[1]
	print("reading", fn)
	w = worm(fn)

	print("length:", w.length())
	print("dist_to_line:", w.dist_to_line())
	print("dist_to_plane:", w.dist_to_plane())
	print("twist:", w.total_twist())
	print("var:", w._pca_var)
	print("var:", w._pca_var_r)
	#print("1dness:", w.one_d_ness())
