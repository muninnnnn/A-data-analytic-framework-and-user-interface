# README #

Some python scripts to help analyse midline curve data.

Only works with python-2 at the moment and needs checking for using on `marc1`/`arc2`.

create PCA from tagged frames
./pvdPCA_tag.py /nobackup/scsrih/video/annotations/N2_0_75pc_20160427_trial0*.csv > 0_75.pca

get freq and lambdas from planar tagged clips.

 ( for i in ../worm-data/tags/N2_1_00pc_*.csv ; do ./curvature-plot.py -p -b foo $i; done ) 2>/dev/null | tee 1_00_planars.out

turns.py: add turns to trajectory

see Makefile for more targets.
