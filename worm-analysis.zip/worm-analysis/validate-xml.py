import sys, xml.dom.minidom as d
from shutil import copyfile

def validate( fn ):
    try:
        d.parse(fn)
        return 1
    except:
        return 0

myfile = sys.argv[1]

if validate( myfile ):
    print('xml file is ok')
else:
    print('xml file is not ok')
    copyfile(myfile, myfile + '.orig')

    file = open(myfile,'a')
    file.write('  </Collection>\n')
    file.write('</VTKFile>\n')

if validate( myfile ):
    print('xml file is fixed!')
else:
    print('xml file is horribly wrong!')



