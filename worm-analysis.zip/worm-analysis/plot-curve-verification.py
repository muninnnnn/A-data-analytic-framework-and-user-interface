#!/usr/bin/env python

from error import except_bad
import matplotlib as mpl
mpl.use('agg')
import math
from math import pi, sin, cos
from matplotlib import pyplot as plt
from matplotlib import gridspec
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from numpy.linalg import norm
from matplotlib.backend_bases import NavigationToolbar2, Event
import matplotlib.image as mpimg
import xml.etree.ElementTree
import sys
from sys import argv
import os
import getopt
from worm_parse import pvdparse, worm
import cv2
from error import eprint

from util import tail
from pvdTD import total_displacement
from pvdSD import self_dist_min
from worm_util import worm_length
from project import project32

# this is incomplete. use getopt below.
import parameters

eprint("OBSOLETE script")

parameters = parameters.parser(argv)

pvdDirname = parameters.pvd_dir + '/'
outdir = parameters.output_dir + '/'

from colormaps import phasecolor

def plot_midline_projection(X, cam, ax):
		pts = []
		#for ww in X:
		#	px = ps.p(ww, cam)
		#	pts.append(px)
		pts = np.array(pts)

		try:
			x,y = zip(*pts)
		except:
			eprint("errr nocam", cam) # excepton?
			return

		xmiddle = (max(x)+min(x)) / 2
		ymiddle = (max(y)+min(y)) / 2
		xyrange = max( [ max(x) - min(x), max(y) - min(y) ] ) + 10
		xxrange = [ xmiddle - xyrange, xmiddle + xyrange ]
		yyrange = [ ymiddle - xyrange, ymiddle + xyrange ]

		for j in range(len(x)-1):
			# print(j)
			 #color = ( 0., U[j], 1-U[j], 1.0 )
			ax.plot( [x[j],x[j+1]], [y[j],y[j+1]],
					 color = "blue",  linewidth=1, alpha=0.3 )

		# TODO: fallback
		if 2*xyrange > 100:
			ax.xaxis.set_ticks( np.arange(0, 2048, 100) )
			ax.yaxis.set_ticks( np.arange(0, 2048, 100) )
		elif 2*xyrange > 50:
			ax.xaxis.set_ticks( np.arange(0, 2048, 50) )
			ax.yaxis.set_ticks( np.arange(0, 2048, 50) )
		else:
			ax.xaxis.set_ticks( np.arange(0, 2048, 25) )
			ax.yaxis.set_ticks( np.arange(0, 2048, 25) )

		ax.axis( xxrange + yyrange )

# BUG: pass pvd as arg
# or tagfile?!
pvdFile = pvdDirname + '/skeletons_worm.pvd'

cam1=""
cam2=""
cam3=""
pcaFile=""
tagsfile=""

noplot=False

def isflipped(t):
	id=4
	try:
		print("isflipped? ", t[id])
	except:
		pass
	if(not t):
		return False
	print("isfl2", t)
	if len(t)<=id:
		return False
	if type(t[id])==str and len(t[id]) and t[id][0]=="1":
		return True
	if t[id]==1:
		return True
	return False

def usage():
	print("incomplete")

try:
	# the first few have been done by "parameter"
	opts, args = getopt.getopt(argv[1:], "w:x:y:z:p:C:L:",
			 ["pvddir=", "framesdir=", "outdir=", "tags="])
	print("opts", opts, "args", args)
except getopt.GetoptError as err:
	#incomplete
	# print(help information and exit:
	print(str(err))  # will print something like "option -a not recognized"
	usage()
	sys.exit(2)

print("opts", opts)

calibrationfile=""
layout="all"

for o, a in opts:
	print("parse", o, a)
	if o == "-v":
		verbose = True
	elif o in ("-n"):
		noplot = True
	elif o in ("-L"):
		layout = a
	elif o in ("-x"):
		cam1 = a
	elif o in ("-y"):
		cam2 = a
	elif o in ("-z"):
		cam3 = a
	elif o in ("-C"):
		calibrationfile = a
	elif o in ("-w"):
		pvdFile=a
	elif o in ("-p"):
		pcaFile=a
	elif o in ("--pvddir"):
		pvdDirname=a
	elif o in ("--outdir"):
		outdir=a
	elif o in ("--tagsfile"):
		tagsfile=a

ps = project32(calibrationfile)

# pvdDirname=os.path.dirname(pvdFile)

from frame_tags import make_frame_tags
tags=make_frame_tags(tagsfile)

# print "pvdDirname", pvdDirname

# strip the last character
videoName = os.path.basename(pvdDirname)

# Set up axes and plot some awesome science

nCam = 3
camRange = range( 0, nCam )

fig = plt.figure(facecolor='white')


if(layout=="all"):
	gs = gridspec.GridSpec(3, 4)
	ax3d = fig.add_subplot(gs[0:3,0:3], projection='3d')
	camAxs = [ fig.add_subplot(gs[c,3]) for c in camRange ]
elif(layout=="2D"):
	gs = gridspec.GridSpec(2, 2)
	for c in camRange:
		print("slot", c%2,c//2)
	camAxs = [ fig.add_subplot(gs[c%2,c//2]) for c in camRange ]


def setupAxis( cam, ax, i ):
	if cam < 0:
		ax3d.set_xlabel( 'mm' )
		ax3d.set_ylabel( 'mm' )
		ax3d.set_zlabel( 'mm' )
		# ax.view_init(elev=20., azim=70 + i)
		# ax.grid(False)
	else:
		ax.set_xlabel( 'Pixels' )
		ax.set_ylabel( 'Pixels' )
		# ax.set_title( "Camera View {0}".format(cam+1), fontsize=9 )

gs.update(wspace=0.5, hspace=0.5)

mainPvd = pvdparse(pvdFile)

cam = [cam1, cam2, cam3]
print("camera videos ", cam)
vidcap = [ cv2.VideoCapture(cam[i]) for i in camRange ]
print("did cap", cam)
captured_frames = [False] * len(camRange)

success=True
def getframe():
	global captured_frames
	try:
		triplet=[]
		s=True
		for i in camRange:
			if not vidcap[i].isOpened():
				continue

			s,f=vidcap[i].read()
			if not s:
				if(i==0):
					eprint("something WRONG")
				eprint("done reading in frames")
				break
			sys.stdout.write('.')
			sys.stdout.flush()
			cv2.resize(f, (800, 600))
			triplet.append(f)
		if not s:
			return
		captured_frames = triplet
	except IOError:
		print("something went wrong")
		return
		pass

print("")

# this does not really work.
def get_energy(i,a):
	dir=pvdDirname
	en=0
	efn='energy_frame_'+str(i)+'.txt'
	# print(efn)

	try:
		ef=open(dir+'/'+efn, 'r')
		el=-1
		es=[-1,-1,-1,-1,-1]
		try:
			el=tail(ef,1)[0]
			es=el.split(",")
		except:
			pass
		for ii in (1,2,3,4,5):
			try:
				f=float(es[ii])
			except IndexError:
				print(es)
				f=1e99;

			en+=f

	except IOError:
		en=1e99
	
	return en


currentframe=-1
def frames(i):
	global currentframe
	global captured_frames
	if i>currentframe:
		getframe()
	currentframe+=1

	return(captured_frames)
	return [ captured_frames[c] for c in camRange ]

im0 = None
ims = [ None for _ in camRange ]

from worm_parse import ptsFromVtu

td=0;
pts=[]

from detectPCA import readEwMs
from xwToMs import xwToMs, xwToM
from msToXw import mToXw
numpca = 0
pcaworms = []
pcaPlot = None

if pcaFile:
	print("fetching PCA from " + pcaFile)
	pcamean, pcaworms = readEwMs(pcaFile)
	numpca = len(pcaworms)
	if(layout=="2D"):
		pcaPlot = fig.add_subplot(gs[1,1])
	else:
		pcaPlot = fig.add_subplot(gs[2,0])

	print("found", numpca, " eigenworms")
	#print type(pcaworms)
	#print pcaworms.dtype
else:
	print("no PCA")

def plot_worm_3d(myworm, U, ax3d, pca, cog_hist):
	for j in range(len(myworm.X)-1):
		X = myworm.pts()
		U = myworm.U()
		ax3d.plot( [X[j][0],X[j+1][0]], [X[j][1],X[j+1][1]], [X[j][2],X[j+1][2]],
				  color = ( 0., U[j], 1-U[j], 1.0 ), linewidth=5 )


	try:
		c = myworm.centroid();
		ax3d.scatter( c[0], c[1], c[2], color='red' )
		for i in cog_hist:
			ax3d.scatter( i[0], i[1], i[2], color='orange' )
	except:
		pass

pindex=0

def plot_pca( P, myworm):
	if ""==pcaFile:
		return -1

	W = myworm.W()
	X = myworm.pts()


	P.cla()
	P.set_ylim([-100.,100.])
	# M, nu = xwToM(X, W)

	coeffs = myworm.pca_coeffs([pcamean, pcaworms])
	Xr = myworm.pca_reconstruct([pcamean, pcaworms])

	if(not np.iscomplexobj(coeffs)):
		P.bar( range(numpca), coeffs )
		pass
	else:
		P.set_ylim([0,60])
		color=[phasecolor(0)]

		prev=coeffs[0]
		for i in coeffs[1:]:
			color.append( phasecolor(i / prev ) )
			prev=i

		P.bar( range(numpca), [norm(i) for i in  coeffs], color=color)
		# P.bar( range(numpca), [phase(i) for i in  coeffs] )
	
	for j in range(len(Xr)-1):
	   errc = 0
	#	min(1, 4*norm(Xr[j]-X[j])
	#		 + 4*norm(Xr[j+1]-X[j+1]))
	   ax3d.plot( [Xr[j][0], Xr[j+1][0]], \
					 [Xr[j][1], Xr[j+1][1]], \
					  [Xr[j][2], Xr[j+1][2]], \
				  color = ( errc, 0, errc ) , linewidth=1)

	return


cog1=[]
cog_hist=list()

for i,a in enumerate(mainPvd):

	# get main points
	if(layout=="all"):
		ax3d.cla()
		setupAxis( -1, ax3d, i )

	time = mainPvd[i].get('timestep')
	fn = pvdDirname + '/' + mainPvd[i].get('file')
	
	pts,W,U = ptsFromVtu( fn )

	# flip=isflipped(tags.get_tag(i))

	myworm = worm(fn, tags.get_tag(i))

	pts = myworm.pts()
	W = myworm.W()
	U = myworm.U()

	try:
		cog = myworm.centroid()
	except except_bad:
		cog = None

	WL = worm_length(pts)
	SD = self_dist_min(pts,20)
	tdt = tdh = -1
	dirstring=""

	if(i):
		td=total_displacement(pts, pts1)
		tdh = norm(pts[0] - pts1[0])
		tdt = norm(pts[-1] - pts1[-1])
		ht = pts[0] - pts[-1]

		direction=0
		if(cog is None):
			pass
		else:
			gd = cog-cog1
			direction=np.dot(ht, gd)

		dirstring="?"
		if direction>0:
			dirstring="fwd"
		elif direction<0:
			dirstring="bwd"


	pts1 = pts

	try:
		x,y,z = zip(*pts)
	except:
		x,y,z = [],[],[]

	try:
		energ = float( mainPvd[i].get('energy') )
		iter = int( mainPvd[i].get('iter') )
		framenumber = int( mainPvd[i].get('frame') )
	except:
		energ=get_energy(i,a)
		framenumber = -1
		iter = -1

	pcaTD = 0
	if(layout=="all"):
		plot_worm_3d(myworm, U, ax3d, pcaFile, cog_hist)
		pcaTD = plot_pca(pcaPlot, myworm)
		pcaTD = myworm.pca_quality(pcaworms)

	cog1 = cog;
	if(len(cog_hist)>9):
		cog_hist.pop(0)
	cog_hist.append(cog)


	if(noplot):
		eprint("plotbypass")
	#HACL. bypass plotting.
		continue

	headline = '{0} Time: {1} Frame: {2} Iter: {8} Energy: {3:E} tags: {12} dir: {11}\n'\
			   'LEN: {4:.2f} TD: {5:.2f} TDH: {9:.2f} TDT: {10:.2f} SD: {6:.2f} PCATD: {7:.2f}'.\
				 format(videoName, time, framenumber, energ, WL, td, SD, \
						pcaTD, iter, tdh, tdt, dirstring, myworm.has_tags())

	tagstring = myworm.directionstring() + " " + myworm.gaitstring()
	if i == 0:
		supt = fig.suptitle(headline)
		ttext = plt.figtext(0., .8, tagstring)
	else:
		supt.set_text( headline)
		ttext.set_text(tagstring)

	minx = min( [ pt[0] for pt in pts ] )
	maxx = max( [ pt[0] for pt in pts ] )
	miny = min( [ pt[1] for pt in pts ] )
	maxy = max( [ pt[1] for pt in pts ] )
	minz = min( [ pt[2] for pt in pts ] )
	maxz = max( [ pt[2] for pt in pts ] )

	maxRange = max( [ maxx-minx, maxy-miny, maxz-minz] ) / 2.0

	newxRange = [ (minx+maxx)/2.0 - maxRange,  (minx+maxx)/2.0 + maxRange ]
	newyRange = [ (miny+maxy)/2.0 - maxRange,  (miny+maxy)/2.0 + maxRange ]
	newzRange = [ (minz+maxz)/2.0 - maxRange,  (minz+maxz)/2.0 + maxRange ]

	if(layout=="all"):
		for xb, yb, zb in zip( newxRange, newyRange, newzRange ):
			ax3d.plot( [xb], [yb], [zb], 'w' )

		ax3d.set_xticks( np.linspace( np.ceil( newxRange[0]/0.25)*0.25,
									 np.floor( newxRange[1]/0.25)*0.25,
									 int( np.floor( newxRange[1]/0.25) - np.ceil( newxRange[0]/0.25) )+1,
									 endpoint=True ) )
		ax3d.set_yticks( np.linspace( np.ceil( newyRange[0]/0.25)*0.25,
									 np.floor( newyRange[1]/0.25)*0.25,
									 int( np.floor( newyRange[1]/0.25) - np.ceil( newyRange[0]/0.25) )+1,
									 endpoint=True ) )
		ax3d.set_zticks( np.linspace( np.ceil( newzRange[0]/0.25)*0.25,
									 np.floor( newzRange[1]/0.25)*0.25,
									 int( np.floor( newzRange[1]/0.25) - np.ceil( newzRange[0]/0.25) )+1,
									 endpoint=True ) )

	# 2d projections
#	eprint("projections", camRange, len(ims), len(camAxs))
	for cam, f, im, ax in zip( camRange, frames(i), ims, camAxs ):
		frame = f.copy()

		ax.cla()
		setupAxis( cam, ax, i )
		im = ax.imshow( frame )

		try:
			whitePoints = np.genfromtxt(
					pvdDirname + '/distance_cam{0}_frame_{1}.csv'.format( cam, i ),
										 delimiter=',', skip_header=1 )
			ax.scatter( whitePoints.T[0], whitePoints.T[1], color='r', lw=0, s=1 )
		except:
			print(pvdDirname)
			print(cam)
			print(i)
			print('unable to plot whitePoints from ', pvdDirname
					+ '/distance_cam{0}_frame_{1}.csv'.format( cam, i ))

#		eprint("frame " + str(i) + "\n")

# === these are the projected skeletons
		W = []
		U = []

		plot_midline_projection(myworm.X, cam, ax)


		if(cog is None):
			pass
		#else:
		#	px = ps.p(cog, cam)
		#	ax.scatter( px[0], px[1], color="#44ff44", s=5)


	plt.draw()

	# fig.tight_layout()
	outframe=('{1}/frame_'+layout+'{0:06d}.png').format(i,outdir)
	plt.savefig(outframe)
	print('saved ', outframe)
