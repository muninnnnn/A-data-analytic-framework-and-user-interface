from shutil import copyfile
import os

cylinderHome='/home/cserv1_a/soc_staff/scstr/biosys2/3D_Data/valid_vids/'

infile=open('interesting-sections.txt','r')
for line in infile.readlines():
    trialId = line.split(':')[0]
    frameRange = line.split(':')[1]
    startFrame = int(frameRange.split('-')[0])
    endFrame = int(frameRange.split('-')[1])

    print trialId, startFrame, endFrame
    outdir = trialId + '_{}-{}'.format(startFrame, endFrame)
    for i in xrange(startFrame, endFrame):
        copyfile( os.path.join( cylinderHome, trialId, 'cylinder_{:06d}.vtk'.format(i)), os.path.join( outdir, 'cylinder_{:06d}.vtk'.format(i)) )
