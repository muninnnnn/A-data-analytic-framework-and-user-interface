import numpy as np
import xml.etree.ElementTree
import os

def readTrajectoryFile( fn, start, end ):
    data = np.loadtxt(fn, delimiter=',')

    frame_number = data.T[0][start:end]
    time = data.T[1][start:end]
    x = data.T[2][start:end]
    y = data.T[3][start:end]
    z = data.T[4][start:end]

    return frame_number, time, x, y, z

trajHome = '/home/csunix/scstr/biosys2/3D_Data/analysis/223137/'

infile=open('interesting-sections.txt','r')
for line in infile.readlines():
    trialId = line.split(':')[0]
    frameRange = line.split(':')[1]
    startFrame = int(frameRange.split('-')[0])
    endFrame = int(frameRange.split('-')[1])

    print trialId, startFrame, endFrame

    outdir = trialId + '_{}-{}'.format(startFrame, endFrame)
    if not os.path.exists(outdir):
        os.makedirs(outdir)

    trajFile = os.path.join( trajHome, trialId + '_traj_output.csv' )
    frames, times, x, y, z = readTrajectoryFile( trajFile, startFrame, endFrame )
    nTimes = len(frames)

    outfile = open( os.path.join( outdir, 'midpoints.vtu'),'w')
    outfile.write("""<?xml version="1.0"?>
    <VTKFile type="UnstructuredGrid" version="0.1" byte_order="LittleEndian">
      <UnstructuredGrid>
        <Piece NumberOfPoints="{0}" NumberOfCells="{1}">
    """.format(nTimes, nTimes-1))
    outfile.write('      <PointData Scalars="time">\n')
    outfile.write('        <DataArray type="Float32" Name="time" NumberOfComponents="1">\n')
    outfile.write('         ')
    for time in times:
        outfile.write(' {}'.format(time))
    outfile.write('\n')
    outfile.write('        </DataArray>\n')
    outfile.write('      </PointData>\n')

    outfile.write("""      <Points>
            <DataArray type="Float32" NumberOfComponents="3" format="ascii">
    """)

    for xx,yy,zz in zip(x,y,z):
        outfile.write('{} {} {}\n'.format(xx,yy,zz))

    outfile.write("""        </DataArray>
          </Points>
    """)
    outfile.write('      <Cells>\n')
    outfile.write('        <DataArray type="Int32" Name="connectivity" format="ascii">\n')
    for i in range(nTimes-1):
        outfile.write(' {} {}'.format(i,i+1))
    outfile.write('        </DataArray>\n')

    outfile.write('        <DataArray type="Int32" Name="offsets" format="ascii">\n')
    for i in xrange(1,nTimes):
        outfile.write(' {}'.format(2*i))
    outfile.write('        </DataArray>\n')

    outfile.write('        <DataArray type="Int32" Name="types" format="ascii">\n')
    for i in range(nTimes):
        outfile.write(' {}'.format(3))
    outfile.write('        </DataArray>\n')

    outfile.write("""      </Cells>
        </Piece>
      </UnstructuredGrid>
    </VTKFile>""")
