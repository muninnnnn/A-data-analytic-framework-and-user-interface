#!/bin/bash

for dir in N2_*
do
    ffmpeg -framerate 25 -y -i ${dir}/white.%04d.png -c:v libx264 ${dir}_white.avi
    ffmpeg -framerate 25 -y -i ${dir}/curvature_blue.%04d.png -c:v libx264 ${dir}_curvature.avi
done
