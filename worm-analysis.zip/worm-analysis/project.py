#!/usr/bin/env python3

from error import eprint
import subprocess
from subprocess import PIPE

class project32:
	def __init__(self, cf):

		self._p=[]
		args = ["project", cf, "1"]
		self._p.append( subprocess.Popen(args, stdin=PIPE, stdout=PIPE))
		args[2] = "2"
		self._p.append( subprocess.Popen(args, stdin=PIPE, stdout=PIPE))
		args[2] = "4"
		self._p.append( subprocess.Popen(args, stdin=PIPE, stdout=PIPE))

		self._off=[[ 0., 0.], [0.,0.], [0.,0.] ]

	def set_offset(self, i, o):
		self._off[i][0] = o[0]
		self._off[i][1] = o[1]

	def p(self, X, cam):
		s = str(X[0]) + " " + str(X[1]) + " " + str(X[2]) + " \n"
		self._p[cam].stdin.write(bytes(s, 'utf8'))
		self._p[cam].stdin.flush()
		a = self._p[cam].stdout.readline()[:-1]
		a = a.decode("utf-8")
		a = a.split(" ");
		off = self._off[cam]
		try:
			return float(a[0])+off[0], float(a[1])+off[1]
		except:
			return 1e99, 1e99
	

if __name__=="__main__":
	cf = "../worm-data/calib/20160715/new-calibration-3d.xml"
	cf = "../worm-data/calib/6_3d.xml"
	p=project32(cf)

	print(p.p([3.11,-1.2,1609],0))
	print(p.p([3.11,-1.2,1609],1))
	print(p.p([3.11,-1.2,1609],2))

	cf = "../worm-data/calib/6_alt_constrained.xml"
	q=project32(cf)

	print(q.p([-1.2,3.11, 1609],0))
	print(q.p([-1.2,3.11, 1609],1))
	print(q.p([-1.2,3.11, 1609],2))

