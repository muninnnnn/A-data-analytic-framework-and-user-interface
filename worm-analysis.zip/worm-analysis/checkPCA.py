#!/usr/bin/env python
from __future__ import print_function
from sys import argv
from msToXw import msToXw
import numpy as np
from math import sqrt
from eigenworm import readEwMs
from error import printn
from numpy.linalg import norm

# compute the distance of q to span(P)
def subspace_distance(P, q):
	for p in P:
		q -= np.dot(q, np.conj(p)) * p

	return norm(q)

def conj_check(P):
	print("distance to realness")
	for i in range(len(P)):
		printn(i, " ")
		delta = P[i]-np.conj(P[i])
		print(norm(delta))

	for i in range(len(P)):
		for j in range(i):
			printn(i, " vs ", j, " corr ")
			# delta = P[i]-np.conj(P[j])
			delta = np.dot(P[i], np.conj(P[j]))
			print(norm(delta))

	for i in range(len(P)):
		q = np.conj(P[i])
		print(i, "conjugate in there",  subspace_distance(P, q))


	for i in range(len(P)):
		print(i, "corr to conj", norm(np.dot(P[i], P[i])))



if __name__=="__main__":
	from mpl_toolkits.mplot3d import Axes3D
	from numpy.linalg import norm

	cplx=False
	i=1
	if(argv[i] == '-c'):
		cplx=True
		i+=1

	filename = argv[i]
	prefix = filename
	P = readEwMs(filename, cplx)
	index = 0
	#for p in [P[0]]:
	for i in range(len(P)):
		one = np.dot(P[i], np.conj(P[i]))
		print( i, " cdot ", i, one, one-1. )
		assert(abs(one-1.)<1e-10)
		for j in range(i):

			dot = np.dot(P[i], np.conj(P[j]))
			assert(abs(dot)<1e-12)
#			print( dot*np.conj(dot) )

	if(cplx):
		conj_check(P)

		for p in P:
			print("D0", np.dot(P[0], p),
			norm(np.dot(P[0], p)))

		for p in P:
			print("D1", np.dot(P[1], p),
			norm(np.dot(P[1], p)))
