import numpy as np
from sys import argv
import os
from xwToMs import xwToMs, cXwToMs
from msToXw import msToXw, cMsToXw

if __name__=="__main__":
    pvdfn=argv[1]

    from worm_parse import pvdparse, ptsFromVtu
    vtuindex=pvdparse(pvdfn)
    dir=os.path.dirname(pvdfn)

    x=iter(vtuindex)
    t=x.next()
    if(len(argv)>2):
        fn=int(argv[2])
        print("#frame", fn)
        for i in range(int(argv[2])):
            t=x.next()

    i = 0
    end = 200
    while(i<end):
        try:
            t = x.next()
        except StopIteration:
            break

        f=t.get('file')

        X,W,ign = ptsFromVtu(dir+'/'+f)

        m1, m2, nu = xwToMs(X, W)
        m11, m22, angle = cXwToMs(X, W)

        tau=X[1]-X[0]
        tau *= 127.

        center = (X[63]+X[64])/2
        ctau = X[64]-X[63]
        ctau *= 127.

        Xn,W = msToXw(m1, m2)



        Xr,W = msToXw(m1, m2, tau, nu, X[0])
        Xc,W = cMsToXw(m11, m22, ctau, angle, center)

        errorH = []
        errorC = []
        for i in range(len(X)):
            errorH.append(float(np.linalg.norm(X[i]-Xr[i])))
            errorC.append(float(np.linalg.norm(X[i]-Xc[i])))

        print "Error in msToXw: ", sum(errorH)
        print "Error in cMsToXw: ", sum(errorC)

        from matplotlib import pyplot as plt
        from matplotlib import gridspec
        from mpl_toolkits.mplot3d import Axes3D

        fig = plt.figure(facecolor='white')

        gs = gridspec.GridSpec(3, 4)
        ax0 = fig.add_subplot(gs[0:3,0:3], projection='3d')

        for j in range(len(X)-1):
            ax0.plot( [Xr[j][0], Xr[j+1][0]], \
                        [Xr[j][1], Xr[j+1][1]], \
                        [Xr[j][2], Xr[j+1][2]], \
                            color = 'green' , linewidth=3)

        for j in range(len(Xc)-1):
            ax0.plot( [Xc[j][0], Xc[j+1][0]], \
                        [Xc[j][1], Xc[j+1][1]], \
                        [Xc[j][2], Xc[j+1][2]], \
                            color = 'red' , linewidth=3)

        plt.show()
