import matplotlib as mpl
mpl.use('pdf')

import numpy as np
from matplotlib import pyplot as plt
import glob, os

import frame_tags


def parseFn( fn ):
    fn = os.path.basename(fn)
    data = fn.split('_')
    strain = data[0]
    media = float(data[1]+data[2][:2])/100.0
    date = data[3]
    trial = data[4]

    return strain, media, date, trial

def readPostureFile( fn ):
    frames, times, planeFits, lineFits, totalCurvatures = [], [], [], [], []
    try:
        file = open(fn,'r')
    except:
        return  frames, times, planeFits, lineFits, totalCurvatures

    for line in file.readlines():
        if '#' == line[0]:
            continue
        else:
            data = line.split(',')
            myFrame = int(float(data[0]))
            frames.append(myFrame)
            myTime = float(data[1])
            times.append(myTime)
            myPlaneFit = float(data[2])
            planeFits.append(myPlaneFit)
            myLineFit = float(data[3])
            lineFits.append(myLineFit)
            myTotalCurvature = float(data[4])
            totalCurvatures.append(myTotalCurvature)

    file.close()

    return frames, times, planeFits, lineFits, totalCurvatures

def readTrajectoryFile( fn ):
    try:
        data = np.loadtxt(fn, delimiter=',')
    except:
        return [],[],[],[],[],[],[],[],[],[]

    frame_number = data.T[0]
    time = data.T[1]
    x = data.T[2]
    y = data.T[3]
    z = data.T[4]
    speed = data.T[5]
    distance = data.T[6]
    cumulative_distance = data.T[7]
    turn_rate = data.T[8]
    turn_radii = data.T[9]
    return frame_number,time,x,y,z,speed,distance,cumulative_distance,turn_rate,turn_radii

def myHistLog( list, nBins=25 ):
    a = min(list)
    b = max(list)
    N = float(len(list))
    # N = 1

    bins = np.zeros( nBins )
    labels = np.logspace( np.log10(a), np.log10(b), nBins, endpoint=True )
    for l in list:
        try:
            idx = next(idx for idx, value in enumerate(labels) if value >= l)
        except:
            idx = -1
            # idx = int( (nBins-1) * ( l - a ) / ( b - a ) )
        bins[idx] += 1

    return labels, bins

basedir='/home/csunix/scstr/biosys2/3D_Data/analysis/223137/'
annotationdir = os.path.join( basedir, 'annotations')

def myTags( tags ):
    if not tags:
        return []
    # return tags[:-1]
    return [ t for j,t in enumerate(tags) if j < 2 ]

allTags = set()
for file in sorted( glob.glob( os.path.join(annotationdir, '*.csv') ) ):
    tags = frame_tags.frame_tags(file)
    for i in range(tags.size()):
        try:
            tt = tags.get_tag(i)
            for dd in myTags(tt):
                if dd == '':
                    continue
                allTags.add( dd )
        except:
            continue

bigDict = {}

for file in sorted( glob.glob( os.path.join(annotationdir, '*.csv') ) ):

    # print os.path.basename(file), tags.numtags()
    tags = frame_tags.frame_tags(file)
    trajFile = os.path.join( basedir, os.path.basename(file).replace('annotation','traj_output') )
    postureFile = os.path.join( basedir, os.path.basename(file).replace('annotation','posture_output') )

    strain, media, date, trial = parseFn( trajFile )
    if strain != "N2": continue

    data = readPostureFile( postureFile )

    if data != []:
        for j, key in enumerate(['frames', 'times', 'plane_fits', 'line_fits', 'total_curvatures']):

            for dd in allTags:
                if dd == '': continue

                if not dd in bigDict:
                    bigDict[dd] = {}

                if not media in bigDict[dd]:
                    bigDict[dd][media] = {}

                if key in bigDict[dd][media]:
                    bigDict[dd][media][key] += [ d for framenumber, d in zip(data[0],data[j]) \
                                                 if not np.isnan(d) and dd in myTags(tags.get_tag(int(framenumber))) ]
                else:
                    bigDict[dd][media][key] = [ d for framenumber, d in zip(data[0],data[j]) \
                                                if not np.isnan(d) and dd in  myTags(tags.get_tag(int(framenumber))) ]

    data = readTrajectoryFile( trajFile )

    if data != []:
        for j, key in enumerate(['frame_number','time','x','y','z','speed','distance','cumulative_distance','turn_rate','turn_radii']):

            for dd in allTags:
                if dd == '': continue

                if not dd in bigDict:
                    bigDict[dd] = {}

                if not media in bigDict[dd]:
                    bigDict[dd][media] = {}

                if key in bigDict[dd][media]:
                    bigDict[dd][media][key] += [ d for framenumber, d in zip(data[0],data[j]) \
                                                 if not np.isnan(d) and dd in myTags(tags.get_tag(int(framenumber))) ]
                else:
                    bigDict[dd][media][key] = [ d for framenumber, d in zip(data[0],data[j]) \
                                                if not np.isnan(d) and dd in myTags(tags.get_tag(int(framenumber))) ]

for dd in bigDict.keys():
    for fignum, key in enumerate(['speed','distance','cumulative_distance','turn_rate','turn_radii','plane_fits', 'line_fits', 'total_curvatures']):
        plt.figure(fignum)
        plt.clf()
        plt.title(dd + ' ' + key)
        plt.figure(fignum+20)
        plt.clf()
        plt.title(dd + ' ' + key + ' mean')

        for media in sorted(bigDict[dd]):
            try:
                data = bigDict[dd][media][key]
            except:
                continue

            if not data:
                continue
            labels, bins = myHistLog( data )
            plt.figure(fignum)
            plt.semilogx( labels, bins, color=(media/4.0,1.0-media/4.0,1.0), label='{}'.format(media))

            plt.figure(fignum+20)
            plt.semilogy( media, np.mean(data), 'o', color=(media/4.0,1.0-media/4.0,1.0), label='{}'.format(media))

            if dd == 'fwd' and key in ['speed','turn_rate','turn_radii','plane_fits','line_fits','total_curvatures']:
                np.savetxt( 'totaliser_plots_pretty/' + dd + '_' + key + '{}.dat'.format(media), [ [a,b] for a,b in zip(labels, bins) ] )
                print 'saved data to', 'totaliser_plots_pretty/' + dd + '_' + key + '{}.dat'.format(media)

        # plt.figure(fignum)
        # plt.savefig('totaliser_plots_freq/' + dd + '_' + key+'_dist.pdf')
        # print 'saved','totaliser_plots_freq/' + dd + '_' +  key+'_dist.pdf'

        # plt.figure(fignum+20)
        # plt.savefig('totaliser_plots_freq/' +  dd + '_' + key+'_mean.pdf')
        # print 'saved', 'totaliser_plots_freq/' + dd + '_' + key+'_mean.pdf'
