#!/usr/bin/env python

from math import log, exp
from numpy import arange,array,ones,linalg
import random
import numpy as np

from math import log
logs = [ log(i) for i in range(1, 20000) ]

from error import eprint

def scale_to_fit(a, b):
	l=len(a)
	if len(b)<l:
		l=len(b)
	A = array(a[:l])
	B = array(b[:l])
	return np.linalg.norm(B)/np.linalg.norm(A)

def fit_mono(data):
	number=0
	L=[]
	LA=[]
	M=0
	for d in data:
		number+=len(d)-1
		L.extend( [ log(i) for i in d[1:] ] )
		LA.extend( logs[:len(d)-1] )
		assert(len(d) == len(logs[:len(d)]))
		if (M<len(d)):
			M = len(d)

	A = array([ LA, ones(number)])

	y = array(L)
	#print "leny", len(y)
	#print "size", A.size /2
	w = linalg.lstsq(A.T,y)[0]

	return w,M

from math import exp
def fit_rescale(data):
	w, M = fit_mono(data)
	eprint("EXPONENT", w)
	fit = [ exp(w[1])*i**w[0] for i in range(M) ]

	for i in range(len(data)):
		d = data[i]
		s = scale_to_fit(d, fit)
		d = [ s*x for x in d ]
		data[i] = d

#	w, M = fit_mono(data)
	return w, M


if __name__=="__main__":

	logs = [ log(i) for i in range(1,400) ]
	mockup1 = [ 5.*i**.6   + random.uniform(-.2,.2) for i in range(20) ]
	mockup2 = [ 4.*i**.7   + random.uniform(-.2,.2)  for i in range(50) ]
	mockup3 = [ 3.*i**.8   + random.uniform(-.2,.2)  for i in range(50) ]

	data = [mockup1 , mockup2, mockup3]

	from matplotlib import pyplot as plt

	w, M = fit_rescale(data)
	w, M = fit_rescale(data)
	w, M = fit_rescale(data)
	w, M = fit_rescale(data)
	fit = [ exp(w[1])*i**w[0] for i in range(M) ]

	for m in data:
		plt.plot(m, color='red')

	plt.plot(fit)

	plt.show()

