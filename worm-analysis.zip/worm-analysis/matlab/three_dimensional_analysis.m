clear
close all

fps = 25;

% data_folder = 'X:\data\3D\curve_20170329_183732\nobackup\scsrih\output-curve\20170329_183732\N2_1_25pc_20160425_trial02\';
data_folder = 'X:\data\3D\curve\223137\nobackup\scsrih\output-curve\223137';
% data_folder = 'X:\data\3D\N2\curve';
% data_folder = 'X:\data\3D\curve_20170330_115632\';
% for exploration:
% data_folder = ('C:\Users\scsrih\Desktop\worm\curve\N2_0_75pc_20160427_trial02\20170324_165030');
% [ points, curvatures, times ] = readPvd_curve([data_folder '\skeletons_worm.pvd']);

trials = dir(data_folder);
dirFlags = [trials.isdir];
trials = trials(dirFlags);
trials = trials(arrayfun(@(x) x.name(1), trials) ~= '.');


%% validation videos - needs .png file inputs which are not outputted as
%% standard
% for k = 1:1%length(trials)
%     trial = trials(k).name;
%     folder = ([data_folder '\' trials(k).name]);
% %     sub_folders = dir(folder);
% %     sub_folders = sub_folders(arrayfun(@(x) x.name(1), sub_folders) ~= '.');
% %     folder = ([folder '\' sub_folders(1).name]);
% % trials = trials(arrayfun(@(x) x.name(1), trials) ~= '.');
% 
% %%% validation videos
% 
% %%% read silhouette points
% [ silhouette_cam0, silhouette_cam1, silhouette_cam2] = distance_read(folder);
% 
% %%% projected curves
% [ points_cam0, curvatures_cam0, times_cam0 ] = readPvd_curve([folder '\projected_skeletons_cam0worm.pvd']);
% [ points_cam1, curvatures_cam1, times_cam1 ] = readPvd_curve([folder '\projected_skeletons_cam1worm.pvd']);
% [ points_cam2, curvatures_cam2, times_cam2 ] = readPvd_curve([folder '\projected_skeletons_cam2worm.pvd']);
% 
% %%% plot validation
% worm_margin = 10; % margin of pixels plotted around worm
% 
% cam0_imgs = dir([folder '\cam0_frame_*.png']);
% N_cam0 = natsortfiles({cam0_imgs.name})';
% cam1_imgs = dir([folder '\cam1_frame_*.png']);
% N_cam1 = natsortfiles({cam1_imgs.name})';
% cam2_imgs = dir([folder '\cam2_frame_*.png']);
% N_cam2 = natsortfiles({cam2_imgs.name})';
% 
% for n = 1:length(silhouette_cam0)
%     set(0,'DefaultFigureVisible','off')
%     h = figure;
%     subplot(3,3,3)
%     imshow([folder '\' cell2mat(N_cam0(n))]);hold on
%     xlim([min(silhouette_cam0{1,n}(:,1))-worm_margin max(silhouette_cam0{1,n}(:,1))+worm_margin]);
%     ylim([min(silhouette_cam0{1,n}(:,2))-worm_margin max(silhouette_cam0{1,n}(:,2))+worm_margin]);
%     scatter(silhouette_cam0{1,n}(:,1),silhouette_cam0{1,n}(:,2),'.')
%     plot(points_cam0{1,n}(1,:),points_cam0{1,n}(2,:),'-g')
%     
%     subplot(3,3,6)
%     imshow([folder '\' cell2mat(N_cam1(n))]);hold on
%     xlim([min(silhouette_cam1{1,n}(:,1))-worm_margin max(silhouette_cam1{1,n}(:,1))+worm_margin]);
%     ylim([min(silhouette_cam1{1,n}(:,2))-worm_margin max(silhouette_cam1{1,n}(:,2))+worm_margin]);
%     scatter(silhouette_cam1{1,n}(:,1),silhouette_cam1{1,n}(:,2),'.')
%     plot(points_cam1{1,n}(1,:),points_cam1{1,n}(2,:),'-g')
%     
%     subplot(3,3,9)
%     imshow([folder '\' cell2mat(N_cam2(n))]);hold on
%     xlim([min(silhouette_cam2{1,n}(:,1))-worm_margin max(silhouette_cam2{1,n}(:,1))+worm_margin]);
%     ylim([min(silhouette_cam2{1,n}(:,2))-worm_margin max(silhouette_cam2{1,n}(:,2))+worm_margin]);
%     scatter(silhouette_cam2{1,n}(:,1),silhouette_cam2{1,n}(:,2),'.')
%     plot(points_cam2{1,n}(1,:),points_cam2{1,n}(2,:),'-g')
%     
%     subplot(3,3,[1 2 4 5 7 8])
%     plot3(points{1,n}(1,:),points{1,n}(2,:),points{1,n}(3,:),'-');hold on;
%     xlabel('mm')
%     ylabel('mm')
%     zlabel('mm')
%     title(sprintf([trials(n).name '   frame %06d'],n),'Interpreter','none')
%     
%     saveas(h,[folder '\' sprintf([trials(n).name '_%06d.png'],n)])
%     close
% end
% end

    
for m = 1:length(trials)
    
    trial = trials(m);
    folder = ([data_folder '\' trial.name]);
    [ points, curvatures, times ] = readPvd_curve([folder '\skeletons_worm.pvd']);
    mm = extractmidpoint( points );
    
    save ([data_folder(1:length(data_folder)-7) '\analysis\' trial.name '_PE_data.mat'] ,'-regexp','^(?!(dirFlags|trials)$). ');
    
end
    %%% trajectory investigation
    
    % plot raw x,y,z data
    
    
    
    
    figure(1)
    plot3(mm(1,:),mm(2,:),mm(3,:),'r')
    xlabel('mm')
    ylabel('mm')
    zlabel('mm')
    title(trial.name,'Interpreter', 'none')
    
    saveas(gcf,[data_folder(1:length(data_folder)-6) '\plots\trajectories\' trial.name '_unfilt_traj.bmp'],'bmp');
    
    % filter data using a third order butterworth filter (calculated in a
    % different script - buttered_worms.m
    fc = 1.7; % frequency cutoff determined by buttered_worms.m
    fs = 25; % frequency of recording
    
    [b,a] = butter(3,fc/(fs/2),'low');
    filt_x = filtfilt(b,a,mm(1,:));
    filt_y = filtfilt(b,a,mm(2,:));
    filt_z = filtfilt(b,a,mm(3,:));
    filt_mm = [filt_x; filt_y; filt_z];
    
    % plot filtered x,y,z data
    figure(1);hold on
    plot3(filt_x,filt_y,filt_z,'r')
    xlabel('mm')
    ylabel('mm')
    zlabel('mm')
    title(trial.name,'Interpreter', 'none')
    
    saveas(gcf,[data_folder(1:length(data_folder)-6) '\plots\trajectories\' trial.name '_trajectories.bmp'],'bmp');
    
    % plot filtered x,y,z data
    figure(2);hold on
    plot3(filt_x,filt_y,filt_z,'r')
    xlabel('mm')
    ylabel('mm')
    zlabel('mm')
    title(trial.name,'Interpreter', 'none')
    
    saveas(gcf,[data_folder(1:length(data_folder)-6) '\plots\trajectories\' trial.name '_filt_traj.bmp'],'bmp');
    %%% speed calculations
    
    % raw speed
    mm_diff = diff(mm,1,2);
    speed = zeros(length(mm_diff),1);
    
    for k = 1:length(mm_diff)
        speed(k) = sqrt(sum(mm_diff(:,k).^2))/(1/fps);
    end
    mean_speed = mean(speed);
    
    % filtered speed
    filt_mm_diff = diff(filt_mm,1,2);
    filt_speed = zeros(length(filt_mm_diff),1);
    
    for k = 1:length(filt_mm_diff)
        filt_speed(k) = sqrt(sum(filt_mm_diff(:,k).^2))/(1/fps);
    end
    mean_filt_speed = mean(filt_speed);
    
    figure(3)
    plot((1:length(speed))/fps,filt_speed,'r')
    xlim([0 (length(speed)/fps)])
    xlabel('time (s)')
    ylabel('speed (mm s^-^1)')
    title([trial.name ' speed'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-6) '\plots\100frames_curves\' trial.name '_filt_speed.bmp'],'bmp');
    
    % plot both raw and filtered speed against time
    figure(4)
    plot((1:length(speed))/fps,speed);hold on
    plot((1:length(speed))/fps,filt_speed,'r')
    xlim([0 (length(speed)/fps)])
    xlabel('time (s)')
    ylabel('speed (mm s^-^1)')
    title([trial.name ' speed'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-6) '\plots\speed\' trial.name '_speeds.bmp'],'bmp');
    
%     labels = [100 200 400 1000 2000 5000 10000 20000 50000];
%     set(gca, 'XTick', 1:length(times(1:length(times)-1))); % Change x-axis ticks
%     set(gca, 'XTickLabel', times(1:100:length(times)-1));
%     xlabel('time (s)');
%     ylabel('speed (mm s^-^1)')
%     title(trials(trial).name,'Interpreter', 'none')
    
    % accelertion
    
    
    %%% curvature
    % need to calculate max/min curvature
    
    
    
    
    % convert Cartesian coordinates to spherical coordinates
    [filt_azimuth,filt_elevation,filt_r] = cart2sph(filt_mm(1,:),filt_mm(2,:),filt_mm(3,:));
    [azimuth,elevation,r] = cart2sph(mm(1,:),mm(2,:),mm(3,:));
    
    
    figure(5)
    for j = 1:25:length(points)
        plot3(points{1,j}(1,:),points{1,j}(2,:),points{1,j}(3,:),'o');hold on;
    end
    xlabel('mm')
    ylabel('mm')
    zlabel('mm')
    title([trial.name ' curve plots 1 second'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-6) '\plots\25frames_curves\' '_25frames_curves.bmp'],'bmp');
    
    figure(6)
    for j = 1:25:length(points)
        plot3(curvatures{1,j}(1,:),curvatures{1,j}(2,:),curvatures{1,j}(3,:),'o');hold on;
    end
%     xlabel('mm')
%     ylabel('mm')
%     zlabel('mm')
    title([trial.name ' curve plots'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-6) '\plots\curvature\' trial.name '_curvature.bmp'],'bmp');
    
    figure(7)
    for j = 1:100:length(points)
        plot3(points{1,j}(1,:)+j,points{1,j}(2,:),points{1,j}(3,:),'o');hold on;
    end
    xlabel('mm')
    ylabel('mm')
    zlabel('mm')
    title([trial.name ' curve plots 4 seconds'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-6) '\plots\100frames_curves\' trial.name '_100frames_curves.bmp'],'bmp');
     
    %%%
    % do stuff here
    close all
    
    save ([data_folder(1:length(data_folder)-7) '\analysis\' trial.name '_PE_data.mat']);
%     clear points curvatures times mm trial
    %%%
    
%     save ([data_folder(1:length(data_folder)-6) 'analysis\' trial.name '.mat'],'points','curvatures','times','mm','trial');
end

% for n = 1:5
%     
%     trial = trials(n);
%     
%     load ([data_folder(1:length(data_folder)-6) 'analysis\' trial.name '.mat'],'points','curvatures','times','mm','trial');
% 
%     figure(1)
%     plot3(mm(1,:),mm(2,:),mm(3,:))
%     xlabel('mm')
%     ylabel('mm')
%     zlabel('mm')
%     title(trial.name,'Interpreter', 'none')
%     
%     fc = 1.7; % frequency cutoff determined by buttered_worms.m
%     fs = 25; % frequency of recording
%     
%     [b,a] = butter(3,fc/(fs/2),'low');
%     filt_x = filtfilt(b,a,mm(1,:));
%     filt_y = filtfilt(b,a,mm(2,:));
%     filt_z = filtfilt(b,a,mm(3,:));
%     
%     figure(1);hold on
%     plot3(filt_x,filt_y,filt_z,'r')
%     xlabel('mm')
%     ylabel('mm')
%     zlabel('mm')
%     title(trial.name,'Interpreter', 'none')
%     
%     % Bishop Frame
%     plot3(points{1}(1,:),points{1}(2,:),points{1}(3,:),'o')
% 
%     clear points curvatures times mm trial
% end