clear
close all

root_folder = 'X:\20170515\3D\calibration\';
date = '20170515';
new_folder = 'bw_images_0_35';
bw_folder = [root_folder date '\' new_folder];
mkdir([root_folder date],new_folder);

images = dir([root_folder date '\' '*.bmp']);

for i = 1:length(images)
    img = imread([root_folder date '\' images(i).name]);
    %     'X:\20161024\3D\calibration\20161028\' '20161028_calib1_cam2-14.bmp']);
    % figure(1)
    % imshow(img);
    
    % img2=img;
    
    % figure(2)
    % imshow(img2);
    %%% if clipping is needed comment this part back in
%     R = roipoly(img);
%             im2 = img;
%             im2(~R) = 255; %set things not in the mask to zero
%             imshow(im2);
%     % level = 0.25;
%     BW = im2bw(im2,0.4);
    %%%

    BW = im2bw(img,0.35);
    imwrite(BW,[bw_folder '\' images(i).name]);
    % figure(3)
    % imshow(BW)
end