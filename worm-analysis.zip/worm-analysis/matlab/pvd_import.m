clear
close all

fps = 25;
data_folder = 'X:\data\3D\curve\223137\nobackup\scsrih\output-curve\223137';

trials = dir(data_folder);
dirFlags = [trials.isdir];
trials = trials(dirFlags);
trials = trials(arrayfun(@(x) x.name(1), trials) ~= '.');

for m = 9:length(trials)
    trial = trials(m);
    folder = ([data_folder '\' trial.name]);
    if exist([folder '\skeletons_worm.pvd'],'file')==2;
        [ points, curvatures, times ] = readPvd_curve([folder '\skeletons_worm.pvd']);
        mm = extractmidpoint( points );
        save ([data_folder(1:length(data_folder)-36) '\analysis\' trial.name '_PE_data.mat'], '-regexp', '^(?!(dirFlags|trials)$).')
    end
end