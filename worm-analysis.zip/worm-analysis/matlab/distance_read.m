function [ silhouette_cam0, silhouette_cam1, silhouette_cam2] = distance_read(folder)

% this function reads the x,y coordinates of the silhouette identified
% using the Otsu method in the openWorm software.

% output
% silhouette_cam0, silhouette_cam1, silhouette_cam2 are the three cameras

% input
% folder ontaining the .csv files

files0=dir([folder ,'\distance_cam0_frame_*.csv']);
graph_cam0 = natsortfiles({files0.name})';
files1=dir([folder ,'\distance_cam1_frame_*.csv']);
graph_cam1 = natsortfiles({files1.name})';
files2=dir([folder ,'\distance_cam2_frame_*.csv']);
graph_cam2 = natsortfiles({files2.name})';

silhouette_cam0 = cell(1,length(files0));
silhouette_cam1 = cell(1,length(files1));
silhouette_cam2 = cell(1,length(files2));

for n = 1:length(files0)
    silhouette_cam0{n} = dlmread([folder '\' cell2mat(graph_cam0(n))],',',1,0);
    silhouette_cam1{n} = dlmread([folder '\' cell2mat(graph_cam1(n))],',',1,0);
    silhouette_cam2{n} = dlmread([folder '\' cell2mat(graph_cam2(n))],',',1,0);
end