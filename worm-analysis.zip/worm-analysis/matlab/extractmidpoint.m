function mm = extractmidpoint( pts )
%
% extract midpoint for trajectory, one per step
%

    mm = arrayfun( @extract_one_midpoint, pts, 'UniformOutput', false );
end

function mid = extract_one_midpoint( pts_step )
    myPts = pts_step{1};
    nPts = length(myPts);
    mid = myPts( :, nPts/2 );
end
