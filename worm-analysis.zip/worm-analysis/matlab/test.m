function test

[ X, W, t ] = readPvd( 'X:\data\3D\curve\200406\N2_0_75pc_20160427_trial01/skeletons_worm.pvd' );

clf
hold on

nTimes = length(t);

for k = 1 :nTimes
    vec = curvaturesToVec( X{k}, W{k} ); % all of m1 and then all of m2, 256 long vector
    [X2,W2] = vecToCurvatures( vec ); % inverse of above

    vec2 = curvaturesToVec( X2, W2 ); 
    disp( max( vec - vec2 ) );
    [X3,W3] = vecToCurvatures( vec2 );

    vec3 = curvaturesToVec( X3, W3 );
    disp( max( vec - vec3 ) );
    [X4,W4] = vecToCurvatures( vec3 );

    subplot(121);
    plot3( X{k}(1,:), X{k}(2,:), X{k}(3,:) );
    subplot(122);
    hold on
    plot3( X2(1,:), X2(2,:), X2(3,:), 'color', 'red' );
    plot3( X3(1,:), X3(2,:), X3(3,:), 'color', 'green' );
    plot3( X4(1,:), X4(2,:), X4(3,:), 'color', 'blue' );
    pause
    clf
end

end