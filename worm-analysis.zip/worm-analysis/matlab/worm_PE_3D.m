clear
close all

data_folder = 'X:\data\3D\curve\223137\analysis\PE_data\';

trials = dir([data_folder '*PE_data.mat']);
% trials = trials(arrayfun(@(x) x.name(1), trials) ~= '.');

for m = 1:size(trials)
    load ([data_folder trials(m).name], '-regexp', '^(?!trials$|data_folder$|m$).');
    %     load ([data_folder trials(m).name], 'points', 'curvatures', 'times', 'filt_mm');
    
    % meta data
    trial_name = trial.name;
    parsed = strsplit(trial_name,{'_','.'});
    strain = cell2mat(parsed(1));
    med_temp = cell2mat(parsed(3));
    media = cell2mat([parsed(2) '.' med_temp(1:2)]);
    %     media2 = [media(1) '.' media(3:4)];
    date = cell2mat(parsed(4));
    run = cell2mat(parsed(5));
    trial_length = size(filt_mm,2);
    trial_length_sec = size(filt_mm,2)/fps;
    
    mkdir([data_folder(1:length(data_folder)-9) '\plots\distance\']);
    mkdir([data_folder(1:length(data_folder)-9) '\plots\histograms\']);
    
    % distance
    distance = sqrt((filt_mm_diff(1,:).^2)+(filt_mm_diff(2,:).^2))+(filt_mm_diff(3,:).^2);
    figure(1)
    plot((1:length(distance))/fps,distance,'r')
    xlim([0 (length(speed)/fps)])
    xlabel('time (s)')
    ylabel('distance (mm)')
    title([trial.name ' Distance. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\distance\' trial.name '_filt_speed.bmp'],'bmp');
    
    % total distance
    distance_tot = sum(distance);
    
    % cumulative distance covered
    dis_cum_sum = zeros(1,size(distance,2));
    for sums = 1:size(distance,2)
        dis_cum_sum(sums) = sum(distance(1:sums));
    end
    figure(2)
    plot((1:length(distance))/fps,dis_cum_sum,'r')
    xlim([0 (length(speed)/fps)])
    xlabel('time (s)')
    ylabel('cumulative distance (mm)')
    title([trial.name ' Cumulative distance. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\distance\' trial.name '_filt_speed.bmp'],'bmp');
    
    % crow distance
    straight_distance = sqrt((filt_mm(1,1)-filt_mm(1,size(filt_mm,2)))^2+(filt_mm(2,1)-filt_mm(2,size(filt_mm,2)))^2+(filt_mm(3,1)-filt_mm(3,size(filt_mm,2)))^2);
    
    % persistance of the trajectory length
    if size(filt_mm,2)>25
        persist_one_sec = sqrt(sum((filt_mm(:,1:size(filt_mm,2)-25)-(filt_mm(:,26:size(filt_mm,2)))).^2));
        persist_ang_one_sec =  bsxfun(@rdivide, (filt_mm(:,1:size(filt_mm,2)-25)-filt_mm(:,26:size(filt_mm,2))), persist_one_sec);
    else
        persist_one_sec = [];
        persist_ang_one_sec = [];
    end
    
    if size(filt_mm,2)>50
        persist_two_sec = sqrt(sum((filt_mm(:,1:size(filt_mm,2)-50)-(filt_mm(:,51:size(filt_mm,2)))).^2));
        persist_ang_two_sec =  bsxfun(@rdivide, (filt_mm(:,1:size(filt_mm,2)-50)-filt_mm(:,51:size(filt_mm,2))), persist_two_sec);
    else
        persist_two_sec = [];
        persist_ang_two_sec = [];
    end
    
    if size(filt_mm,2)>100
        persist_four_sec = sqrt(sum((filt_mm(:,1:size(filt_mm,2)-100)-(filt_mm(:,101:size(filt_mm,2)))).^2));
        persist_ang_four_sec =  bsxfun(@rdivide, (filt_mm(:,1:size(filt_mm,2)-100)-filt_mm(:,101:size(filt_mm,2))), persist_four_sec);
    else
        persist_four_sec = [];
        persist_ang_four_sec = [];
    end
    
    if size(filt_mm,2)>200
        persist_eight_sec = sqrt(sum((filt_mm(:,1:size(filt_mm,2)-200)-(filt_mm(:,201:size(filt_mm,2)))).^2));
        persist_ang_eight_sec =  bsxfun(@rdivide, (filt_mm(:,1:size(filt_mm,2)-200)-filt_mm(:,201:size(filt_mm,2))), persist_eight_sec);
    else
        persist_eight_sec = [];
        persist_ang_eight_sec = [];
    end
    
    if size(filt_mm,2)>400
        persist_sixteen_sec = sqrt(sum((filt_mm(:,1:size(filt_mm,2)-400)-(filt_mm(:,401:size(filt_mm,2)))).^2));
        persist_ang_sixteen_sec =  bsxfun(@rdivide, (filt_mm(:,1:size(filt_mm,2)-400)-filt_mm(:,401:size(filt_mm,2))), persist_sixteen_sec);
    else
        persist_sixteen_sec = [];
        persist_ang_sixteen_sec = [];
    end
    
    if size(filt_mm,2)>800
        persist_thirty_two_sec = sqrt(sum((filt_mm(:,1:size(filt_mm,2)-800)-(filt_mm(:,801:size(filt_mm,2)))).^2));
        persist_ang_thirty_two_sec =  bsxfun(@rdivide, (filt_mm(:,1:size(filt_mm,2)-800)-filt_mm(:,801:size(filt_mm,2))), persist_thirty_two_sec);
    else
        persist_thirty_two_sec = [];
        persist_ang_thirty_two_sec = [];
    end
    
    if size(filt_mm,2)>800
        persist_sixty_four_sec = sqrt(sum((filt_mm(:,1:size(filt_mm,2)-1600)-(filt_mm(:,1601:size(filt_mm,2)))).^2));
        persist_ang_sixty_four_sec =  bsxfun(@rdivide, (filt_mm(:,1:size(filt_mm,2)-1600)-filt_mm(:,1601:size(filt_mm,2))), persist_sixty_four_sec);
    else
        persist_sixty_four_sec = [];
        persist_ang_sixty_four_sec = [];
    end
    
    % distance persistance historgram
    bin = 20;
    figure
    histogram(persist_one_sec,bin);hold on
    histogram(persist_two_sec,bin)
    histogram(persist_four_sec,bin)
    histogram(persist_eight_sec,bin)
    histogram(persist_sixteen_sec,bin)
    histogram(persist_thirty_two_sec,bin)
    histogram(persist_sixty_four_sec,bin)
    xlabel('distance (mm)')
    ylabel('frequency')
    title([trial.name ' Distance Persistance. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    legend = legend('1 second', '2 second', '4 second', '8 second', '16 second', '32 second', '64 second');
    set(legend, 'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\histograms\' trial.name '_persistance_hist.bmp'],'bmp');
    
    % x persistance histogram
    figure
    histogram(persist_ang_one_sec(1,:),bin);hold on
    histogram(persist_ang_two_sec(1,:),bin)
    histogram(persist_ang_four_sec(1,:),bin)
    histogram(persist_ang_eight_sec(1,:),bin)
    histogram(persist_ang_sixteen_sec(1,:),bin)
    histogram(persist_ang_thirty_two_sec(1,:),bin)
    histogram(persist_ang_sisty_four_sec(1,:),bin)
    xlabel('distance (mm)')
    ylabel('frequency')
    title([trial.name ' x normalised vector persistance. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    legend = legend('1 second', '2 second', '4 second', '8 second', '16 second', '32 second', '64 second');
    set(legend, 'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\histograms\' trial.name '_persistance_hist.bmp'],'bmp');
    
    % y persistance histogram
    figure
    histogram(persist_ang_one_sec(2,:),bin);hold on
    histogram(persist_ang_two_sec(2,:),bin)
    histogram(persist_ang_four_sec(2,:),bin)
    histogram(persist_ang_eight_sec(2,:),bin)
    histogram(persist_ang_sixteen_sec(2,:),bin)
    histogram(persist_ang_thirty_two_sec(2,:),bin)
    histogram(persist_ang_sisty_four_sec(2,:),bin)
    xlabel('distance (mm)')
    ylabel('frequency')
    title([trial.name ' y normalised vector persistance. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    legend = legend('1 second', '2 second', '4 second', '8 second', '16 second', '32 second', '64 second');
    set(legend, 'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\histograms\' trial.name '_persistance_hist.bmp'],'bmp');
    
    % z persistance histogram
    figure
    histogram(persist_ang_one_sec(3,:),bin);hold on
    histogram(persist_ang_two_sec(3,:),bin)
    histogram(persist_ang_four_sec(3,:),bin)
    histogram(persist_ang_eight_sec(3,:),bin)
    histogram(persist_ang_sixteen_sec(3,:),bin)
    histogram(persist_ang_thirty_two_sec(3,:),bin)
    histogram(persist_ang_sisty_four_sec(3,:),bin)
    xlabel('distance (mm)')
    ylabel('frequency')
    title([trial.name ' z normalised vector persistance. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    legend = legend('1 second', '2 second', '4 second', '8 second', '16 second', '32 second', '64 second');
    set(legend, 'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\histograms\' trial.name '_persistance_hist.bmp'],'bmp');
    
    % volume covered in trajectory
    figure
    plot3(filt_mm(1,:),filt_mm(2,:),filt_mm(3,:),'.')
    xlabel('mm')
    ylabel('mm')
    zlabel('mm')
    title([trial.name ' Trajectory. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\trajectories\' trial.name '_filt_traj.bmp'],'bmp');
    
    [rotmat_traj,cornerpoints_traj,volume_traj,surface_traj,edgelength_traj] = minboundbox(filt_mm(1,:),filt_mm(2,:),filt_mm(3,:));
    
    figure
    plotminbox(cornerpoints_traj);hold on
    plot3(filt_mm(1,:),filt_mm(2,:),filt_mm(3,:),'r')
    xlabel('mm')
    ylabel('mm')
    zlabel('mm')
    title([trial.name ' Trajectory with volume bounding box. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\trajectories\' trial.name '_traj_volume.bmp'],'bmp');
    
    %     % volume containing worm
    %     rotmat_worm = cell(1,size(points,2));
    %     cornerpoints_worm = cell(1,size(points,2));
    %     volume_worm = zeros(1,size(points,2));
    %     surface_worm = zeros(1,size(points,2));
    %     edgelength_worm = zeros(1,size(points,2));
    %
    %     for frame = 1:5%size(points,2)
    %     [rotmat_worm{frame},cornerpoints_worm{frame},volume_worm(frame),surface_worm(frame),edgelength_worm(frame)] = minboundbox(points{1,frame}(1,:),points{1,frame}(2,:),points{1,frame}(3,:));
    %     end
    
    % planarity & line
    nTimes = size(times,2);
    planeFit = zeros(1,nTimes);
    lineFit = zeros(1,nTimes);
    totalCurvature = zeros(1,nTimes);
    
    for k = 1 : nTimes
        [planeFit(k), lineFit(k)] = fitPlane( points{k} );
        
        sum_curvatures = 0.0;
        for j = 1 : length(curvatures{k})
            for d = 1 : 3
                sum_curvatures = sum_curvatures + (curvatures{k}(d,j))^2;
            end
        end
        totalCurvature(k) = sqrt(sum_curvatures/length(curvatures{k}));
    end
    
    %%%
    figure
    left_color = [0 0 1];
    right_color = [1 0 0];
    set(gcf,'defaultAxesColorOrder',[left_color; right_color]);
    clf;
    hold on;
    xlabel('time (s)');
    xlim([0 times(length(times))])
    
    yyaxis left
    semilogy( times, planeFit, 'b' );
    ylabel('Plane fit (mm)');
    
    yyaxis right
    semilogy( times, lineFit, 'r' );
    ylabel('Line fit (mm)')
    
    title([trial.name ' Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\' trial.name '_plane_line.bmp'],'bmp');
    
    %%%
    figure
    clf;
    left_color = [0 0 1];
    right_color = [0 1 0];
    set(gcf,'defaultAxesColorOrder',[left_color; right_color]);
    hold on;
    xlabel('time (s)');
    xlim([0 times(length(times))])
    
    yyaxis left
    semilogy( times, planeFit, 'b' );
    ylabel('Plane fit (mm)');
    
    yyaxis right
    semilogy( times, totalCurvature, 'g' );
    ylabel('Total curvature')
    
    title([trial.name ' Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\' trial.name '_plane_curve.bmp'],'bmp');
    
    %%%
    figure
    left_color = [0 1 0];
    right_color = [1 0 0];
    set(gcf,'defaultAxesColorOrder',[left_color; right_color]);
    
    clf;
    hold on;
    xlabel('time (s)');
    xlim([0 times(length(times))])
    
    yyaxis left
    semilogy( times, totalCurvature, 'g' );
    ylabel('Total curvature');
    
    yyaxis right
    semilogy( times, lineFit, 'r' );
    ylabel('Line fit (mm)')
    
    title([trial.name ' Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\' trial.name '_curve_line.bmp'],'bmp');
    
    % 90th centile curvature
    
    figure
    histogram(filt_speed)
    ylabel('frequency')
    xlabel('speed (mm s^-^1)')
    title([trial.name ' Speed Histogram. Trial Length: ' num2str(trial_length) ' frames, ' num2str(trial_length_sec) ' s'],'Interpreter', 'none')
    saveas(gcf,[data_folder(1:length(data_folder)-9) '\plots\histograms\' trial.name '_speed_hist.bmp'],'bmp');
    
    % performance envelope
    i=1;
    xff = filt_mm(1,:);
    yff = filt_mm(2,:);
    zff = filt_mm(3,:);
    
    %stores target coordinates as cells in an array
    xffpos{i}=xff;
    yffpos{i}=yff;
    zffpos{i}=zff;
    
    %difference coordinates for change in each direction and multiply by frame
    %rate for Cartesian velocity components and horizontal and total speed
    
    xffvel=diff(xff)*fps;
    yffvel=diff(yff)*fps;
    zffvel=diff(zff)*fps;
    
    xffvelall{i}=xffvel;
    yffvelall{i}=yffvel;
    zffvelall{i}=zffvel;
    
    
    hor_speed_all{i}=sqrt(xffvel.^2+yffvel.^2);
    total_speed=sqrt(xffvel.^2+yffvel.^2+zffvel.^2);
    total_speed_all{i}=total_speed;
    
    %difference velocity components and multiply by frame rate for total
    %acceleration
    xffacc=(diff(xffvel)*fps);
    yffacc=(diff(yffvel)*fps);
    zffacc=(diff(zffvel)*fps);
    tffacc=sqrt(xffacc.^2+yffacc.^2+zffacc.^2);
    
    xffaccall{i}=xffacc;
    yffaccall{i}=yffacc;
    zffaccall{i}=zffacc;
    tffaccall{i}=tffacc;
    
    
    %calculates change in speed (i.e. total tangential acceleration)
    delta_total_speed=diff(total_speed)*fps;
    delta_total_speed_all{i}=delta_total_speed;
    
    
    %calculates centripetal acceleration
    centripetal_acc_mag=sqrt(tffacc.^2-delta_total_speed.^2);
    centripetal_acc_mag_all{i}=centripetal_acc_mag;
    
    %Averages velocity components at adjacent points
    atot=[xffvel(:,1:length(xffvel)-1); yffvel(:,1:length(yffvel)-1); zffvel(:,1:length(zffvel)-1)];
    btot=[xffvel(:,2:length(xffvel)); yffvel(:,2:length(yffvel)); zffvel(:,2:length(zffvel))];
    avtot=(sqrt(atot(1,:).^2+atot(2,:).^2+atot(3,:).^2)+sqrt(btot(1,:).^2+btot(2,:).^2+btot(3,:).^2))/2;
    avtot_all{i}=avtot;
    avhor_all{i}=(sqrt(atot(1,:).^2+atot(2,:).^2)+sqrt(btot(1,:).^2+btot(2,:).^2))/2;
    avver_all{i}=sqrt(atot(3,:).^2+btot(3,:).^2)/2;
    
    %Calculates total change in track path direction (rad/s unsigned)
    turn_rate=fps*(asin(sqrt(sum(cross(atot,btot).^2))./(sqrt(sum(atot.^2)).*sqrt(sum(btot.^2)))));
    rate_turn_all{i}=turn_rate;
    %     turn_rate=fps*(asin(sqrt(sum(cross(atot,btot).^2))./(sqrt(sum(atot.^2)).*sqrt(sum(btot.^2)))));
    %     rate_turn_all{i}=turn_rate;
    
    %Calculates track path angle and heading (rad signed)
    
    worm_track_angle_all{i}=atan(zffvel./sqrt(xffvel.^2+yffvel.^2));
    
    av_worm_track_angle=atan((atot(3,:)+btot(3,:))./sqrt((atot(1,:)+btot(1,:)).^2+(atot(2,:)+btot(2,:)).^2));
    av_worm_track_angle_all{i}=av_worm_track_angle;
    
    av_heading_angle=atan2((atot(1,:)+btot(1,:)),(atot(2,:)+btot(2,:)));
    av_heading_angle_all{i}=av_heading_angle;
    
    %Calculates instantaneous turn radius (m)
    temp_tot_turn_radius = (avtot./turn_rate);
    %     temp_tot_turn_radius(temp_tot_turn_radius>1000) = NaN; % converts the turn radii over 1 mm (1000 mm) to NaNs.
    tot_turn_radius_all{i}=temp_tot_turn_radius;
    turn_radii = cell2mat(tot_turn_radius_all);
    
    %resolves vertical and horizontal components of tangential acceleration
    %(note horizontal component is signed negative if slowing down, while
    %vertical component is signed negative if in the direction of gravity)
    delta_total_speed_vertical_all{i}=sin(av_worm_track_angle).*abs(delta_total_speed);
    delta_total_speed_horizontal_all{i}=cos(av_worm_track_angle).*delta_total_speed;
    
    
    %resolves tangential and centripetal components of acceleration (but there
    %is no inertia for the worm)
    tangential_acc_z=delta_total_speed.*sin(av_worm_track_angle);
    tangential_acc_h=delta_total_speed.*cos(av_worm_track_angle);
    tangential_acc_x=tangential_acc_h.*sin(av_heading_angle);
    tangential_acc_y=tangential_acc_h.*cos(av_heading_angle);
    tangential_acc_all{i}=[tangential_acc_x;tangential_acc_y;tangential_acc_z];
    centripetal_acc_all{i}=[xffacc;yffacc;zffacc]-[tangential_acc_x;tangential_acc_y;tangential_acc_z];
    % end
    
    
    %%% save .csv files %%%
    frames = 0:1:size(times,2)-1;
    
    trajectory_data = NaN(size(frames,2),10);
    trajectory_data(:,1:5) = [frames' times' filt_mm'];
    trajectory_data(1:size(filt_speed,1),6:8) = [filt_speed distance' dis_cum_sum'];
    trajectory_data(1:size(turn_rate,2),9:10) = [turn_rate' turn_radii'];
    
    save ([data_folder trials(m).name '_all_PE_output'], '-regexp', '^(?!trials$|data_folder$|m$|trials$).');
    % save ([data_folder trials(m).name '_PE_output'],');
    
    fid = fopen([data_folder(1:length(data_folder)-8) trial_name '_traj_output.csv'],'wt');
    fprintf(fid,'%s\n', ['# trial name: ' trial_name]);
    fprintf(fid,'%s\n', ['# trial number: ' run]);
    fprintf(fid,'%s\n', ['# date: ' date]);
    fprintf(fid,'%s\n', ['# strain: ' strain]);
    fprintf(fid,'%s\n', ['# viscosity: ' media]);
    fprintf(fid,'%s\n', ['# trial length (frames): ' trial_length]);
    fprintf(fid,'%s\n', ['# trial length (seconds): ' trial_length_sec]);
    fprintf(fid,'%s\n', ['# frame_number,time,x,y,z,speed,distance,cumulative_distance,turn_rate,turn_radii']);
    fclose(fid);
    dlmwrite([data_folder(1:length(data_folder)-8) trial_name '_traj_output.csv'],trajectory_data,'-append');
    
    posture_data = NaN(size(frames,2),5);
    posture_data(:,1:5) = [frames' times' planeFit' lineFit' totalCurvature'];
    
    fid = fopen([data_folder(1:length(data_folder)-8) trial_name '_posture_output.csv'],'wt');
    fprintf(fid,'%s\n', ['# trial name: ' trial_name]);
    fprintf(fid,'%s\n', ['# trial number: ' run]);
    fprintf(fid,'%s\n', ['# date: ' date]);
    fprintf(fid,'%s\n', ['# strain: ' strain]);
    fprintf(fid,'%s\n', ['# viscosity: ' media]);
    fprintf(fid,'%s\n', ['# trial length (frames): ' trial_length]);
    fprintf(fid,'%s\n', ['# trial length (seconds): ' trial_length_sec]);
    fprintf(fid,'%s\n', ['# frame_number,time,plane_fit,line_fit,total_curvature']);
    fclose(fid);
    dlmwrite([data_folder(1:length(data_folder)-8) trial_name '_posture_output.csv'],posture_data,'-append');
    
    persistance_data = NaN(size(frames,2),16);
    persistance_data(:,1:2) = [frames' times'];
    persistance_data(1:size(persist_one_sec,2),3) = persist_one_sec';
    persistance_data(1:size(persist_two_sec,2),4) = persist_two_sec';
    persistance_data(1:size(persist_four_sec,2),5) = persist_four_sec';
    persistance_data(1:size(persist_eight_sec,2),6) = persist_eight_sec';
    persistance_data(1:size(persist_sixteen_sec,2),7) = persist_sixteen_sec';
    persistance_data(1:size(persist_thirty_two_sec,2),8) = persist_thirty_two_sec';
    persistance_data(1:size(persist_sixty_four_sec,2),9) = persist_sixty_four_sec';
    persistance_data(1:size(persist_ang_one_sec,2),10) = persist_one_sec';
    persistance_data(1:size(persist_ang_two_sec,2),11) = persist_two_sec';
    persistance_data(1:size(persist_ang_four_sec,2),12) = persist_four_sec';
    persistance_data(1:size(persist_ang_eight_sec,2),13) = persist_eight_sec';
    persistance_data(1:size(persist_ang_sixteen_sec,2),14) = persist_sixteen_sec';
    persistance_data(1:size(persist_ang_thirty_two_sec,2),15) = persist_thirty_two_sec';
    persistance_data(1:size(persist_ang_sixty_four_sec,2),16) = persist_sixty_four_sec';
    
    fid = fopen([data_folder(1:length(data_folder)-8) '\' trial_name '_persist_output.csv'],'wt');
    fprintf(fid,'%s\n', ['# trial name: ' trial_name]);
    fprintf(fid,'%s\n', ['# trial number: ' run]);
    fprintf(fid,'%s\n', ['# date: ' date]);
    fprintf(fid,'%s\n', ['# strain: ' strain]);
    fprintf(fid,'%s\n', ['# viscosity: ' media]);
    fprintf(fid,'%s\n', ['# trial length (frames): ' trial_length]);
    fprintf(fid,'%s\n', ['# trial length (seconds): ' trial_length_sec]);
    fprintf(fid,'%s\n', ['# frame_number,time,persist_1,persist_2,persist_4,persist_8,persist_16,persist_32,persist_64,persist_ang_1,persist_ang_2,persist_ang_4,persist_ang_8,persist_ang_16,persist_ang_32,persist_ang_64']);
    fclose(fid);
    dlmwrite([data_folder(1:length(data_folder)-9) trial_name '_persist_output.csv'],persistance_data,'-append');
    
    global_data = [sum(distance) straight_distance volume_traj];
    
    fid = fopen([data_folder(1:length(data_folder)-8) trial_name '_global_output.csv'],'wt');
    fprintf(fid,'%s\n', ['# trial name: ' trial_name]);
    fprintf(fid,'%s\n', ['# trial number: ' run]);
    fprintf(fid,'%s\n', ['# date: ' date]);
    fprintf(fid,'%s\n', ['# strain: ' strain]);
    fprintf(fid,'%s\n', ['# viscosity: ' media]);
    fprintf(fid,'%s\n', ['# trial length (frames): ' trial_length]);
    fprintf(fid,'%s\n', ['# trial length (seconds): ' trial_length_sec]);
    fprintf(fid,'%s\n', ['# total_distance,straight_distance,trajectory_volume']);
    fclose(fid);
    dlmwrite([data_folder(1:length(data_folder)-8) trial_name '_global_output.csv'],global_data,'-append');

    close all
    clearvars -except data_folder trials m
end
