clear
close all

data_folder = 'X:\data\3D\curve\223137\analysis\';

trials = dir(data_folder);
trials = trials(arrayfun(@(x) x.name(1), trials) ~= '.');

filenames = cell(length(trials),1);
for i = 1:length(trials)
    filenames{i} = trials(i).name;
end
% filenames = [{'N2_0_75pc_20160427_trial01.mat'}];
%            {'F15N2a'};
%            {'F15N2b'};
%            {'F15N2c'};
%            {'F15N2d'};
%            {'F15N3'};
%            {'F15N4a'};
%            {'F15N4b'};];
            
for i=1:length(filenames);
    
    load([data_folder filenames{i}],'mm');
    X{i}=mm(1,:);
    Y{i}=mm(2,:);
    Z{i}=mm(3,:);
    
end

x=cell2mat(X);
y=cell2mat(Y);
z=cell2mat(Z);

xrand=randn(length(x),1);
i=0;

datax=zeros((2.49-0.1)/0.01,length(x));
datay=zeros((2.49-0.1)/0.01,length(x));
dataz=zeros((2.49-0.1)/0.01,length(x));

for f=0.05:0.05:12.45
    
    i=i+1;
    
    [B A]=butter(3,f/12.5);
    
    xfilt=filtfilt(B,A,x);
    yfilt=filtfilt(B,A,y);
    zfilt=filtfilt(B,A,z);
    
    xresd=xfilt-x;
    yresd=yfilt-y;
    zresd=zfilt-z;
        
    datax(i,:)=xresd;
    datay(i,:)=yresd;
    dataz(i,:)=zresd;

    xresd=xrand-filtfilt(B,A,xrand);
    random(i,:)=xresd;   
    fprintf(['Fequency: ' num2str(f) ' Hz \n']);
    
end

% save frequency_fish data* random*
% load frequency_fish

freqs=0.05:0.05:12.45;

clear data_std data_var random_std random_var
for f=1:size(datax,1)

    [dataxc lags]=xcorr(datax(f,:),50,'coeff');
    dataxc(find(lags==0))=[];
    datax_std(f)=std(dataxc);
    datax_var(f)=var(dataxc);
    
    [dataxc lags]=xcorr(datay(f,:),50,'coeff');
    dataxc(find(lags==0))=[];
    datay_std(f)=std(dataxc);
    datay_var(f)=var(dataxc);    
    
    [dataxc lags]=xcorr(dataz(f,:),50,'coeff');
    dataxc(find(lags==0))=[];
    dataz_std(f)=std(dataxc);
    dataz_var(f)=var(dataxc);      

    [randomxc lags]=xcorr(random(f,:),50,'coeff');
    randomxc(find(lags==0))=[];    
    random_std(f)=std(randomxc);
    random_var(f)=var(randomxc);
    
end

%     subplot(3,1,1)
    hold off
    h(1)=plot(freqs,datax_var,'m');hold on;
    h(2)=plot(freqs,datay_var,'g');hold on;
    h(3)=plot(freqs,dataz_var,'b');hold on;
    h(4)=plot(freqs,random_var,'r');
    axis([0 max(freqs) 0 0.3])
    xlabel('Cut-off frequency');
    ylabel('Variance of autocorrelation coefficient');
    legend(h,'x-axis','y-axis','z-axis','random')
    fillscreen
