clear
close all

week = '20170522';
date = '20170523';
date2 = str2double(date);
trial = '01';
strain = 'N2';
media = '1_75pc';
media2 = [media(1) '.' media(3:4)];
if date2 == 20160425|| date2 == 20160426|| date2 ==20160427|| date2 ==20160428|| date2 ==20160614|| date2 == 20160615|| date2 == 20160711|| date2 == 20160713|| date2 == 20160714|| date2 == 20160715|| date2 == 20160718|| date2 == 20160801|| date2 == 20160802|| date2 == 20160816|| date2 == 20160817
    mag = '150';
elseif date2 == 20161017|| date2 == 20161018|| date2 == 20161019|| date2 == 20161020|| date2 == 20161021|| date2 == 20161024|| date2 == 20161028|| date2 == 20161101|| date2 == 20161104|| date2 == 20161107|| date2 == 20161110|| date2 == 20161111|| date2 == 20161123|| date2 == 20161124|| date2 == 20161128|| date2 == 20161101|| date2 == 20161129 || date2 == 20170508 || date2 == 20170515 || date2 == 20170523
    mag = '230';
end

frame_index = 1; % needs to be one greater than the frame you want to investigate as we count from 0 and matlab does not

mov_dir = ['X:\' week '\3D\video\' strain '\' media '\'];

for cam = 1:1
    mov_name = [date '_trial' num2str(trial) '_cam' num2str(cam) '.avi'];
    movie = [mov_dir mov_name];
    v = VideoReader(movie);
    time_array = 0:(1/v.FrameRate):v.Duration;
    frames = 0:1:v.Duration/(1/v.FrameRate);
    frames = round(frames);
    random_frames = time_array(frame_index);
    rf_idx = frames(frame_index);
    for i=1:length(random_frames)
        v.CurrentTime = random_frames(i);
        movie_frame = rf_idx(i);
        while v.CurrentTime == random_frames(i)
            x = zeros(1,12);
            y = zeros(1,12);
            %                 movie_frame = random_frames(i)/(1/v.FrameRate);
            imshow(readFrame(v));hold on
            pause(10)
            imwrite(readFrame(v),['X:\data\3D\worm_spline\bmps\' mov_name(1:length(mov_name)-4) '_frame_' num2str(movie_frame) '.bmp'],'bmp');
            for spline_points = 1:16
                [x(spline_points),y(spline_points)] = ginput(1);
                plot(x(spline_points),y(spline_points),'.-r')
            end
            plot(x,y,'.-r')
            u = linspace(0,1,length(x));
            fitu = linspace(0,1,1000);
            fitx = interp1(u,x,fitu,'spline');
            fity = interp1(u,y,fitu,'spline');
            fitx = round(fitx);
            fity = round(fity);
            scatter(fitx,fity,'.')
            saveas(gcf,['X:\data\3D\worm_spline\splines\' mov_name(1:length(mov_name)-4) '_spline_frame_' num2str(rf_idx(i)) '.bmp'],'bmp');
            pause(2)
            close
            fitted = [fitx' fity'];
            fitted = unique(fitted,'rows','stable'); % original version was out of order as the option 'stable' was not used
            %                 clear x y fitx fity fitu u
        end
        vid_out = VideoWriter(['X:\data\3D\worm_spline\avi\' mov_name(1:length(mov_name)-4) '_frames_' num2str(rf_idx(i)) '-' num2str(rf_idx(i)+25) '.avi'],'Grayscale AVI');
        open(vid_out)
        for n = rf_idx(i)+1:1:rf_idx(i)+25
            v.CurrentTime = time_array(n);
            current_frame = (readFrame(v));
            writeVideo(vid_out,current_frame)
        end
        close(vid_out)
        time = random_frames(i);
        
        fid = fopen(['X:\data\3D\worm_spline\csv\' mov_name(1:length(mov_name)-4) '_frame_' num2str(rf_idx(i)) '.csv'],'wt');
        fprintf(fid,'%s\n', ['# video file name: ' mov_name(1:length(mov_name)-4) '_frames_' num2str(movie_frame) '-' num2str(movie_frame+25) '.avi']);
        fprintf(fid,'%s\n', '# frame number: 0');
%         fprintf(fid,'%s\n', '# frame number: 13');
        fprintf(fid,'%s\n', ['# date: ' date]);
        fprintf(fid,'%s\n', ['# strain: ' strain]);
        fprintf(fid,'%s\n', ['# viscosity: ' media2]);
        fprintf(fid,'%s\n', ['# magnification: ' mag]);
        fprintf(fid,'%s\n', ['# original movie file name: ' mov_name]);
        fprintf(fid,'%s\n', ['# original frame number: ' num2str(movie_frame)]);
        fprintf(fid,'%s\n', ['# time: ' num2str(time)]);
        fprintf(fid,'%s\n', ['# number of points clicked: ' num2str(length(x))]);
        fclose(fid);
        dlmwrite(['X:\data\3D\worm_spline\csv\' mov_name(1:length(mov_name)-4) '_frame_' num2str(rf_idx(i)) '.csv'],fitted,'-append');
        
        save (['X:\data\3D\worm_spline\mat\' mov_name(1:length(mov_name)-4) '_frame_' num2str(rf_idx(i)) '.mat']);
        %         save (['X:\' week '\3D\video\' strain '\' media '\' date '_trial' trial '_cam' cam '_frame' num2str(frame)],'x','y','fitx_x','fity_x','good_spline','head','frame','week','date','trial','strain','media','cam','time','fitted');
        close
    end
    clearvars -except m mov_dir files random_frames week date trial strain media media2 mag frame mov_dir files frame_index movie cam specified_frames
end