clear all
close all

date=161215;
calib=2;

for cam=1:3;
    
    % get the number of calibration .bmp files in the directory
    D = dir(['P:\3D Data\Calibration\' num2str(date) '\Cam' num2str(cam) '\Calib' num2str(calib), '\*.bmp']);
    Num = length(D(not([D.isdir])));

        for frame=1:Num

            im=imread(['P:\3D Data\Calibration\' num2str(date) '\Cam' num2str(cam) '\Calib' num2str(calib) '\Calib' num2str(calib) '_' num2str(date) '_Cam' num2str(cam) '-' num2str(frame) '.bmp']);

            R = roipoly(im);
            im2 = im;
            im2(~R) = 0; %set things not in the mask to zero
            imshow(im2);

            imwrite(im2,['P:\3D Data\Calibration\' num2str(date) '\Cam' num2str(cam) '\Calib' num2str(calib) '\Calib' num2str(calib) '_' num2str(date) '_Cam' num2str(cam) '-' num2str(frame) '_masked.bmp'])
            close
        end
end