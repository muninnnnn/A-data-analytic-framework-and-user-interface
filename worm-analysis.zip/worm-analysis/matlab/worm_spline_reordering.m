clear
close all
mov_dir = 'X:\20160425\3D\video\N2\0_75pc\head\';

dot_mat_files = dir([mov_dir '\*.mat']);

for m = 1:length(dot_mat_files)
    load([mov_dir dot_mat_files(m).name])
    fitted = [fitx' fity'];
    fitted = unique(fitted,'rows','stable');
    fid = fopen([mov_dir mov_name(1:length(mov_name)-4) '_frame' num2str(frame) '.csv'],'wt');
    fprintf(fid,'%s\n', ['# video file name: ' mov_name]);
    fprintf(fid,'%s\n', ['# frame number: ' num2str(frame)]);
    fprintf(fid,'%s\n', ['# time: ' num2str(time)]);
    fprintf(fid,'%s\n', ['# number of points clicked: ' num2str(length(x))]);
    fclose(fid);
    dlmwrite([mov_dir mov_name(1:length(mov_name)-4) '_frame' num2str(frame) '.csv'],fitted,'-append');
%     save ([mov_dir mov_name(1:length(mov_name)-4) '_frame' num2str(frame) '.mat']);
end