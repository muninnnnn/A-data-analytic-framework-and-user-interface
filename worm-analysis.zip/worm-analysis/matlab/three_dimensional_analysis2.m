clear
close all

fps = 25;

data_folder = 'X:\data\3D\curve\223137\analysis\';

trials = dir(data_folder);
dirFlags = [trials.isdir];
% trials = trials(dirFlags);
trials = trials(arrayfun(@(x) x.name(1), trials) ~= '.');

for m = 100:114%length(trials)
    load ([data_folder trials(m).name], '-regexp', '^(?!data_folder$|folder$).');
    %     load ([data_folder trials(m).name], '-regexp', '^(?!trials$|data_folder$|m$).');
    %     trial = trials(m);
    %     folder = ([data_folder '\' trial.name]);
    %     [ points, curvatures, times ] = readPvd_curve([folder '\skeletons_worm.pvd']);
    %     mm = extractmidpoint( points );
    %
    %     save ([data_folder(1:length(data_folder)-7) '\analysis\' trial.name '_PE_data.mat'] ,'-regexp','^(?!(dirFlags|trials)$). ');
    % end
    if size(mm,2)>=9
        
        figure(1)
        plot3(mm(1,:),mm(2,:),mm(3,:),'b')
        xlabel('mm')
        ylabel('mm')
        zlabel('mm')
        title(trial.name,'Interpreter', 'none')
        
        mkdir([data_folder(1:length(data_folder)) '\plots\trajectories\']);
        mkdir([data_folder(1:length(data_folder)) '\plots\100frames_curves\']);
        mkdir([data_folder(1:length(data_folder)) '\plots\speed\']);
        mkdir([data_folder(1:length(data_folder)) '\plots\25frames_curves\']);
        mkdir([data_folder(1:length(data_folder)) '\plots\curvature\']);
        mkdir([data_folder 'PE_data\']);
        
        saveas(gcf,[data_folder(1:length(data_folder)) '\plots\trajectories\' trial.name '_unfilt_traj.bmp'],'bmp');
        
        % filter data using a third order butterworth filter (calculated in a
        % different script - buttered_worms.m
        fc = 2.9; % frequency cutoff determined by buttered_worms.m - was 1.7 for 20160427_0_75_pc_trial01
        fs = 25; % frequency of recording
        
        [b,a] = butter(3,fc/(fs/2),'low');
        filt_x = filtfilt(b,a,mm(1,:));
        filt_y = filtfilt(b,a,mm(2,:));
        filt_z = filtfilt(b,a,mm(3,:));
        filt_mm = [filt_x; filt_y; filt_z];
        
        % plot filtered x,y,z data
        figure(1);hold on
        plot3(filt_x,filt_y,filt_z,'r')
        xlabel('mm')
        ylabel('mm')
        zlabel('mm')
        title(trial.name,'Interpreter', 'none')
        
        saveas(gcf,[data_folder(1:length(data_folder)) '\plots\trajectories\' trial.name '_trajectories.bmp'],'bmp');
        
        % plot filtered x,y,z data
        figure(2);hold on
        plot3(filt_x,filt_y,filt_z,'r')
        xlabel('mm')
        ylabel('mm')
        zlabel('mm')
        title(trial.name,'Interpreter', 'none')
        
        saveas(gcf,[data_folder(1:length(data_folder)) '\plots\trajectories\' trial.name '_filt_traj.bmp'],'bmp');
        %%% speed calculations
        
        % raw speed
        mm_diff = diff(mm,1,2);
        speed = zeros(length(mm_diff),1);
        
        for k = 1:length(mm_diff)
            speed(k) = sqrt(sum(mm_diff(:,k).^2))/(1/fps);
        end
        mean_speed = mean(speed);
        
        % filtered speed
        filt_mm_diff = diff(filt_mm,1,2);
        filt_speed = zeros(length(filt_mm_diff),1);
        
        for k = 1:length(filt_mm_diff)
            filt_speed(k) = sqrt(sum(filt_mm_diff(:,k).^2))/(1/fps);
        end
        mean_filt_speed = mean(filt_speed);
        
        figure(3)
        plot((1:length(speed))/fps,filt_speed,'r')
        xlim([0 (length(speed)/fps)])
        xlabel('time (s)')
        ylabel('speed (mm s^-^1)')
        title([trial.name ' speed'],'Interpreter', 'none')
        saveas(gcf,[data_folder(1:length(data_folder)) '\plots\100frames_curves\' trial.name '_filt_speed.bmp'],'bmp');
        
        % plot both raw and filtered speed against time
        figure(4)
        plot((1:length(speed))/fps,speed);hold on
        plot((1:length(speed))/fps,filt_speed,'r')
        xlim([0 (length(speed)/fps)])
        xlabel('time (s)')
        ylabel('speed (mm s^-^1)')
        title([trial.name ' speed'],'Interpreter', 'none')
        saveas(gcf,[data_folder(1:length(data_folder)) '\plots\speed\' trial.name '_speeds.bmp'],'bmp');
        
        % convert Cartesian coordinates to spherical coordinates
        [filt_azimuth,filt_elevation,filt_r] = cart2sph(filt_mm(1,:),filt_mm(2,:),filt_mm(3,:));
        [azimuth,elevation,r] = cart2sph(mm(1,:),mm(2,:),mm(3,:));
        
        
        figure(5)
        for j = 1:25:length(points)
            plot3(points{1,j}(1,:),points{1,j}(2,:),points{1,j}(3,:),'o');hold on;
        end
        xlabel('mm')
        ylabel('mm')
        zlabel('mm')
        title([trial.name ' curve plots 1 second'],'Interpreter', 'none')
        saveas(gcf,[data_folder(1:length(data_folder)) '\plots\25frames_curves\' '_25frames_curves.bmp'],'bmp');
        
        figure(6)
        for j = 1:25:length(points)
            plot3(curvatures{1,j}(1,:),curvatures{1,j}(2,:),curvatures{1,j}(3,:),'o');hold on;
        end
        %     xlabel('mm')
        %     ylabel('mm')
        %     zlabel('mm')
        title([trial.name ' curve plots'],'Interpreter', 'none')
        saveas(gcf,[data_folder(1:length(data_folder)) '\plots\curvature\' trial.name '_curvature.bmp'],'bmp');
        
        figure(7)
        for j = 1:100:length(points)
            plot3(points{1,j}(1,:)+j,points{1,j}(2,:),points{1,j}(3,:),'o');hold on;
        end
        xlabel('mm')
        ylabel('mm')
        zlabel('mm')
        title([trial.name ' curve plots 4 seconds'],'Interpreter', 'none')
        saveas(gcf,[data_folder(1:length(data_folder)) '\plots\100frames_curves\' trial.name '_100frames_curves.bmp'],'bmp');
        
        %%%
        % do stuff here
        close all
        
        save ([data_folder 'PE_data\' trial.name '_PE_data.mat'], '-regexp', '^(?!data_folder$|dirFlags$|a$|b$|j$|k$).');
    else
        
        fprintf(['cannot process movie ' trial.name ]);
        fileID = fopen([data_folder 'PE_data\error_' trial.name '.txt'],'w');
        fprintf(fileID, 'not enough points to process');
        fclose(fileID);
    end
    
    clearvars -except trials m data_folder fps dirFlags
end
