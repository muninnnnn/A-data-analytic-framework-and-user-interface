function [planeSum,lineSum] = fitPlane( points )

mid = mean( points' )';

R = bsxfun(@minus,points,mid)';
[V,D] = eig(R'*R);
%Extract the output from the eigenvectors
n = V(:,1);
V = V(:,2:end);

planeSum = 0.0;
lineSum = 0.0;
for j = 1 : length(points)
    planeSum = planeSum + (n'*(points(:,j)-mid))^2;
    
    q = V(:,2)'*(points(:,j)-mid) * V(:,2) + mid;
    lineSum = lineSum + ( q(1) - points(1,j) )^2 + ( q(2) - points(2,j) )^2 + ( q(3) - points(3,j) )^2;
end

planeSum = sqrt(planeSum/length(points));
lineSum = sqrt(lineSum/length(points));

return;

fig = figure(1);
hold on;
plot3( points(1,:),  points(2,:), points(3,:), 'b' );
plot3( [ mid(1), mid(1) + V(1,1) ], [ mid(2), mid(2) + V(2,1) ], [ mid(3), mid(3) + V(3,1) ], 'r' );
plot3( [ mid(1), mid(1) + V(1,2) ], [ mid(2), mid(2) + V(2,2) ], [ mid(3), mid(3) + V(3,2) ], 'g' );
pause;
hold off;
end