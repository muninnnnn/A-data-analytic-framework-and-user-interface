% gram-schmit
function Q = GS( A )
[m,n] = size(A);
Q = zeros(m,n);
for j = 1:n
   v = A(:,j);
   for i = 1:j-1
      v = v - v'*Q(:,i)*Q(:,i);
   end
   if( norm(v) > 1.0e-12 )
       Q(:,j) = v / norm(v);
   end
end

% remove zero columns
Q( :, ~any(Q,1) ) = [];
end