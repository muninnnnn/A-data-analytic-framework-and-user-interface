function [X,W] = vecToCurvatures( vec )
% option 1
% W = reshape( vec, 3, [] );

% options 2
    nPoints = length(vec)/2;
    m1 = vec(1:nPoints);
    m2 = vec(nPoints+1:end);

    nPoints =  length(m1);
    h = 1.0 / nPoints;

    tau = zeros( 3, nPoints );
    M1 = zeros( 3, nPoints );
    M2 = zeros( 3, nPoints );
    tau(:,1) = [1;0;0];
    M1(:,1) = [0;1;0];
    M2(:,1) = [0;0;1];

    for j = 2:nPoints

        tauJtilde = tau(:,j-1) + h * ( m1(j) * M1(:,j-1) + m2(j) * ...
                                     M2(:,j-1) );
        M1Jtilde = M1(:,j-1) + h * ( -m1(j) * tau(:,j-1) );
        M2Jtilde = M2(:,j-1) + h * ( -m2(j) * tau(:,j-1) );

        % is this needed if we do the above better?
        tau(:,j) = tauJtilde / norm(tauJtilde);
        M1(:,j) = M1Jtilde / norm(M1Jtilde);
        M2(:,j) = M2Jtilde / norm(M2Jtilde);

        %disp( [ norm(tauJtilde), norm(M1Jtilde), norm(M2Jtilde)]);
        %disp( [dot(tau(:,j), M1(:,j)),dot(tau(:,j), M1(:,j)) ]);
        %pause
    end

    X = zeros( 3, nPoints );
    W = zeros( 3, nPoints );

    for j = 2:nPoints
        X(:,j) = X(:,j-1) + h * tau(:,j);
        W(:,j) = m1(j) * M1(:,j) + m2(j) * M2(:,j);
    end
end