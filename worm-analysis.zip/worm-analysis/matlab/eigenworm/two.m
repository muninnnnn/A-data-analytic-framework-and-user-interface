 FUT n/ ¡D¢n£W¥¤§¦P¨z©Tª¨£©¬«¬©	­g®§¤§¯U=¨¤§©T­
°U±i²?J³K/´dµ 
v j	.GJ@HR/M4FM<IJEH[?6R j I7\ A
 F¶nTdr/·=
¸ ²X³Kg´na¹²?U³}u´º>»F±²?J³Kg´µ ¼©D¦W¤½¿¾ A(:, j) ¨ª© v ½À©¬¼©¬ÁÂg¢U¢UÃg¢7¾
°° · ¸ ²X³K/´u»7¹²?J³Xu´µ  MK[/j?C52L47<CCL,/.|S/2LInmK.<CL@HIJR (q
T
i aj )qi = (q
T
i
v)qi
F=Ä 
v @HM-R/IªOÅST.2KS	.R/A/@B<[/EH472{C5Ic47EBEÆI7\ q1, . . . , qj−1
¸ ²L³K/´n7TF7Ç1² ° ´µ
¹²?U³K/´n°¬È ¸ ²Lb³L/´µ  R/I72L647EH@BÉ. v C5IzjT.|CL,/.|R/.XwaC[/R/@QC-VJ.<C5I72 qj
F=Ä
_\dtJIJ[f[/R/A/IzC5,/.3EH47M
