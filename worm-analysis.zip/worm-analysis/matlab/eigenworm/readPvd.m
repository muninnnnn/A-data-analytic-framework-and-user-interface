function [ points, curvatures, times ] = readPvd( filename )

% Takes pvd file (understand this code from bottom up)
% e.g.
% '/home/csunix/scjde/not-backed-up/worms-curve-worm/build/output/worm.pvd'
%
% '/usr/not-backed-up/scjde/worms-curve-worm/build/worm.pvd'

% Problem "curvatures" and "points" are identical :s

pvdFile =  parseXML( filename );
[pathstr,a,b] = fileparts(filename);

points= {};
curvatures = {};
times = [];

Collection = pvdFile.Children(2);
DataSets = Collection.Children;
for data = DataSets,
   if strcmp( data.Name, 'DataSet' );     % string compare: strcmp('cat','cat') = 1 and strcmp('cat', 'dog') = 0 
       for v = data.Attributes,
           if strcmp( v.Name, 'file' )
               [points{end+1},curvatures{end+1}] = readVtu( strcat(pathstr, '/', + v.Value) );  % strcat joins strings end-to-end horizontally strcat('cat','/','dog') = cat/dog
           end
           if strcmp( v.Name, 'timestep' )
               times = [times, str2num(v.Value)];
           end
       end
   end
end
end

function [ points, curvatures ] = readVtu( filename ) % sum(vtu) = pvd(?)
disp( sprintf('reading %s',filename) ); % comment to speed up
vtuFile =  parseXML( filename );
pieces = vtuFile.Children(2).Children(2);

for f = pieces.Attributes,
   if strcmp( f.Name, 'NumberOfPoints' );
       nPoints = int16(str2num( f.Value ));       % red herring
   end
end

%  Added by Jack - navigate pvd file to find "points" copying method for
%  getting curvature (lines 58-62)
kiddo1 = returnChild('Points', pieces );
kiddo2 = returnChild('DataArray' , kiddo1 );
data   = strsplit(kiddo2.Children(1).Data);
S = sprintf('%s ' , data{:});
points = sscanf( S, '%f' );
% Jack end

% Original code before Jack tried to fix it
% data = strsplit(pieces.Children(2).Children(2).Children(1).Data);
% S = sprintf('%s ', data{:} );
% points = sscanf( S, '%f' );

child1 = returnChild( 'PointData', pieces ); %search all children for PointData (?)
child2 = returnChild( 'DataArray', child1 );
data2 = strsplit(child2.Children(1).Data);
P = sprintf('%s ', data2{:});
curvatures = sscanf( P, '%f' );

% reshape data to npoint columns and unknown rows
points = reshape( points, [], nPoints );
curvatures = reshape( curvatures, [], nPoints );

end

function c = returnChild( name, s )

c = false;
for child = s.Children
   if strcmp( child.Name, name )  %if childname is identical to input name
      c = child;
      break;
   end
end
end

function theStruct = parseXML(filename)   % http://uk.mathworks.com/help/matlab/ref/xmlread.html
% PARSEXML Convert XML file to a MATLAB structure.
try
   tree = xmlread(filename); %parses xml files
catch
   error('Failed to read XML file %s.',filename); %if statements between try and catch fail; execute statements between catch and end.
end

% Recurse over child nodes. This could run into problems 
% with very deeply nested trees.
try
   theStruct = parseChildNodes(tree);
catch
   error('Unable to parse XML file %s.',filename);
end
end


% ----- Local function PARSECHILDNODES -----
function children = parseChildNodes(theNode)
% Recurse over node children.
children = [];
if theNode.hasChildNodes
   childNodes = theNode.getChildNodes;
   numChildNodes = childNodes.getLength;
   allocCell = cell(1, numChildNodes);

   children = struct(             ...
      'Name', allocCell, 'Attributes', allocCell,    ...
      'Data', allocCell, 'Children', allocCell);

    for count = 1:numChildNodes
        theChild = childNodes.item(count-1);
        children(count) = makeStructFromNode(theChild);
    end
end
end

% ----- Local function MAKESTRUCTFROMNODE -----
function nodeStruct = makeStructFromNode(theNode)
% Create structure of node info.

nodeStruct = struct(                        ...
   'Name', char(theNode.getNodeName),       ...
   'Attributes', parseAttributes(theNode),  ...
   'Data', '',                              ...
   'Children', parseChildNodes(theNode));

if any(strcmp(methods(theNode), 'getData'))
   nodeStruct.Data = char(theNode.getData);  % if any nodes match, put data in node structure
else
   nodeStruct.Data = '';
end
end

% ----- Local function PARSEATTRIBUTES -----
function attributes = parseAttributes(theNode)
% Create attributes structure.

attributes = [];
if theNode.hasAttributes
   theAttributes = theNode.getAttributes;
   numAttributes = theAttributes.getLength;
   allocCell = cell(1, numAttributes);         % Mat of empty cells
   attributes = struct('Name', allocCell, 'Value', ...
                       allocCell);

   for count = 1:numAttributes
      attrib = theAttributes.item(count-1);
      attributes(count).Name = char(attrib.getName);
      attributes(count).Value = char(attrib.getValue);
   end
end
end
