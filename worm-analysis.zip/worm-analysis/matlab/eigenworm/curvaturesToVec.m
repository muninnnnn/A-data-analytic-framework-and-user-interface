function vec = curvaturesToVec( X, W )
% option 1
% vec = reshape( W, [], 1 );

% option 2
    [ tau, M1, M2 ] = findFrame( X );
    [ m10, m20 ] = decompose( M1, M2, W );
    [ m1, m2 ] = normalised( m10, m20 );
    vec = [ m1(:) ; m2(:) ];
end

% find frame
function [ tau, M1, M2 ] = findFrame( X )

    nPoints = length(X);
    tau = zeros( 3, nPoints );
    M1 = zeros( 3, nPoints );
    M2 = zeros( 3, nPoints );
    for j = 1 : nPoints-1
        tauJtilde = X(:,j+1) - X(:,j);
        tau(:,j) = tauJtilde / norm( tauJtilde );

        if( j == 1 )
            A = [ tau(:,j), [1;0;0], [0;1;0], [0;0;1] ];
            Q = GS(A);
            M1tilde = Q(:,2);
            M1(:,j) = M1tilde / norm(M1tilde);
            M2(:,j) = cross(tau(:,j),M1(:,j));
        else
            M1tilde = M1(:,j-1) - tau(:,j)' * M1(:,j-1) * tau(:,j);
            M1(:,j) = M1tilde / norm(M1tilde);
            M2(:,j) = cross(tau(:,j),M1(:,j));
        end
    end
end

% decompose
function [m1, m2] = decompose( M1, M2, W )
    nPoints = length(W);
    m1 = zeros( nPoints, 1 );
    m2 = zeros( nPoints, 1 );
    for j = 2:nPoints-1,
        m1(j) = M1(:,j)' * W(:,j);
        m2(j) = M2(:,j)' * W(:,j);
    end
end

% normalise
function [m1, m2] = normalised( m10, m20 )
  [ v, j ] = max( m10.^2 + m20.^2 );
  theta = atan2( -m20(j), m10(j) );
  m1m2 = [ cos(theta), -sin(theta) ; sin(theta), cos(theta) ] * [ ...
      m10'; m20' ];

  m1 = m1m2(1,:);
  m2 = m1m2(2,:);
end

% gram-schmit
function Q = GS( A )
[m,n] = size(A);
Q = zeros(m,n);
for j = 1:n
   v = A(:,j);
   for i = 1:j-1
      v = v - v'*Q(:,i)*Q(:,i);
   end
   if( norm(v) > 1.0e-12 )
       Q(:,j) = v / norm(v);
   end
end

% remove zero columns
Q( :, ~any(Q,1) ) = [];
end