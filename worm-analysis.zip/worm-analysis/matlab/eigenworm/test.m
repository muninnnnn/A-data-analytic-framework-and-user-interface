function test

% datadir='/run/user/347601/gvfs/sftp:host=marc/home/marc1_d/scsrih/Files/output-curve/223137/'
    datadir='/usr/not-backed-up/scstr/Software/WORMS/data-analysis/matlab/eigenworm/data/nobackup/scsrih/output-curve/223137/'

subdirs=[ 'N2_0_25pc_20160718_trial01';
'N2_0_25pc_20160718_trial02';
'N2_0_25pc_20160718_trial03';
'N2_0_25pc_20160718_trial04';
'N2_0_25pc_20160718_trial05';
'N2_0_25pc_20160718_trial06';
'N2_0_25pc_20160718_trial07';
'N2_0_25pc_20160718_trial08';
'N2_0_25pc_20160718_trial09';
'N2_0_25pc_20160718_trial10';
'N2_0_25pc_20160718_trial11';
'N2_0_25pc_20160718_trial12';
'N2_0_25pc_20160718_trial13';
'N2_0_25pc_20160718_trial14';
'N2_0_25pc_20160718_trial15';
'N2_0_75pc_20160427_trial01';
'N2_0_75pc_20160427_trial02';
'N2_0_75pc_20160427_trial03';
'N2_0_75pc_20160427_trial04';
'N2_0_75pc_20160427_trial05';
'N2_1_00pc_20160426_trial02';
'N2_1_00pc_20160426_trial03';
'N2_1_00pc_20160426_trial04';
'N2_1_00pc_20160426_trial05';
'N2_1_25pc_20160425_trial03';
'N2_1_25pc_20161017_trial03';
'N2_1_25pc_20161017_trial04';
'N2_1_25pc_20161017_trial07';
'N2_1_25pc_20161017_trial08';
'N2_1_25pc_20161017_trial09';
'N2_1_25pc_20161017_trial10';
'N2_1_25pc_20161128_trial01';
'N2_1_25pc_20161128_trial02';
'N2_1_25pc_20161128_trial03';
'N2_1_25pc_20161128_trial04';
'N2_1_25pc_20161128_trial05';
'N2_1_25pc_20161128_trial07';
'N2_1_25pc_20161128_trial08';
'N2_1_25pc_20161128_trial09';
'N2_1_25pc_20170508_trial01';
'N2_1_25pc_20170508_trial02';
'N2_1_25pc_20170508_trial03';
'N2_1_25pc_20170508_trial04';
'N2_1_25pc_20170508_trial05';
'N2_1_25pc_20170508_trial06';
'N2_1_50pc_20160802_trial01';
'N2_1_50pc_20160816_trial02';
'N2_1_50pc_20160817_trial01';
'N2_1_50pc_20160817_trial02';
'N2_1_50pc_20161017_trial01';
'N2_1_50pc_20161017_trial02';
'N2_1_50pc_20161129_trial01';
'N2_1_50pc_20161129_trial02';
'N2_1_50pc_20161129_trial03';
'N2_1_50pc_20161129_trial04';
'N2_1_75pc_20160428_trial01';
'N2_1_75pc_20160428_trial02';
'N2_1_75pc_20160428_trial03';
'N2_1_75pc_20160428_trial04';
'N2_1_75pc_20161021_trial01';
'N2_1_75pc_20161024_trial01';
'N2_1_75pc_20161024_trial02';
'N2_1_75pc_20161024_trial03';
'N2_1_75pc_20161024_trial04';
'N2_1_75pc_20161124_trial01';
'N2_1_75pc_20161124_trial02';
'N2_2_00pc_20160615_trial01';
'N2_2_00pc_20160615_trial02';
'N2_2_00pc_20160615_trial03';
'N2_2_00pc_20160615_trial04';
'N2_2_00pc_20160615_trial05';
'N2_2_00pc_20160615_trial06';
'N2_2_00pc_20160615_trial07';
'N2_2_00pc_20160615_trial08';
'N2_2_00pc_20160615_trial09';
'N2_2_00pc_20160615_trial10';
'N2_2_00pc_20160615_trial11';
'N2_2_00pc_20160615_trial12';
'N2_2_00pc_20161019_trial01';
'N2_2_00pc_20161019_trial02';
'N2_2_00pc_20161020_trial01';
'N2_2_25pc_20160711_trial01';
'N2_2_25pc_20160711_trial02';
'N2_2_25pc_20160711_trial03';
'N2_2_25pc_20160711_trial04';
'N2_2_25pc_20160711_trial05';
'N2_2_25pc_20160711_trial06';
'N2_2_25pc_20160711_trial07';
'N2_2_50pc_20160614_trial02';
'N2_2_50pc_20160614_trial03';
'N2_2_75pc_20160713_trial01';
'N2_2_75pc_20160713_trial02';
'N2_3_50pc_20160715_trial01';
'N2_3_50pc_20160715_trial02';
'N2_3_50pc_20160715_trial03';
'N2_3_75pc_20160801_trial01';
'N2_4_00pc_20160714_trial01';
'N2_4_00pc_20160714_trial02';
'N2_4_00pc_20160714_trial03';
'N2_4_00pc_20160714_trial04';
'N2_4_00pc_20160714_trial05';
'N2_4_00pc_20160714_trial06' ];

nFrames = length(subdirs);
for iter = 1 : nFrames
    sd = subdirs(iter,:);
    disp(sd);
    xmlFn = strcat(datadir, '/', sd, '/skeletons_worm.pvd');
    if exist( xmlFn, 'file') ~= 2
        disp('skipping');
        continue;
    end

    [ X, W, t ] = readPvd( xmlFn );
    nTimes = length(t);
    for k = 1 :nTimes
        vecFn =  sprintf( '%s_%d.mat', sd, k );
        if exist( vecFn, 'file') ~= 2
            disp('skipping frame');
            continue;
        end

        vec = curvaturesToVec( X{k}, W{k} );
        save( vecFn, 'vec', '-double');
        disp(sprintf('saving to %s', vecFn ));

    end
end
end