function testPca

[ X, W, t ] = readPvd( 'data/skeletons_worm.pvd' );

nTimes = length(t);

for k = 1 :nTimes
    vec = curvaturesToVec( X{k}, W{k} );

    if k == 1
        data = vec;
    else
        data = [ data, vec ];
    end
end

size( data * data' )
[V,D] = eig( data * data' );

for i = 1:10
    vec = V(i,:);
    [myX,myW] = vecToCurvatures( vec );
    plot3( myX(1,:), myX(2,:), myX(3,:) );
    axis equal;
    pause
end

end