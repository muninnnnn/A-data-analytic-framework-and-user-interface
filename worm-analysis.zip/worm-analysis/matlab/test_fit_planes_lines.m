function test
[pts, W, t ] = readPvd('X:\data\3D\N2\curve\N2_4_00pc_20160714_trial02\skeletons_worm.pvd');

nTimes = length(t);
for k = 1 : nTimes
   [planeFit(k), lineFit(k)] = fitPlane( pts{k} );
   
   sum = 0.0;
   for j = 1 : length(W{k})
       for d = 1 : 3
        sum = sum + (W{k}(d,j))^2;
       end
   end
   totalCurvature(k) = sqrt(sum/length(W{k}));
end

clf;
hold on;
xlabel('time (s)');
% xlim([0 length(t)])

yyaxis left
semilogy( t, planeFit, 'b' );
ylabel('Plane fit (mm)');

yyaxis right
semilogy( t, lineFit, 'r' );
ylabel('Line fit (mm)')

end