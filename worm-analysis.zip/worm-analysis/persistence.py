

def getD(c):
	L = len(c)
	D = []
	for dt in range(1, L):
		s = 0
		for i in range(L - dt):
			s += norm(c[i] - c[i+dt])
		s /= float(L - dt)
		# print(dt, s)
		D.append(s)
	return D
