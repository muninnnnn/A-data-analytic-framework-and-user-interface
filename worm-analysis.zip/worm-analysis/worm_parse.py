#!/usr/bin/env python
from __future__ import print_function

import numpy as np
from sklearn.decomposition import PCA
import xml.etree.ElementTree
import os
from os.path import dirname
from sys import argv
from xwToMs import xwToM, total_twist, cXwToMs, xwToMs
from msToXw import mToXw, cMToXw

from xml.etree.ElementTree import ParseError
from error import eprint
from numpy.linalg import norm
from numpy import array, dot
from pvdTD import total_displacement

from util import rigid_transform_3D
from util import XtoW


from error import except_bad

def point_distance(X, Y):
	assert(len(X) == len(Y))
	d=0
	for i,j in zip(X, Y):
		d += norm2(i-j)

	from math import sqrt
	return sqrt(d/len(X))

# directions
WORM_ERROR = 0
WORM_FWD = 1
WORM_BACK = 2
WORM_STILL = 3


def norm2(x):
	return np.dot(x,x)

# parse vtu file into numpy thing
def ptsFromVtu( filename, data=False ):
    try:
        file = open(filename)
#    except FileNotFoundError:
#        return [], [], []
    except IOError:
    # yikes. errors are different between python versions??!
        if data:
            return [], [], [], []
        else:
            return [], [], []

    readingPoints = False
    ptsData = []
    readingW = False
    WData = []
    readingU = False
    UData = []

    while(True):
        line = file.readline()

        if(line==""):
           break

        line=line[:-1]

        if line[0:9]=="<!-- DATA":
            break

        if '<Points>' in line:
            readingPoints = True
            continue
        if '</Points>' in line:
            readingPoints = False
            continue

        if '<DataArray type="Float32" Name="W" NumberOfComponents="3">' in line:
            readingW = True
            continue

        if '<DataArray type="Float32" Name="u" NumberOfComponents="1">' in line:
            readingU = True
            continue

        if '</DataArray>' in line:
            readingPoints = False
            readingW = False
            readingU = False
            continue

        if readingPoints and not 'DataArray' in line:
            for d in line.split():
                ptsData.append( float(d) )

        if readingW and not 'DataArray' in line:
            for d in line.split():
                WData.append( float(d) )

        if readingU and not 'DataArray' in line:
            for d in line.split():
                UData.append( float(d) )




    nPts = len(ptsData)//3

    X = [ np.array(ptsData[3*j:3*(j+1)]) for j in range(nPts) ]
    W = [ np.array(WData[3*j:3*(j+1)]) for j in range(nPts) ]
    U = UData

    if(not data):
        return [ X, W, U, data ]
    else:
        pass

    data={}
    if line[0:9]=="<!-- DATA":
     keys=file.readline()[:-1].split()
     values=file.readline()[:-1].split()

     for x, y in zip(keys, values):
        data[x]=float(y)


    return [ X, W, U, data ]

def wormFromVTU(x):
	return ptsFromVtu(x, True)

def isflipped(t):
	try:
		return t.isflipped()
	except AttributeError:
		pass
			
	id=4
	if(not t):
		return False
	if type(t)!=list:
		return False
	if type(t)==str:
		eprint("isfl " + t)
	if len(t)<=id:
		return False
	if type(t[id])==str and len(t[id]) and t[id][0]=="1":
		return True
	if t[id]==1:
		return True
	return False

def stringtodir(t):
	if t=="fwd":
		return 1
	elif t=="back" or t=="bwd":
		return -1
	elif t=="still":
		return 2
	elif t=="struggle":
		return 3
	elif t!="":
		eprint("bad direction " + t)
		return 99
		
	return 0

def direction(t):
	try:
		return t.direction()
	except AttributeError:
		pass

	if type(t)!=list:
		return 0
	
	g = 0
	if len(t)>0:
		g = stringtodir(t[0])
	return g

WORM_GAIT_HELIX = 1
WORM_GAIT_FWD = 1024
WORM_GAIT_BACK = 4096

def is_fwd(n):
	return n & WORM_GAIT_FWD

def is_helix(n):
	if type(n)==str:
		n=int(n)
	return n & WORM_GAIT_HELIX

from gait import stringtogait

gaitname=[ "helix", "struggle", "planar", "turn", "3d", \
		"coil", "weather", "still", "loop", "lasso", "fwd", "turn",
		"back", "still", "search"]

def good_cog(t):
	try:
		return t.good_cog()
	except AttributeError:
		# is it a list?

		try:
			if len(t)>6:
				return int(t[6])
		except:
			pass

		return gait(t)

def gait(t):
	try:
		return t.gait()
	except AttributeError:
		pass

	if type(t)!=list:
		# eprint("there is no gait here")
		return 0
	# eprint("its a list", str(t))
	
	g = 0
	if len(t)>0:
		g |= stringtogait(t[0])
	if len(t)>1:
		g |= stringtogait(t[1])
	if len(t)>2:
		g |= stringtogait(t[2])

	# eprint("find gait ",t, g)
	return g


# wrong file...

from worm import worm

# duplicate? use class worm maybe
class worm_still:
	def __init__(self, head, data):
		self._coeffs = []
		self._Xr = []
		# BUG: check if head is a list and data is a string
		data = data[0:-1].split()

		self._dict={}

		j = 0
		for i in head:
			try:
				self._dict[i] = data[j]
			except IndexError:
				break
			j += 1

	def get_worm(self):
		filename = self._dict["filename"]
		return worm(self._dirname + '/' + filename)

   # pretend XML
	def findall(self, key):
		if key == "Main":
			filename = self._dirname+"/"+self._dict["filename"]
			return
		return

	def set_dir(self, d):
		self._dirname = d

   # pretend XML
	def get(self, key):
		if key=="timestep":
			return 0; #incomplete
		elif key=="frame":
			return int(self._dict['framenumber'])
		elif key=="file":
			# BUG this is not the file
			# filename = self._dirname+"/"+self._dict["filename"]
			try:
				filename = self._dict["filename"]
			#eprint ("get" + filename)
				return filename
			except KeyError:
				return("no_file_in_worm_parse")
		else:
			return self._dict[key]

class wormindex:
	def __init__(self, filename):
		f = open(filename,'r')
		# eprint("...", filename)
		l = next(f)
		if l[0] != '#':
			raise BaseException("fixme, need proper exception")
		if l[-1] != '\n':
			raise "fixme, need proper exception"

		self._index = []
		self._dirname = dirname(filename)
		self._header = l[1:-1].split()
		self._i = 0;

		# BUG wrong loop invariant.
		while(True):
			try:
				l = next(f)
			except StopIteration:
				break

			newworm = worm_still(self._header, l)
			newworm.set_dir(self._dirname)
			self._index.append(newworm)

	def next(self):
		n = self._i
		self._i += 1
		return self._index[n]

	def __getitem__(self, i):
		# eprint("wormindex[]", i)
		return self._index[i]

def pvdparse(filename):

	if filename[-3:] == "txt":
		#eprint("Txt only " + filename + "\n")
		return wormindex(filename)
	try:
		eprint("trying xml " + filename + "\n")
		tree = xml.etree.ElementTree.parse(filename)
		root = tree.getroot()[0]
		mainPvd = root.findall('DataSet')
		return mainPvd
	except IOError:
		eprint("not there: " + filename + "\n")
	except ParseError:
		eprint("probably not an xml file " + filename + "\n")

	try:
		index = wormindex(filename)
	except IOError:
		index = wormindex(filename[:-3]+"txt")

	return index

if __name__ == "__main__":
	a = pvdparse(argv[1])
	print(a[1])
	print("timestep", a[1].get('timestep'))
	print("...", a[1].get('file'))
	for i in a:
		w = i.get_worm()
		print(w.center_of_gravity())


if 0 and __name__=="__main__":
	X, W, U = ptsFromVtu("test_01.vtu")
	print(X[0], X[1], X[2])
	print(W[0], W[1], W[2])
	l=0
	for i in xrange(len(X)-1):
		d = X[i+1]-X[i]
		n = np.linalg.norm(d)
		l+=n;
	print(n, l)
