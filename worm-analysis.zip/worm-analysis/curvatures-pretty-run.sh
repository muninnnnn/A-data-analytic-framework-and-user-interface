#!/bin/bash

set -e
set -u

base="/home/csunix/scstr/Software/WORMS/data-analysis/matlab/eigenworm/data/nobackup/scsrih/output-curve/223137/"
out="curvatures-pretty-out"
mkdir -p ${out}

python -O curvatures-pretty.py \
       pvd_dir:${base}/N2_0_75pc_20160427_trial05 \
       start_frame:600 \
       end_frame:750 \
       output_dir:${out}

python -O curvatures-pretty.py \
       pvd_dir:${base}/N2_1_75pc_20160428_trial01 \
       start_frame:100 \
       end_frame:250 \
       output_dir:${out}

python -O curvatures-pretty.py \
       pvd_dir:${base}/N2_1_75pc_20160428_trial01 \
       start_frame:870 \
       end_frame:1020 \
       output_dir:${out}

python -O curvatures-pretty.py \
       pvd_dir:${base}/N2_2_00pc_20160615_trial03 \
       start_frame:384 \
       end_frame:534 \
       output_dir:${out}

python -O curvatures-pretty.py \
       pvd_dir:${base}/N2_4_00pc_20160714_trial02 \
       start_frame:300 \
       end_frame:600 \
       output_dir:${out}
