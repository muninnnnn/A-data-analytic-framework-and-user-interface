from eigenworm import readEwMs
from worm_parse import ptsFromVtu, worm
from xwToMs import xwToMs, cXwToMs
from matplotlib import pyplot as plt
from matplotlib import gridspec
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import sys
import time

def rigid_transform_3D(A, B):
    start_time = time.time()
    assert len(A) == len(B)

    N = A.shape[0]; # total points

    centroid_A = np.mean(A, axis=0)
    centroid_B = np.mean(B, axis=0)

    # centre the points
    AA = A - np.tile(centroid_A, (N, 1))
    BB = B - np.tile(centroid_B, (N, 1))

    # dot is matrix multiplication for array
    H = np.transpose(AA) * BB

    U, S, Vt = np.linalg.svd(H)

    R = Vt.T * U.T

    # special reflection case
    if np.linalg.det(R) < 0:
       print "Reflection detected"
       Vt[2,:] *= -1
       R = Vt.T * U.T

    t = -R*centroid_A.T + centroid_B.T
    end_time = time.time()
    print "Enlapsed time: ", end_time - start_time
    return R, t


if __name__=="__main__":
    #ew = readEwMs(sys.argv[1])

    #coeffs = ew.pca_coeffs(pcaworms)
    if len(sys.argv) < 2:
        print "vtu file not specified"
        sys.exit()

    myworm = worm(sys.argv[1])

    X = myworm.pts()
    W = myworm.W()

    m1, m2, theta = xwToMs(X, W)

    Ms = np.concatenate((m1, m2))

    ew = readEwMs("../3d_data/pca/1_00pc_HT.pca")

    c0 = np.dot(ew[0], Ms)
    c1 = np.dot(ew[1], Ms)
    c2 = np.dot(ew[2], Ms)
    c3 = np.dot(ew[3], Ms)


    print c0, c1, c2, c3

    Xr = myworm.pca_reconstruction(ew)

    x=[]
    y=[]
    z=[]
    for i in range(len(X)):
        x.append(X[i][0])
        y.append(X[i][1])
        z.append(X[i][2])

    pts = np.matrix(X)
    reconstruction = np.matrix(Xr)
    r, t = rigid_transform_3D(reconstruction, pts)

    optimal = (r*reconstruction.T) + np.tile(t, (1, len(Xr)))
    optimal = optimal.T

    print "R: ", r
    print t

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    xPts=[]
    yPts=[]
    zPts=[]
    for i in range(len(Xr)):
        xPts.append(Xr[i][0])
        yPts.append(Xr[i][1])
        zPts.append(Xr[i][2])


    ax.plot(xPts, yPts, zPts, color='b')

    ax.plot(x,y,z, color='g')

    optimalx=[]
    optimaly=[]
    optimalz=[]
    print t.item(0)
    for i in range(len(optimal)):
        optimalx.append(optimal.item((i,0)))
        optimaly.append(optimal.item((i,1)))
        optimalz.append(optimal.item((i,2)))

    ax.plot(optimalx, optimaly, optimalz, color='r')
    plt.show()
