import numpy as np
import glob, os
from matplotlib import pyplot as plt

basedir='/home/csunix/scstr/biosys2/3D_Data/analysis/223137/'

def parseFn( fn ):
    data = fn.split('_')
    strain = data[0]
    media = float(data[1]+data[2][:2])/100.0
    date = data[3]
    trial = data[4]

    return strain, media, date, trial

def readTrajectoryFile( fn ):
    data = np.loadtxt(fn, delimiter=',')

    frame_number = data.T[0]
    time = data.T[1]
    x = data.T[2]
    y = data.T[3]
    z = data.T[4]
    speed = data.T[5]
    distance = data.T[6]
    cumulative_distance = data.T[7]
    turn_rate = data.T[8]
    turn_radii = data.T[9]
    return frame_number,time,x,y,z,speed,distance,cumulative_distance,turn_rate,turn_radii

def myHist( list, nBins=50 ):
    a = min(list)
    b = max(list)
    N = float(len(list))
    # N = 1

    bins = np.zeros( nBins )
    labels = np.linspace( a, b, nBins )
    for l in list:
        idx = int( (nBins-1) * ( l - a ) / ( b - a ) )
        bins[idx] += 1.0/N

    return labels, bins

def myHistLog( list, nBins=50 ):
    a = min(list)
    b = max(list)
    N = float(len(list))
    # N = 1

    bins = np.zeros( nBins )
    labels = np.logspace( np.log10(a), np.log10(b), nBins, endpoint=True )
    for l in list:
        try:
            idx = next(idx for idx, value in enumerate(labels) if value >= l)
        except:
            idx = -1
            # idx = int( (nBins-1) * ( l - a ) / ( b - a ) )
        bins[idx] += 1.0/N

    return labels, bins

os.chdir( basedir )
bigDict = {}
for file in sorted( glob.glob("*traj_output.csv") ):
    strain, media, date, trial = parseFn( file )
    if strain != "N2": continue
    if media < 1.01: continue

    print (strain, media, date, trial)
    data = readTrajectoryFile( file )

    for j, key in enumerate(['frame_number','time','x','y','z','speed','distance','cumulative_distance','turn_rate','turn_radii']):
        if not media in bigDict:
            bigDict[media] = {}

        if key in bigDict[media]:
            bigDict[media][key] += [ d  for d in data[j] if not np.isnan(d) ]
        else:
            bigDict[media][key] = [ d  for d in data[j] if not np.isnan(d) ]

for fignum, key in enumerate(['speed','distance','cumulative_distance','turn_rate','turn_radii']):
    plt.figure(fignum)
    plt.title(key)
    plt.figure(fignum+20)
    plt.title(key + ' mean')

    for media in sorted(bigDict):
        data = bigDict[media][key]
        labels, bins = myHistLog( data, 25 )
        plt.figure(fignum)
        plt.semilogx( labels, bins, color=(media/4.0,1.0-media/4.0,1.0), label='{}'.format(media))

        plt.figure(fignum+20)
        plt.plot( media, np.mean(data), 'o', color=(media/4.0,1.0-media/4.0,1.0), label='{}'.format(media))

    plt.figure(fignum)
    plt.savefig('totaliser_plots/' + key+'_dist.png')
    print 'saved','totaliser_plots/', key+'_dist.png'

    plt.figure(fignum+20)
    plt.savefig('totaliser_plots/' + key+'_mean.png')
    print 'saved', 'totaliser_plots/', key+'_mean.png'

# plt.show()
