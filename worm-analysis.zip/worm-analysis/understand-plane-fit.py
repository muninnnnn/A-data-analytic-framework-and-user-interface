import numpy as np
import glob, os
from matplotlib import pyplot as plt
from scipy import stats

basedir='/home/csunix/scstr/biosys2/3D_Data/analysis/223137/'

def parseFn( fn ):
    data = fn.split('_')
    strain = data[0]
    media = float(data[1]+data[2][:2])/100.0
    date = data[3]
    trial = data[4]

    return strain, media, date, trial


def readPostureFile( fn ):
    file = open(fn,'r')
    frames, times, planeFits, lineFits, totalCurvatures = [], [], [], [], []

    for line in file.readlines():
        if '#' == line[0]:
            continue
        else:
            data = line.split(',')
            myFrame = int(data[0])
            frames.append(myFrame)
            myTime = float(data[1])
            times.append(myTime)
            myPlaneFit = float(data[2])
            planeFits.append(myPlaneFit)
            myLineFit = float(data[3])
            lineFits.append(myLineFit)
            myTotalCurvature = float(data[4])
            totalCurvatures.append(myTotalCurvature)

    file.close()

    return frames, times, planeFits, lineFits, totalCurvatures

def myHist( list, nBins=50 ):
    a = min(list)
    b = max(list)
    N = float(len(list))
    # N = 1

    bins = np.zeros( nBins )
    labels = np.linspace( a, b, nBins )
    for l in list:
        idx = int( (nBins-1) * ( l - a ) / ( b - a ) )
        bins[idx] += 1.0/N

    return labels, bins

def my2dHist( list1, list2, nBins1 = 50, nBins2 = 50 ):
    a1 = min(list1)
    b1 = max(list1)
    a2 = min(list2)
    b2 = max(list2)

    bins = np.zeros( [nBins1, nBins2] )
    labels1 = np.linspace( a1, b1, nBins1 )
    labels2 = np.linspace( a2, b2, nBins2 )
    for l1,l2 in zip(list1, list2 ):
        idx1 = int( (nBins1-1) * ( l1 - a1 ) / ( b1 - a1 ) )
        idx2 = int( (nBins2-1) * ( l2 - a2 ) / ( b2 - a2 ) )
        bins[idx1,idx2] += 1

    return labels1, labels2, bins

def myHistLog( list, nBins=50 ):
    a = min(list)
    b = max(list)
    N = float(len(list))
    # N = 1

    bins = np.zeros( nBins )
    labels = np.logspace( np.log10(a), np.log10(b), nBins, endpoint=True )
    for l in list:
        try:
            idx = next(idx for idx, value in enumerate(labels) if value >= l)
        except:
            idx = -1
            # idx = int( (nBins-1) * ( l - a ) / ( b - a ) )
        bins[idx] += 1.0/N

    return labels, bins

allPlaneFitDict = {}
allPlaneFits = []
allLineFitDict = {}
allLineFits = []
allCurvatureDict = {}
allCurvature = []

os.chdir( basedir )
for file in sorted( glob.glob("*posture_output.csv") ):
    strain, media, date, trial = parseFn( file )
    if strain != "N2": continue

    print (strain, media, date, trial)
    frames, times, planeFits, lineFits, totalCurvatures = readPostureFile( file )

    if media in allPlaneFitDict.keys():
        allPlaneFitDict[ media ] += planeFits
    else:
        allPlaneFitDict[ media ] = planeFits
    allPlaneFits += planeFits

    if media in allLineFitDict.keys():
        allLineFitDict[ media ] += lineFits
    else:
        allLineFitDict[ media ] = lineFits
    allLineFits += lineFits

    if media in allCurvatureDict.keys():
        allCurvatureDict[ media ] += totalCurvatures
    else:
        allCurvatureDict[ media ] = totalCurvatures
    allCurvature += totalCurvatures

for fignum, dict in enumerate([ allPlaneFitDict, allLineFitDict, allCurvatureDict ]):

    allFits = []
    for media in sorted(dict):
        fits = dict[media]
        allFits = fits
        labels, bins = myHistLog( allFits, 25 )

        plt.figure(fignum)
        plt.semilogx( labels, bins, color=(media/4.0,1.0-media/4.0,1.0), label='{}'.format(media))

        plt.figure(fignum+10)
        mean = np.mean( fits )
        plt.plot( media, mean, 'o', color=(media/4.0,1.0-media/4.0,1.0), label='{}'.format(media))

    # plt.figure(fignum)
    # ax = plt.gca()
    # handles, labels = ax.get_legend_handles_labels()
    # # reverse the order
    # ax.legend(handles[::-1], labels[::-1])

    # # or sort them by labels
    # import operator
    # hl = sorted(zip(handles, labels),
    #             key=lambda x : x[1] )
    # handles2, labels2 = zip(*hl)

    # ax.legend(handles2, labels2)

    plt.figure(fignum)
    key = ['plane_fit','line_fit','total_curvature'][fignum]
    plt.title(key)
    plt.savefig('totaliser_plots/'+key+'_dist.png')
    plt.figure(fignum+10)
    plt.title(key)
    plt.savefig('totaliser_plots/'+key+'_mean.png')

plt.figure(20)
labels1, labels2, bins = my2dHist( allPlaneFits, allLineFits, 100, 100 )
plt.imshow( bins )

plt.savefig('totaliser_plots/plane_and_line_codist.png')

plt.show()
# plt.figure(2)
# plt.hist( allLineFits, 100 )

# plt.figure(3)
# plt.hist( allCurvature, 100 )


# plt.show()
