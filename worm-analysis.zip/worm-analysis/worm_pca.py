from __future__ import print_function
from error import printn
from numpy import array
from error import printn
from numpy import iscomplexobj

def printa(c, cplx):
		space=""
		for i in c:
			printn(space)
			printn(str(i.real))
			space=" "

		if cplx:
			for i in c:
				printn(space)
				printn(str(i.imag))
		print("")

def dump_pca(worms, cplx=False):

	if iscomplexobj(worms):
		cplx = True
	if cplx:
		printn("# COMPLEX ")
	print("# PCA", len(worms))

	for c in worms:

		space=""
		for i in c:
			printn(space)
			printn(str(i.real))
			space=" "

		if cplx:
			for i in c:
				printn(space)
				printn(str(i.imag))
		print("")


# make_pca?!
# this does not just print
def print_pca(Ms, DIMENSION=10, cplx=False, cc=False):
	if cc:
		cplx = True
		from cpca import PCA
		myPCA = PCA

	else:
		from sklearn.decomposition import PCA
		myPCA = PCA
	if cplx:

		printn("# COMPLEX ")

	print("# PCA", DIMENSION, "from", len(Ms))

	pca = myPCA(n_components=DIMENSION)

	Ms = array(Ms)
	#pca.fit(Ms) <= documented interface
	# HACK HACK, works wirh sklearn 18
	pca._fit_full(Ms, DIMENSION)
	printn("# mean ")
	printa(pca.mean_, cplx) 
	#	priNt(pca.components_)

# call dump_pca!!!
	for c in pca.components_:
	#		print("# norm", norm(c))

		printa(c, cplx) 

