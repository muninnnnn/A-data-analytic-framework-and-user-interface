#!/usr/bin/env python

from __future__ import print_function

from estimateK import estimateK
from worm_parse import pvdparse, ptsFromVtu
from sys import argv
import os
import numpy as np
import numpy.linalg as la
from numpy.linalg import norm
from math import sqrt
from sklearn.decomposition import PCA
from xwToMs import xwToMs, xwToM
from msToXw import msToXw
from pvdSD import self_distance
from error import eprint

from scipy.sparse.linalg import svds


class myPCA:
	def __init__(self,inputData):
		data = inputData.copy()
		#m = no of points
		#n = no of features per point
		self.m = data.shape[0]
		self.n = data.shape[1]
		#mean center the data
		data -= np.mean(data,axis=0)
		
		# calculate the covariance matrix
		c = np.cov(data, rowvar=0)
		
		# get the eigenvalues/eigenvectors of c
		# eval, evec = la.eig(c)
		eval, S, evec = svds(c)

		print(eval)
		eval=np.abs(eval)
		print(eval)


		perm = eval.argsort();
		print(perm)
		print(perm[::-1])
		evec = evec.transpose()[perm[::-1] ].transpose()

		# u = eigen vectors (transposed)
		self.u = evec.transpose()
	
	def getU(self):
	  return self.u
	
	def getPCA(self,vector,components):
	    if components > self.n:
	        raise Exception("components must be > 0 and <= n")
	    return np.dot(self.u[0:components,:],vector)


import sys

DIMENSION=3
SD_THRESH=0


def printn(*args, **kwargs):
	sys.stdout.write(*args, **kwargs)

def cpcaproj(t, p):
	dim=len(t)
	ret=np.zeros_like(t)

	print("cp")
	for c in p:
		ret += np.dot(t,np.conj(c)) * c
	return ret

if __name__=="__main__":
	pca = PCA(n_components=DIMENSION)
	e=.1j

	stuff= np.array([ [1.,  1.,  0., 0.],
			            [0.,  1.j, 0., 0.],
			            [0.,  0.,  1., 0.],
			            [1.j, 0.,  2., 0.],
			            [1.,  0.,  1., 0.] ])

	n_samples = stuff.shape[0]

#	stuff= np.array([
#		               [1.,  0.,  0., 0., 0.],
#			            [0.,  1.,  0., 0., 0.],
#			            [0.,  0.,  1., 0., 0.],
#			            [0.,  0.,  0., 1., 0.],
#			            [0.,  0.,  0., 0., 1.],
#							])

	if(0):
		a = myPCA(stuff)
		U = a.getU()
	#	U[0]=U[0]/norm(U[0])
		print (U[:,0:4])

		print ("---")
	U, S, V = pca._fit_full(stuff, DIMENSION)
	# pca.fit(stuff)

	dim=len(pca.components_)

	print("comp")
	for i in pca.components_:
		print(i)
	print()

	print(dim, " dimensional subspace")
	print( norm(pca.components_,axis=0))
	print( norm(pca.components_,axis=1))

	t=np.array([1+1.j])

	print(t)
	print(np.dot(t,t))
	print(np.dot(t,np.conj(t)))

	print("PCA basis")
	for c in pca.components_:
		print(c)

	print("pcamatrix")
	for c in pca.components_:
		for s in pca.components_:
			print(np.dot(np.conj(c), s),)

	print("matrix")
	for c in pca.components_:
		for s in stuff:
			print(np.dot(np.conj(c), s),)
		print()
#		space=""
#		for i in c:
#			printn(space)
#			printn(str(i))
#			space=" "
#		print("")

	
	thing=np.array([1.j,1.j,0.,0.])
	thing2=cpcaproj(thing, pca.components_)
	print("delta")
	print(norm(thing2-thing))

	thing=np.array([0.j,0.j,0.,1.])
	thing2=cpcaproj(thing, pca.components_)
	print("delta")
	print(norm(thing2-thing))


	explained_variance_ = (S ** 2) / n_samples
	total_var = explained_variance_.sum()
	explained_variance_ratio_ = explained_variance_ / total_var




	r = pca.explained_variance_ratio_
	print(r)

	for i in range(len(r)):
		print(sum(r[0:1+i]))
