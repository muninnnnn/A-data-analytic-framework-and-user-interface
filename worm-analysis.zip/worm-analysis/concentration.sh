#!/bin/sh

id=$(( $1 + 1 ))
sed "${id}q;d" ${RUN_INFO} | awk -F, '{print $9}'
