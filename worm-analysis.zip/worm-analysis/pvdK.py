#!/usr/bin/env python

from estimateK import estimateK
from worm_parse import pvdparse, ptsFromVtu
from sys import argv
import os

pvdfn=argv[1]

vtuindex=pvdparse(pvdfn)
dir=os.path.dirname(pvdfn)

x=iter(vtuindex)
t=x.next()
f=t.get('file')

w0=ptsFromVtu(dir+'/'+f)[0]
i=j=0
meanK=0.
meanTK=0.

print "#number k"

while(True):
	w1=w0
	try:
		t=x.next()
	except StopIteration:
		break

	f=t.get('file')
	w0=ptsFromVtu(dir+'/'+f)[0]

	est=estimateK(w0, w1)

#	print 'EST', est
	c=est[-1][0]
	eo=est[-1][1]

	if( c > .9  ):
		j+=1
		e=est[0]
		tk=est[0][1]
		print i, 'e', e, est[1], est[-1][0], est[-1][1]
		meanK+=e[0]
		meanTK+=abs(tk)
	i+=1;

print meanK/j, meanTK/j
