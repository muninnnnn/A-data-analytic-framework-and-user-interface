#!/usr/bin/env python
from sys import argv

from worm_parse import ptsFromVtu
from xwToMs import xwToMs, convert_3d, an_orthonormal, nextFrame, \
	xwToM

from colormaps import phasecolor
from msToXw import msToXw

import numpy as np
from numpy.linalg import norm

def plotwithframes(X, W, ax0):

	for j in range(len(X)-1):
		ax0.plot( *convert_3d( X[j], X[j+1]),
						color = 'green' , linewidth=3)

	tau = X[1]-X[0]
	tau = tau / norm( tau )

	ax0.set_xticklabels([])
	ax0.set_yticklabels([])
	ax0.set_zticklabels([])

	M1 = an_orthonormal(tau)
	M1 = M1 - np.dot(tau, M1) * tau
	M1 = M1 / norm(M1)
	M2 = np.cross(tau, M1)
	for i in range(1, len(X)-2):
		tau = X[i+1] - X[i]
		M1, M2 = nextFrame(M1, M2, tau)

		h=.01

		if(0 and not i % 5):
			ax0.plot( *convert_3d(X[i], X[i] + h*np.dot(M1, W[i])*M1),
							color = 'blue' , linewidth=3)
			ax0.plot( *convert_3d(X[i], X[i] + h*np.dot(M2, W[i])*M2),
							color = 'red' , linewidth=3)
			ax0.plot( *convert_3d(X[i], X[i] + h*W[i]),
							color = 'grey' , linewidth=3)

	#fig.savefig("m1m2.pdf")

	
###  doesntwork_vim:ts=8:sw=2:et:?!?!

if __name__=="__main__":
	vtufn=argv[1]

	from worm_parse import worm
	myworm=worm(vtufn)

	X = myworm.pts()
	W = myworm.W()

	M, nu = xwToM(X, W, cplx=True)

	from matplotlib import pyplot as plt
	from matplotlib import gridspec
	from mpl_toolkits.mplot3d import Axes3D

	fig = plt.figure(facecolor='white')
	gs = gridspec.GridSpec(3, 4)
	ax0 = fig.add_subplot(gs[0:3,0:3], projection='3d')

	m1 = M.real
	m2 = M.imag
#	X, W = msToXw(m1,m2)
	plotwithframes(X, W, ax0)

	P = fig.add_subplot(gs[2,0])

	from eigenworm import readEwMs
	pcaworms=readEwMs("4.00pc_HT_C.pca")
	numpca = len(pcaworms)

	Xr = myworm.pca_reconstruct(pcaworms)
	plotwithframes(X, W, ax0)

	P.set_ylim([0,60])
	color = [phasecolor(0)]
	coeffs = myworm.pca_coeffs(pcaworms)
	prev = coeffs[0]
	for i in coeffs[1:]:
		color.append( phasecolor(i / prev ) )
		prev=i

	P.bar( range(numpca), [norm(i) for i in  coeffs], color=color)

	plt.show()
	

# plot with frames

