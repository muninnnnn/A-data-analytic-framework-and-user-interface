#!/usr/bin/env python
import textwrap
import numpy as np
from numpy.linalg import norm
from sys import argv
import os
from string import Template

header = Template('''<?xml version="1.0"?>
<VTKFile type="UnstructuredGrid" version="0.1" byte_order="LittleEndian">
  <UnstructuredGrid>
    <Piece NumberOfPoints="$number" NumberOfCells="$cnumber">
	 ''')

Wstuff='''
      <PointData Scalars="W">
        <DataArray type="Float32" Name="W" NumberOfComponents="3">'''

endDataArray = '</DataArray>'
endPointData = '</PointData>'

section0	= '''
        <DataArray type="Float32" Name="u" NumberOfComponents="1">'''
section1 = '''        </DataArray>
       </PointData>
       <CellData Scalars="P">
        <DataArray type="Float32" Name="P" NumberOfComponents="1">'''

# endDataArray = '</DataArray>'
# endCellData = '</CellData>'

section2 = '''
       <Points>
        <DataArray type="Float32" NumberOfComponents="3" format="ascii">'''
section3 = '''        </DataArray>
       </Points>
       <Cells>
        <DataArray type="Int32" Name="connectivity" format="ascii">'''
section4 = '''        </DataArray>
        <DataArray type="Int32" Name="offsets" format="ascii">'''
section5 = '''        </DataArray>
        <DataArray type="Int32" Name="types" format="ascii">'''
section6 = '''        </DataArray>
        </Cells>
    </Piece>
  </UnstructuredGrid>
</VTKFile>
'''


from util import XtoW
#def XtoW(X):
#    wl = len(X)
#    q = np.array( [0] + [ norm( X[i+1] - X[i] ) for i in range(wl-1) ] + [0] )
#    M = np.array( [ .5*(q[i] + q[i+1]) for i in range(wl) ] )
#    SX = np.array( [ (X[i] - X[i-1])/q[i] - (X[i+1] - X[i]) / q[i+1] for i in range(1, wl-1) ] )
#
#    W = np.zeros((wl,3))
#    for i in range(1, wl-1):
#        W[i] = - SX[i-1]/M[i]
#
#    return W

def syntheticVTU():
	fn = open("syntheticWorms/worm_planarSin.txt", "r")
	pts = []
	for line in fn:
		for x in line.split():
			pts.append(float(x))
	incomplete()
	print_vtu(X1)
	X1 = [np.array(pts[3*j:3*(j+1)]) for j in range(len(pts)/3)]

from sys import stdout

def print_vtu(X1, S=stdout):

    W = XtoW(X1)
    L=len(X1)

    S.write  (header.substitute(number=L, cnumber=L-1 ))
    s = "\t"
    S.write(Wstuff)
    for i in W:
        for k in i:
            s += repr(k) + " "

    S.write(s)
    S.write("\n")
    S.write(endDataArray)
    S.write(endPointData)

#    S.write(section0)
#    S.write(section1)
#    S.write(endDataArray)
    S.write(section2)
    s = "\n"
    for i in X1:
        s += "\t" + repr(i[0]) + " "
        s += repr(i[1]) + " "
        s += repr(i[2]) + " "
    S.write(s)
    S.write("\n")
    S.write(section3)


    connectivity= "\t"
    for i in range(1, len(X1),1):
        connectivity += " "+repr(i-1)+" "+repr(i)

    S.write( connectivity)

    S.write  (section4)

    offset = ""
    celltype = ""
    for i in range(1, len(X1), 1):
        offset += repr(i*2) + " "
        celltype += "3 "

    S.write(offset)
    S.write('\n')
    S.write(section5)
    S.write(celltype)
    S.write(section6)


if __name__=="__main__":
	curvscale=64
	from eigenworm import readEwMs
	from msToXw import msToXw, mToXw
	fn = argv[1]
	mean, w = readEwMs(fn)
	w*=curvscale

	out = fn+"_"+str(curvscale)+".mean.vtu"
	print("outfile " + out)
	f=open(out, "w")

	X, W = mToXw(mean)
	print_vtu(X,f)

	for m,i in enumerate(w):
		X, W = mToXw(i)
		out = fn+"_"+str(curvscale)+"."+str(m)+".vtu"
		print("outfile " + out)
		f=open(out, "w")

		print_vtu(X,f)
	
