#!/bin/bash

# ---------- set arc parameters for pbs ----------

# Set current working directory
#$ -cwd
#Use current environment variables/ modules
#$ -V
#Request one hour of runtime
#$ -l h_rt=1:00:00
#Email at the beginning and end of the job
#$ -m be
## Tell SGE that this is an array job, with "tasks" numbered from 1 to 150
##$ -t 1-140

set -e
set -u

exit 1

strain="N2"
date="20160426"
media="1_00pc"
trial="04"

curve_pvd_dir="/nobackup/${USER}/output-curve/${strain}/${date}_${media}_${trial}"
carve_pvd_dir="/nobackup/${USER}/output-carve/${strain}/${date}_${media}_${trial}"

TOKEN="</VTKFile>"
addendtags(){
   find $1 -name '*.pvd' |
   while read p; do
      tail -n 1 "$p" | grep -q "$TOKEN" || \
         echo "$TOKEN" >> $p
   done
}

addendtags "$carve_pvd_dir"
addendtags "$curve_pvd_dir"


video_cam1="/nobackup/${USER}/video/${date}_trial${trial}_cam1.avi"
video_cam2="/nobackup/${USER}/video/${date}_trial${trial}_cam2.avi"
video_cam3="/nobackup/${USER}/video/${date}_trial${trial}_cam3.avi"

output_dir="/nobackup/${USER}/valid_vids/${strain}/${media}_${date}_${trial}"
mkdir -p ${output_dir}

# make temp frame dir
frame_dir=$(mktemp -d tmp.XXXXXX)
# frame_dir="/nobackup/${USER}/worms-curve-analysis/tmp.UTS75k"

# convert video to image sequence
ffmpeg -i ${video_cam1} ${frame_dir}/Cam1_%06d.png
ffmpeg -i ${video_cam2} ${frame_dir}/Cam2_%06d.png
ffmpeg -i ${video_cam3} ${frame_dir}/Cam3_%06d.png

# validation plot (to png)
python -O plot-curve-verification.py \
    pvd_dir:${curve_pvd_dir} frame_dir:${frame_dir} output_dir:${output_dir}

# carve validation plot (to png)
python -O plot-carve-verification.py \
    pvd_dir:${carve_pvd_dir} frame_dir:${frame_dir} output_dir:${output_dir}

# coloured plot (to png)
python -O curvature-plot.py \
    pvd_dir:${curve_pvd_dir} output_dir:${output_dir}

# # cylinder plot (to vtk)
python -O plot-surface.py  \
    pvd_dir:${curve_pvd_dir} output_dir:${output_dir}

# compare carve and curve
python -O carve-vs-curve-verification.py \
       curve_pvd_dir:${curve_pvd_dir} carve_pvd_dir:${carve_pvd_dir} output_dir:${output_dir}

# make movie
# ffmpeg -r 25 -f image2 -s 800x600 -i ${output_dir}/frame_%06d.png -vcodec libx264 -crf 25 -pix_fmt yuv420p /nobackup/${USER}/validation_vid/validation_${media}_${strain}_trial${trial}_${date}.mp4
# ffmpeg -r 25 -f image2 -s 800x600 -i ${output_dir}/frame_%06d.png -vcodec libx264 -crf 25 -pix_fmt yuv420p /nobackup/${USER}/validation_vid/coloured_${media}_${strain}_trial${trial}_${date}.mp4

tar -cf /nobackup/${USER}/valid_vids/cylinder_${media}_${strain}_${date}_trial${trial}.tar ${output_dir}/cylinder*.vtk
ffmpeg -i ${output_dir}/frame_%06d.png -c:v huffyuv /nobackup/${USER}/valid_vids/validation_${media}_${strain}_${date}_trial${trial}.avi
ffmpeg -i ${output_dir}/all_%06d.png -c:v huffyuv /nobackup/${USER}/valid_vids/coloured_${media}_${strain}_${date}_trial${trial}.avi

# rmdir -rf ${frame_dir}
rm -rf ${frame_dir}
