#!/usr/bin/env python

from estimateK import estimateK
from sys import argv
import os
import numpy as np
from math import sqrt

def total_displacement(x, y):
	assert(len(x)==len(y))
	t=0
	for i in range(len(x)):
		t+=np.linalg.norm(x[i]-y[i])
		#s =(x[i][0]-y[i][0])**2
		#s+=(x[i][1]-y[i][1])**2
		#s+=(x[i][2]-y[i][2])**2
		#t+=sqrt(s)
	return t

if __name__=="__main__":
	pvdfn=argv[1]

	vtuindex=pvdparse(pvdfn)
	dir=os.path.dirname(pvdfn)

	x=iter(vtuindex)
	t=x.next()
	f=t.get('file')

	from worm_parse import pvdparse, ptsFromVtu
	w0=ptsFromVtu(dir+'/'+f)[0]
	i=0
	TV=0.


	while(True):
		w1=w0
		try:
			t=x.next()
		except StopIteration:
			break

		f=t.get('file')
		w0=ptsFromVtu(dir+'/'+f)[0]

		T = total_displacement(w0, w1)

		print(i, T)
		i+=1


