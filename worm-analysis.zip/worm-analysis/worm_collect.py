#!/usr/bin/env python
from worm_parse import pvdparse, ptsFromVtu
import os
from pvdSD import self_distance
from xwToMs import xwToMs, xwToM
from msToXw import msToXw

from error import eprint

from worm_parse import worm

#ouch. parameter for append?
SD_THRESH = 0

def dummywl(x):
	# eprint("missing tags\n")
	return True

class worm_collect:
	#(Ms, pvdfn, i, end, whitelist=dummywl, complex=False):
	def __init__(self, pvdfn, i, end, whitelist=dummywl, complex=False, all_frames=False):
		self.worms=[]
		self._select_all = all_frames

		eprint("wormcollect "+ pvdfn + "\n")
		try:
			vtuindex = pvdparse(pvdfn)
		except IOError:
			eprint("cannot collect worm data from " + pvdfn)
			raise
		try:
			self._timestep = float(vtuindex[1].get('timestep'))
		except:
			self._timestep = 0

		self._dir = os.path.dirname(pvdfn)
		# eprint("index", type(vtuindex))

		self._x = iter(vtuindex)
		for ii in range(i):
			eprint("skip")
			self._x.next()

		self._w = whitelist # whitelist is no longer a whitelist. it's tags
		self._blacklisted = 0
		self._i = i
		self._end = end

	def timestep(self):
		return self._timestep

	def __iter__(self):
		eprint("iter\n")
		return self

# python2??
	def next(self):
		return self.__next__()

	def __next__(self):
			if(self._i==self._end):
				raise StopIteration
			try:
				t = next(self._x)
			except StopIteration:
				raise

			while not ( self._select_all or  self._w(self._i)):
				t = next(self._x)
				self._blacklisted += 1
				self._i += 1
				if(self._i==self._end):
					raise StopIteration

				# eprint("skipping not tagged", w)
			else:
				f = t.get('file')
				# flip = t.get('flip')
				#if flip:
					#eprint("flip")
				fn = self._dir+'/'+f


				tags = self._w(self._i)
				ww = worm(fn, tags)
				ww.set_framenumber(self._i)
				self._i += 1

				return ww

#				X, W, _ = myworm.XWU()
#
#				s = self_distance(X)
#				if s<SD_THRESH:
#					eprint("too small self distance in frame " +str(i) +":", s)
#				else:
#
#					if not i % 200:
#						eprint(".")
#
#					if(not complex):
#						M, t = xwToM(X,W)
#						Ms.append(M)
#					else:
#						m1, m2, t = xwToMs(X,W)
#						Ms.append(m1 + 1.j * m2)
#

		#eprint("found", i)
		#eprint("blacklisted", blacklisted)

# obsolete
def append_pvdworm(Ms, pvdfn, i, end, whitelist=dummywl, complex=False):
	eprint("obsolete append_pvdworm"+ pvdfn + "\n")
	vtuindex = pvdparse(pvdfn)
	dir = os.path.dirname(pvdfn)
	x = iter(vtuindex)
	for ii in range(i):
		t=x.next()
	blacklisted = 0
	while(i<end):
		try:
			t = next(x)
		except StopIteration:
			break


		w = whitelist(i)
		# print(i, w)
		if not w:
			blacklisted += 1
			# eprint("skipping not tagged", w)
		else:
			f = t.get('file')
			flip = t.get('flip')
			#if flip:
				#eprint("flip")
			fn = dir+'/'+f

			myworm = worm(fn, w)

			X, W, _ = myworm.XWU()

			s = self_distance(X)
			if s<SD_THRESH:
				eprint("too small self distance in frame " +str(i) +":", s)
			else:

				if not i % 200:
					eprint(".")

				if(not complex):
					M, t = xwToM(X,W)
					Ms.append(M)
				else:
					m1, m2, t = xwToMs(X,W)
					Ms.append(m1 + 1.j * m2)

		i+=1

	eprint("found", i)
	eprint("blacklisted", blacklisted)

#obsolete.
def append_pvdworm_complex(Ms, pvdfn, i, end):
	vtuindex = pvdparse(pvdfn)
	dir = os.path.dirname(pvdfn)
	x = iter(vtuindex)
	for ii in range(i):
		t=x.next()
	while(i<end):
		try:
			t = x.next()
		except StopIteration:
			break

		f=t.get('file')
		X,W,ign=ptsFromVtu(dir+'/'+f)

		s=self_distance(X)
		if s<SD_THRESH:
			eprint("too small self distance in frame " +str(i) +":", s)
		else:

			m1, m2, t = xwToMs(X,W)
			Ms.append(m1 + 1.j * m2)

		i+=1

class worms_collection:
	def __init__(self, pvdfn, i, end, whitelist=dummywl):
		eprint("collection opening" +pvdfn +"\n")
		vtuindex = pvdparse(pvdfn)
		try:
			self._timestep = float(vtuindex[1].get('timestep'))
		except:
			self._timestep = 0.
		dir = os.path.dirname(pvdfn)

		self.x = iter(vtuindex)
		for ii in range(i):
			try:
				eprint("skip\n")
				t = self._x.next()
			except StopIteration:
				break

		self._i = i;
		self._whitelist = whitelist

	def __iter__(self):
		eprint("__iter__\n")
		return iter(self)

	def __next__(self):
			t=self._x.next()

			while not self._whitelist(self._i):
				eprint("skipping not tagged", w)
				t=self._x.next()
				self._i+=1

			self._i+=1

			f = t.get('file')
			X, W, _ = ptsFromVtu(dir+'/'+f)


			s = self_distance(X)
			if s<SD_THRESH:
				eprint("too small self distance in frame " +str(i) +":", s)
			else:
				M, t = xwToM(X,W)

				if not i % 200:
					eprint(".")
				Ms.append(M)

			i+=1

			eprint("found", i)

if __name__=="__main__":
	from sys import argv

#	wormpvd = videodir+"/"+T.videofilename()+"/skeletons_worm.pvd"
#	eprint("reading in " + wormpvd)

	WL = worm_collect(argv[1], 0, 999999, dummywl, all_frames=True)

	a=0
	for i in WL:
		a+=1
	print("debugging", a)
