#!/usr/bin/env python

from sys import argv
import numpy as np
from math import atan2, sqrt

def phase(x):
	ma = atan2(x.imag, x.real)
	return ma

def mag(x):
	ma = x * x.conj()
	assert(ma.imag < 1e-10)

	ret = sqrt(ma.real)
#	print "MA", x, ret
	return ret

if __name__=="__main__":

	f = open(argv[1])
	data=[]

	for line in f:
		if line[0]=='#':
			continue
		s = line.split(" ")
		for i in range(4,len(s)):
			try:
				s[i] = float(s[i])
			except:
				pass
		data.append(s)

	
	from matplotlib import pyplot as plt


	cplx=[]
	Poff=5
	pcadim=10
	for i in data:
		l=pcadim
		c = np.zeros(l, dtype="complex")
		for j in range(l):
			c[j] = i[Poff+2*j] + 1.j * i[Poff+2*j+1]
		cplx.append(c)

	plans = []

	# each row
# 	for ccoefs in cplx:
# 		plan = 0;
# 		for k in ccoefs:
# 			if k.real < 0:
# 				k *= -1
# 			print "adding", k, mag(k)
# 			plan += k
# 		print "now have", plan
# 
# 		print "Cc", ccoefs[0]
# 
# 		print len(ccoefs)
# 		owndot=0
# 		for i in ccoefs:
# 			owndot += i * i.conj()
# 		print mag(plan), "owndot", owndot, "I^2", np.dot(ccoefs, ccoefs.conj())
# 		print "COMP", mag(plan), sqrt(np.dot(ccoefs, ccoefs.conj()))
# 		assert mag(plan) < sqrt(np.dot(ccoefs, ccoefs.conj()))
# 		plans.append(mag(plan) / sqrt(np.dot(ccoefs, ccoefs.conj())))


	z = zip(*cplx)
	plt.plot(plans)
	l=len(z[0])

	p1=0
	import math

	myrange=range(115, 220)
	NL= []
	for i in myrange: # (1, l):
		val= phase(z[1][i]) - phase(z[p1][i])
		#if val< 1:
		#	val+=2*math.pi
		tuple=[ i, val ]

		

#		if tuple[0] + tuple[1] < 0:
#			tmp=tuple[1]
#			tuple[1]=-tuple[0]
#			tuple[0]=-tmp

#		if(mag(z[p1][i]) * mag(z[1][i]) > 1000 ):
#		if abs( phase(z[1][i]) - phase(z[p1][i]) - ( phase(z[1][i-1]) - phase(z[p1][i-1])) ) <   1:
		NL.append ( tuple )

#	plt.plot( zip(*NL)[0], zip(*NL)[1])
 	plt.plot( [ mag(x) for x in z[1]] )
 	plt.plot( [ mag(x) for x in z[2]], color="blue" )

# 	plt.plot( [ phase(x) for x in z[0]],
# 			       [ phase(x) for x in z[1]],
##					   color= [ ( 1- i/l ,i/l ,i/l ) for i in range( len(z[0] ))  ],
#						'-*' )

	plt.show()
	
