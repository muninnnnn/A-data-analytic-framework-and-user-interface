#!/usr/bin/env python

from dataparse import datafile_by_index
import math

field="f"

argv[1]=="-f":
	field=argv[2]

# created using something like
# for i in ../worm-data/tags/N2_*.csv ; do ./curvature-plot.py -p 1028 -b foo $i; done

D = datafile_by_index("fwd.out", [0, "number", field])

numbers={}
expectation={}
deviation={}
freqsum={}

CONCENTRATIONS = [ 0.75, 1.00 , 1.25 , 1.50 , 1.75 , 2.00 , 2.25 , 2.50 , 2.75
		, 3.50 , 3.75 , 4.00 ]

for c in CONCENTRATIONS:
	numbers[c] = 0
	freqsum[c] = 0
	expectation[c] = 0

D = datafile_by_index("fwd.out", [0, "number", field])

MINN=25

for i in D:
	c = i[0]
	n = i[1]
	f = i[2]

	if(n>MINN):
		numbers[c] += n
		expectation[c] += f*n

for c in CONCENTRATIONS:
	if(numbers[c]):
		expectation[c] /= numbers[c]
		print(c, expectation[c])
	
	deviation[c] = 0

D = datafile_by_index("fwd.out", [0, "number", field])
	
for i in D:
	c = i[0]
	n = i[1]
	f = i[2]

	if(n<MINN):
		deviation[c] += n*(f-expectation[c])*(f-expectation[c])

for c in CONCENTRATIONS:
	if(numbers[c]):
		d = math.sqrt(deviation[c]/ numbers[c])
		e = expectation[c]
		print(c, e-d, e, e+d, numbers[c])
	

