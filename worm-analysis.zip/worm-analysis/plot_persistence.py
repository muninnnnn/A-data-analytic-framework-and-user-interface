#!/usr/bin/env python
from sys import argv
from sys import stdout
from worm_parse import pvdparse
from error import printn, eprint
import numpy as np
from numpy.linalg import norm

from persistence_fit import fit_rescale

import matplotlib as mpl
mpl.use('agg')

from persistence import getD

from dataparse import datafile_by_index

def getC(fn):
	c = []
	if(fn[-3:]=="out"):
		eprint("incomplete");
		data = datafile_by_index(fn, [0,"centroidx", "centroidy", "centroidz"])
		for i in data:
			a = np.array([i[1], i[2], i[3]])
			c.append(a)
	else:
		a = pvdparse(fn)
		for n,i in enumerate(a):
			w = i.get_worm()
			c.append(w.center_of_gravity())
	return c

from math import exp
def do_it(data, plt, clr):

	w, M = fit_rescale(data)
	w, M = fit_rescale(data)
	w, M = fit_rescale(data)
	w, M = fit_rescale(data)

	for d in data:
		plt.plot(d, color=clr);
	fit = [ exp(w[1])*(i)**w[0] for i in range(M) ]
	plt.plot(fit, 'r--', color=clr);

if __name__ == "__main__":
	assert("-o" == argv[1] )
	outfile = argv[2]

	i=3


	D=[]
	mycolors=[ (0,0,1),  (1,0,0),  (0,1,0),  (1,1,0),   (0,1,1),   (1,0,1)] \
	        +[ (0,0,.5), (.5,0,0), (0,.5,0), (.5,.5,0), (0,.5,.5), (.5,0,.5)] \
			  +[ (0,0,0), (0,0,0)]
	myci=iter(mycolors)
	clr = next(myci)

	data = []

	from matplotlib import pyplot as plt
	for fn in argv[3:]:
		if fn=="-n":
			if len(data):
				do_it(data, plt, clr)
				data = []
				clr = next(myci)
			continue
		eprint("doing ", fn)
		c = getC(fn)
		d = getD(c)
		d = d[:len(d)]
		
		data.append(d)

	do_it(data, plt, clr)

	eprint("TODO: print/include number of frames per exponent")
	eprint("TODO: print scaling used per clip")
	eprint("TODO: add .5")

	if(outfile):
		plt.savefig( outfile )
