#!/usr/bin/env python
from sys import argv
from msToXw import msToXw
from plotPCA import readEwMs
from xwToMs import xwToMs
from sklearn.decomposition import PCA
import sys, os, getopt
import numpy as np

from worm_parse import pvdparse, ptsFromVtu

# this is entirely stupid. don't export.
# (implement properly in worm_parse, one day)
#
def fetchworms(pvdfn, begin, end):
	vtuindex=pvdparse(pvdfn)
	dir=os.path.dirname(pvdfn)

	x=iter(vtuindex)
	i = begin
	for ii in range(begin):
		t=x.next()

	Ms=[]

	while(i!=end):
		try:
			t=x.next()
		except StopIteration:
			break

		f=t.get('file')
		X,W,ign=ptsFromVtu(dir+'/'+f)

		m1, m2, t = xwToMs(X,W)
		M = np.concatenate(( m1, m2) )

		Ms.append(M)

		i+=1
	return Ms

if __name__=="__main__":
	try:
		opts, args = getopt.getopt(sys.argv[1:], "p:c:b:e:", [])
	except getopt.GetoptError as err:
		# print help information and exit:
		print(str(err))  # will print something like "option -a not recognized"
		usage()
		sys.exit(2)

	begin=0
	end=99999

	for o, a in opts:
		if o == "-c":
			clip = a
		elif o in ("-p"):
			pcadump = a
		elif o in ("-b"):
			begin = int(a)
		elif o in ("-e"):
			end = int(a)
		elif o in ("-I"):
			pass
			# incomplete, list of intervals
			

	P = readEwMs(pcadump)
	Ms = fetchworms(clip, begin, end)
	
	pca = PCA(n_components=len(P))

#	print PCAs[-1][0:4], "..."

	index=0
	for i in Ms:
		printn(index)
		for p in P:
			printn(str(abs(np.dot(p, i))))
		print()
		index+=1

