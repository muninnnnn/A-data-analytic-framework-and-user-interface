#!/bin/bash

set -e

videodir=/nobackup/scsrih/video
outdir=/nobackup/scsfsa/output-curve/000000

echo \# % type date_id total keypoints skeletons txt tags cogs gaits
# 3 1.00 N2 20160426_trial02 14975 13704 12000


i=0

cat $1 | \
while read csv_line; do
	if [ ${csv_line:0:1} = "#" ]; then
		continue
	fi
	i=$(( i + 1 ))
	IFS=',' read -ra params <<< "$csv_line"

	CONCENTRATION="${params[8]}"
	CURVE_PREFIX_PRE=`dirname ${params[7]}`
	CURVE_PREFIX_POST=`basename ${params[7]}`

	what=${CURVE_PREFIX_POST##*pc_}
	TYPE=${CURVE_PREFIX_POST%%_*}
	test -n "$what" || continue
	# echo ---- $CURVE_PREFIX_POST
	p=$( grep $what stats_videolen | tail -n1 )
	if [ -z "$p" ]; then
		echo cannot find len for $what >&2
		continue
	fi
	dir="$outdir/*$CURVE_PREFIX_POST"
	echo -n "$i $CONCENTRATION $TYPE $what "

	q=( $p )
	tot=${q[1]}

	if eval test -d "$dir"; then
	 :
  	else
	 echo $tot 0 0 missing
	 continue
 	fi

	# /nobackup/scsfsa/output-curve/000000/*20160427_trial05*/dist*.csv | wc -l

	# echo $dir
	# echo "find $outdir/*$CURVE_PREFIX_POST -name 'dist*.csv' | wc -l"
	kcount=$( find $dir -name 'dist*.csv' | wc -l )
	count=$( find $dir -name 'skel*.vtu' | wc -l )
	tags=$( ./taggedworms.py -t ../worm-data/tags/$CURVE_PREFIX_POST.csv  )
	gaits=$( ./taggedworms.py -g ../worm-data/tags/$CURVE_PREFIX_POST.csv  )
	cogs=$( ./taggedworms.py -c ../worm-data/tags/$CURVE_PREFIX_POST.csv  )
	txt=$( grep -v '^#' $dir/skeletons_worm.txt 2>/dev/null | wc -l )

#	echo $CURVE_PREFIX_POST
	echo $leaf $tot $(( $kcount / 3 )) $count $txt $tags $cogs $gaits
	# echo $leaf $tot $kcount $count
done
