#!/usr/bin/env python
from __future__ import print_function
from sys import argv
import sys
from gait import stringtogait
from error import eprint


DEFAULT_VIDEODIR="/nobackup/scsrih/video"
DEFAULT_SKELETONDIR="/nobackup/scsrih/output-curve/000000"

# does not work
#from error import eprint
class tagindicator:
	def __init__(self, ft):
		self.ft_ = ft
		self._all = False;

	def select_all(self):
		self._all = True;
	
	def __call__(self, number):
#		if(self._all):
#			return True
		# eprint(self.ft_.get_tag(number))
		return self.ft_.get_tag(number)

class dummytags():
	def __bool__(self):
		return False
	def get_tag(self, x):
		return []


class frame_tags():
	def __init__(self, tagfile, videodir=DEFAULT_VIDEODIR, skeletondir=DEFAULT_SKELETONDIR):
#		eprint("frametags from", DEFAULT_SKELETONDIR + "\n")
		self.size_ = 0
		self._numtags = 0
		self._numgaits = 0
		self._numcogs = 0
		self.videodir_ = videodir
		self.skeletondir_ = skeletondir
		f = open(tagfile)
		# ouch.
		self._a = [None]*100000

		self._g = [0]*100000

		# YUCK
		firstline=f.readline()
		self._videofn = firstline[2:].split(',')[0]
		self._concentration = 0

		for line in f:
			if line[0:8]=='# media:':
				chunk = line[9:].split(",")[0]
				self._concentration = float(chunk)
			elif line[0]=='#':
				continue
			else:
				s=line.split('\n')[0]
				s=s.split(',')
				myrange=s[0].split('-')
				if(len(myrange[0])==0):
					eprint("BUG in tagfile. missing frame range")
					l=0
					u=-1
				elif(len(myrange)==1):
					if(myrange[0]=='*'):
						l = 0
						u = self._numtags-1
					else:
						eprint("aaa", tagfile, myrange[0], len(myrange[0]))
						l = u = int(myrange[0])
				elif(len(myrange)>2):
					# eprint("BUG in tagfile")
					continue
				else:
					l = int(myrange[0])
					if (myrange[1]=="*"):
						u = self._numtags-1
					else:
						u = int(myrange[1])
				eprint("got!", l, u)
				self.size_ = max(self.size_, u)
				for i in range(l, u+1):
					if(self._a[i]):
						eprint(i, "already tagged!!", len(s))
						for k in range(len(s)-1):
							if k >= len(self._a[i]):
								# eprint("append " + s[k+1])
								self._a[i].append(s[k+1])
							elif s[k+1]:
								# eprint("replace" + str(self._a[i]))
								# eprint("replace" + s[k+1])
								self._a[i][k] = s[k+1]
					else:
						# not tagged yet.
						#eprint("tagging", i, self._numtags)
						self._numtags += 1
						self._a[i] = s[1:]

		for i, x in enumerate(self._a):
			if x:
				for s in x[:3]:
					self._g[i] |= stringtogait(s)

			if self._g[i]:
				self._numgaits += 1

				self._numcogs += 1
			elif type(x) == type(None):
				pass

			elif len(x)>6:
				if x[6]=="1":
					self._numcogs += 1


	def get_concentration(self):
		return self._concentration
	def get_tag(self, framenumber):
		# BUG. don't use
		# eprint(framenumber)
		return self._a[framenumber]
	def __call__(self, framenumber):
		return self._a[framenumber]

	def videofilename(self):
		return self._videofn
	def numgaits(self):
		return self._numgaits
	def numcogs(self):
		return self._numcogs
	def numtags(self):
		return self._numtags
	def size(self):
		return self.size_
	def __iter__(self):
		print(self.videodir_ + "/" + self._videofn + ".mp4")
		print(self.skeletondir_ + "/" + self._videofn + "/")
		return iter(self._a)

def make_frame_tags(fn):
		if not fn:
			return dummytags()
		else:
			return frame_tags(fn)

if __name__=="__main__":
	numtags = 0

	i=1
	mode=""
	if argv[i]=="-n":
		mode="number"
		i+=1
	elif argv[i]=="-a":
		mode="all"
		i+=1

	for f in argv[i:]:
		a = frame_tags(f)
		numtags += a.numtags()

	if mode=="number":
		print(numtags)
	elif mode=="all":
		for i in range(a.numtags()):
			print(i, a.get_tag(i))
	else:
		print("no mode")
