#!/usr/bin/env python

import numpy as np
from numpy.linalg import norm
from sys import argv
import os
from xwToMs import xwToMs, cXwToMs, an_orthonormal
from math import sin, cos, pi

def cMsToXw( m1, m2, tau_=np.array([1,0,0]), theta=0, mid=[0,0,0] ):

    nPoints = len(m1)
    midn = nPoints//2
    H = midn - 1

    assert(not nPoints % 2)
    dims = (nPoints, 3)
    X = np.zeros( dims )
    W = np.zeros( dims )
    tau = np.zeros( dims )
    M1 = np.zeros( dims )
    M2 = np.zeros( dims )

    X[nPoints//2-1] = mid - tau_ / ((nPoints-1)*2)
    X[nPoints//2] = mid + tau_ / ((nPoints-1)*2)
    tau[H] = tau_ / norm(tau_)
    M1[H] = an_orthonormal(tau[H])
    M2[H] = np.cross(tau[63], M1[H])

    scale = np.linalg.norm(tau_)

    if(nPoints != len(m2)):
        raise ValueError("must be the same size")

    h = 1. / (nPoints-1) * scale

    # rotate back...
    st = sin(-theta)
    ct = cos(-theta)

    # going backwards
    for j in range(H-1, -1, -1):
        m1r = ct * m1[j] - st * m2[j]
        m2r = st * m1[j] + ct * m2[j]

        tauJtilde = tau[j+1] - h * (  m1r * M1[j+1] + m2r * M2[j+1] )
        M1Jtilde = M1[j+1] + h * (  m1r * tau[j+1] )
        M2Jtilde = M2[j+1] + h * (  m2r * tau[j+1] )

        tau[j] = tauJtilde / norm(tauJtilde);
        M1[j] = M1Jtilde / norm(M1Jtilde);
        M2[j] = M2Jtilde / norm(M2Jtilde);

    for j in range(midn, nPoints):
        m1r = ct * m1[j] - st * m2[j]
        m2r = st * m1[j] + ct * m2[j]

        tauJtilde = tau[j-1] + h * ( m1r * M1[j-1] + m2r * M2[j-1] )
        M1Jtilde = M1[j-1] + h * ( -m1r * tau[j-1] )
        M2Jtilde = M2[j-1] + h * ( -m2r * tau[j-1] )

        tau[j] = tauJtilde / norm(tauJtilde);
        M1[j] = M1Jtilde / norm(M1Jtilde);
        M2[j] = M2Jtilde / norm(M2Jtilde);

    #h *= scale
    for j in range(H, -1, -1):
        assert(abs(norm(tau[j])-1) < 1e-9)
        X[j] = X[j+1] - h * tau[j]

        W[j] = m1[j] * M1[j] + m2[j] * M2[j];


    for j in range(65,nPoints):
        assert(abs(norm(tau[j])-1) < 1e-9)
        X[j] = X[j-1] + h * tau[j-1]

        W[j] = m1[j] * M1[j] + m2[j] * M2[j];

    return X, []

def cMToXw( M, tau_=np.array([1,0,0]), theta=0, mid=[0,0,0] ):
    nPoints = len(M)
    if np.iscomplexobj(M):
        m1 = M.real
        m2 = M.imag
    else:
        assert(not nPoints % 2)
        nPoints = len(M)/2
        m1 = np.array(M[0:nPoints])
        m2 = np.array(M[nPoints:])

    return cMsToXw(m1, m2, tau_, theta, mid)



def mToXw( M, tau_=[1,0,0], theta=0, start=[0,0,0] ):

    if M.dtype==np.dtype('complex'):
        m1 = M.real
        m2=M.imag
        return msToXw(m1, m2, tau_, theta, start)


    nPoints = len(M)//2
    m1=np.array(M[0:nPoints])
    m2=np.array(M[nPoints:2*nPoints])

    return msToXw(m1, m2, tau_, theta, start)


def msToXw( m1, m2, tau_=np.array([1,0,0]), theta=0, start=[0,0,0] ):
    nPoints = len(m1)
    scale = np.linalg.norm(tau_)
    tau_ = tau_ / scale

    if(nPoints != len(m2)):
        raise ValueError("must be the same size")

    h = 1. / (nPoints-1) * scale
    scale = 1

    dims = (nPoints, 3)
    tau = np.zeros( dims )
    M1 = np.zeros( dims )
    M2 = np.zeros( dims )
    tau[0] = tau_
    M1[0] = an_orthonormal(tau[0])
    M2[0] = np.cross(tau[0], M1[0])

    # rotate back...
    st = sin(-theta)
    ct = cos(-theta)
    # m1 <- ct * m1 - st * m2
    # m1 <- st * m1 + ct * m2

    for j in range(1, nPoints):
        m1r = ct * m1[j] - st * m2[j]
        m2r = st * m1[j] + ct * m2[j]

        t = -m2r * h
        p = m1r * h

        tau[j] = tau[j-1] * np.cos(t) * np.cos(p) \
                 + M1[j-1] * np.cos(t) * np.sin(p) \
                 - M2[j-1] * np.sin(t)

        M1[j] = M1[j-1] * np.cos(p) \
                - tau[j-1] * np.sin(p)

        M2[j] = M2[j-1] * np.cos(t) \
                + M1[j-1] * np.sin(p) * np.sin(t) \
                + tau[j-1] * np.cos(p)*np.sin(t)

    X = np.zeros( dims )
    W = np.zeros( dims )

    X[0] = start

    #print "delta", tau[0]

    for j in range(1,nPoints):
        X[j] = X[j-1] + h * tau[j-1]
        # incomplete rotate w?
        W[j] = m1[j] * M1[j] + m2[j] * M2[j];

# 	X[1] = X[0] + tau[0]

    return X, []

if __name__=="__main__":

    i=1
    centered=False
    if argv[i]=="-c":
        centered = True
        i+=1

    pvdfn=argv[i]

    from worm_parse import pvdparse, ptsFromVtu
    vtuindex=pvdparse(pvdfn)
    dir=os.path.dirname(pvdfn)

    x=iter(vtuindex)
    t=x.next()
    i+=1
    if(len(argv)>i):
        fn=int(argv[i])
        print("#frame", fn)
        for i in range(int(argv[i])):
            t=x.next()

    f=t.get('file')

    X,W,ign = ptsFromVtu(dir+'/'+f)

#	x = iter(vtuindex)
#	t = next(x)
#	if(len(argv)>2):
#		fn=int(argv[2])
#		print("#frame", fn)
#		for i in range(int(argv[2])):
#			t=x.next()
    # print "doing m1, m2"
    if(centered):
        m1, m2, nu = cXwToMs(X, W)
    else:
        m1, m2, nu = xwToMs(X, W)

    tau = X[1]-X[0]
    # tau/=norm(tau)
    tau *= 127.

    center = (X[63]+X[64])/2
    ctau = X[64]-X[63]
    ctau *= 127.

    Xn,W = msToXw(m1, m2)
    if(centered):
        Xr,W = cMsToXw(m1, m2, ctau, nu, center)
    else:
#        X,W = msToXw(m1, m2, tau, nu, X[0])
#        m1, m2, nu = xwToMs(X, W)
        Xr,W = msToXw(m1, m2, tau, nu, X[0])

    from matplotlib import pyplot as plt
    from matplotlib import gridspec
    from mpl_toolkits.mplot3d import Axes3D

    fig = plt.figure(facecolor='white')

    gs = gridspec.GridSpec(3, 4)
    ax0 = fig.add_subplot(gs[0:3,0:3], projection='3d')

    for j in range(len(X)-1):
        ax0.plot( [X[j][0], X[j+1][0]], \
                      [X[j][1], X[j+1][1]], \
                      [X[j][2], X[j+1][2]], \
                        color = 'green' , linewidth=3)

    eps=0.
    for j in range(len(Xr)-1):
        ax0.plot( [Xr[j][0]+eps, Xr[j+1][0]+eps], \
                      [Xr[j][1], Xr[j+1][1]], \
                      [Xr[j][2], Xr[j+1][2]], \
                        color = 'red' , linewidth=3)

    from worm_parse import point_distance
    print("distance",  point_distance(X, Xr))

    ax0.scatter( X[0][0], X[0][1], X[0][2], color='blue' )
    plt.show()
###
###	for i in range(len(X)):
###		print i, X[i][0], Xr[i][0], Xn[i][0],\
###		         X[i][1], Xr[i][1], Xn[i][1],\
###		         X[i][2], Xr[i][2], Xn[i][2]


# vim:ts=8:sw=4:et
