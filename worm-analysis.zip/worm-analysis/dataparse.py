from __future__ import print_function

from error import eprint

class datafile_by_index:
	def __init__(self, fn, indexlist):
		self._f = open(fn, "r")
		self._i = indexlist
		self._s = next(self._f)

		keys = []
		if(self._s[0]=='#'):
			keys = self._s[:-1].split()
		
		print("keys", keys)
		for i,k in enumerate(self._i):
			if type(k)==str:
				print(k)
				for j,l in enumerate(keys):
					if l==k:
						self._i[i]=j
						eprint("found", l, j)
						break;


	def __iter__(self):
		return self

	def next(self):
		return self.__next__()

	def __next__(self):
		self._s = next(self._f)
		while(self._s[0]=='#'):
			self._s = next(self._f)
		v = self._s.split()
		x = []

		try:
			for i in self._i:
				x.append(float(v[i]))
		except:
			print("ERROR", self._s, self._i)
			raise

		return x
