outfile = open('../roi_run_other.sh','w')
outfile.write('#!/bin/bash\n\nset -e\nset -u\n\n')

base='/home/csunix/scstr/Software/WORMS/data-analysis/matlab/eigenworm/data/nobackup/scsrih/output-curve/223137'

infile = open('regions_of_interest.txt')
for line in infile.readlines():
    data = line.split(':')
    trialId=data[0]
    frames=data[1]

    if ',' in data[1]:
        segs = frames.split(',')
    elif '-' in data[1]:
        segs = [ data[1] ]
    else:
        continue

    for seg in segs:
        try:
            ss = seg.split('-')
            startFrame = int(float(ss[0])*25.0)
            endFrame = int(float(ss[1])*25.0)+1
        except:
            print seg
            print segs
            print data
            print line
            exit()

        output_dir="curvature-plots/sub-tests/{0}_{1}_{2}".format( trialId, startFrame, endFrame )
        outfile.write('echo {output_dir} && mkdir -p {output_dir} && python -O extract-undulations.py pvd_dir:{pvd_dir} output_dir:{output_dir} start_frame:{start_frame} end_frame:{end_frame} | tee {output_dir}.out\n'.format( output_dir=output_dir, pvd_dir=base+'/'+trialId, start_frame = startFrame, end_frame = endFrame ))


