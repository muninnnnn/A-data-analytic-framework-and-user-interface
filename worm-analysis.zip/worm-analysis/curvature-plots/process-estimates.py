import os
from matplotlib import pyplot as plt
import numpy as np
from scipy import stats
import re

plt.figure(0)
plt.xlabel('half time period')
plt.ylabel('half space period')

def parseFn( fn ):
    data = fn.split('_')
    strain = data[0]
    media = float(data[1]+data[2][:2])/100.0
    date = data[3]
    trial = int(data[4][5:7])

    return strain, media, date, trial

def median( list ):
    return list[ len(list)/2 ]

def middleOfContourFromFit( fit ):
    p0 = np.array([ -fit[1] / fit[0], 0.0 ])
    p1 = np.array([ ( 128-40 -fit[1]) / fit[0], 128-40.0 ])
    return (p0+p1)/2.0

def contourDist(Pa,Pb):
    p0a = [ -Pa[1] / Pa[0], 0 ]
    p0b = [ -Pb[1] / Pb[0], 0 ]
    p1a = [ ( 128-40 -Pa[1]) / Pa[0], 128-40 ]
    p1b = [ ( 128-40 -Pb[1]) / Pb[0], 128-40 ]
    xDist = (( p0a[0] - p0b[0] ) + ( p1a[0] - p1b[0] ) )/ 2.0

    midx = (( p0a[0] + p0b[0] ) + ( p1a[0] + p1b[0] ) ) / 4.0
    yDist = (Pa[0] - Pb[0] )*midx + (Pa[1] - Pb[1])

    return (abs(xDist)/25.0,abs(yDist)/128.0)

Dict = {}
subdirs = [ f for f in os.listdir('sub-tests') if f.endswith('.out') ]
for fn in sorted( subdirs ):
    strain,media,date,trial = parseFn(fn)

    if not media in Dict:
        Dict[media] = []

    file = open('sub-tests/' + fn)
    lines = file.readlines()
    reading = False
    fits = []
    for line in lines:
        if '** end **' in line:
            reading = False
            continue
        # if '** Undulation parameter estimates **' in line:
        if '** Polyfit fits **' in line:
            reading = True
            continue
        if reading:
            try:
                dd = line.split(',')
                length = int(dd[0])
                pairString = dd[1].replace('[','').replace(']','')
                data = pairString.split()
                fits.append( [float(data[0]), float(data[1]), length] )
            except:
                print 'UNREADABLE: ', line

            # try:
            #     data = line.split()
            #     time = abs(float( data[1][1:-1] ))
            #     dist = abs(float( data[2][1:-1] ))
            #     Dict[ media ].append( [time,dist] )
            #     fits.append( [time,dist] )

            #     plt.figure(0)
            #     plt.plot( 1.0/time, 2.0*dist, 'x', color=(media/4.0,1.0-media/4.0,1.0) )
            #     plt.figure(12)
            #     plt.subplot(1,2,2)
            #     plt.plot( media,dist, 'x', color=(media/4.0,1.0-media/4.0,1.0) )
            #     plt.subplot(1,2,1)
            #     plt.plot( media,time, 'x', color=(media/4.0,1.0-media/4.0,1.0) )

            # except:
            #     print 'UNREADABLE', line

    fits.sort( key = lambda fit : middleOfContourFromFit( fit )[0] )
    for j in range(len(fits)-1):
        time, dist = contourDist( fits[j], fits[j+1] )
        if time > 3.0 or dist > 3.0:
            continue
        Dict[ media ].append( [time,dist] )
        if media < 1.01: continue

        plt.figure(0)
        plt.plot( time, dist, 'x', color=(media/4.0, 1.0-media/4.0,1.0) )
        plt.figure(12)
        plt.subplot(1,2,2)
        plt.plot( media,dist, 'x', color=(media/4.0,1.0-media/4.0,1.0) )
        plt.subplot(1,2,1)
        plt.plot( media,time, 'x', color=(media/4.0,1.0-media/4.0,1.0) )

    # # if( len(fits) != 0 ): # and media == 0.75 and trial==01 ):
    #     # fits.sort( key = lambda x : -x[1]/x[0] )
    #     plt.clf()
    #     plt.title( fn )

    #     # for i in xrange(1,len(fits)-1):
    #     #     print fits[i-1],fits[i],fits[i+1]

    #     # plt.hist( [m for m,c in fits], bins=int( np.sqrt(len(fits))))
    #     # plt.plot( [m for m,c in fits], '.' )
    #     plt.plot( [l for m,c,l in fits], [m for m,c,l in fits], '.' )
    #     plt.show()
    #     raw_input()

nMedia = len(Dict)

n = np.floor( np.sqrt(nMedia) )
m = nMedia / n
while n*m != nMedia:
    n = n-1
    m = nMedia / n

for j,(media, params) in enumerate(sorted(Dict.iteritems())):

    if( len(params) == 0 ):
        continue
    if( media < 1.01 ): continue

    p = np.array(params)
    x = np.array( [ _x for _x,_y in p if _x < 3 and _y < 3 ] )
    y = np.array( [ _y for _x,_y in p if _x < 3 and _y < 3 ] )

    if( len(x) <= 1 or len(y) <= 1):
        continue

    plt.figure(1)
    plt.subplot( n, m, j )
    plt.title('{}%'.format(media))
    plt.hist(x,bins=30 )
    plt.figure(2)
    plt.subplot( n, m, j )
    plt.title('{}%'.format(media))
    plt.hist(y,bins=30 )
    plt.figure(3)
    plt.subplot( n, m, j )
    plt.title('{}%'.format(media))
    plt.hist2d( x,y,
                cmap='Blues', bins=30 )

    plt.figure(12)
    mm = [ stats.trim_mean( p[:,0], 0.1 ),  stats.trim_mean( [ p_ for p_ in p[:,1] ], 0.1 ) ]
    plt.subplot( 1, 2, 1 )
    plt.title( 'half time period (s)')
    plt.plot( media, mm[0], 'o', color=(media/4.0,1.0-media/4.0,1.0) )
    plt.subplot( 1, 2, 2 )
    plt.title( 'half space period (mm)')
    plt.plot( media, mm[1], 'o', color=(media/4.0,1.0-media/4.0,1.0) )
    plt.figure(13)
    plt.plot( mm[0], mm[1], 'o', color=(media/4.0,1.0-media/4.0,1.0) )
    plt.figure(0)
    plt.plot( mm[0], mm[1], 'o', color=(media/4.0,1.0-media/4.0,1.0) )

    print media, mm, len(p), len(x)

plt.figure(0)
plt.suptitle('time vs space periods')
plt.savefig('undulations_time_vs_space_periods.pdf')

plt.figure(1)
plt.suptitle('time period distribution per media')
plt.savefig('undulations_time_period_distribution.pdf')

plt.figure(2)
plt.suptitle('space period distribution per media')
plt.savefig('undulations_space_period_distribution.pdf')

plt.figure(12)
plt.suptitle('time, space vs media (with trimmed means)')
plt.savefig('undulations_time_space_vs_media.pdf')

plt.figure(13)
plt.suptitle('mean time vs space periods')
plt.savefig('undulations_time_vs_space_periods_mean.pdf')
