#!/usr/bin/env python
from __future__ import print_function
from itertools import tee, izip, islice
import numpy as np
from error import eprint
from sys import stderr

def dprint(*args, **kwargs):
	   print("#", *args, **kwargs)
	   # print(*args, file=stderr, **kwargs)

fid=0
epsilon=1e-4
NHMAX=6
H=10

def outdata(X, h=0, p=0):
	global fid
	print(fid, X[0], X[1], X[2], h, p)
	fid += 1

class turn:
	def __init__(self, b, e, X, h):
		self._b = b
		self._e = e

		self._center = (b+e)/2

		print("# TURN ["+str(b)+", "+str(e)+"] len", e-b, "center",
				self._center, "h", h)
		X[self._center][4] = h
		
class segment:
	def segment_it(self, X, nh):
		if nh>NHMAX:
			return
		h = 2**nh*H
		b = self._b
		e = self._e

		turnstart = None
		turnstart = 0
		turnend = b
		t0 = 0;
		for i in range(b+h, e-h):
			x = X[i][:2]
			xlo = X[i-h][:2]
			xhi = X[i+h][:2]

			d0 = x - xlo
			d1 = xhi - x
			p = np.dot(d0, d1)

			if(t0):
				t0 = p<epsilon*h
			else:
				t0 = p<-epsilon*h

			if(t0):
				# eprint(b,e,nh)

				assert(not X[i][3])
				X[i][3] = nh
				if(turnstart):
					# within turn
					pass
				else:
					turnstart = i
					# eprint("segment", turnend, turnstart, h)
					print("# SEGMENT", h,
							"from", turnend, "to", turnstart, "len", turnstart-turnend)
					newseg = segment(turnend+h, turnstart-h, X, nh+1)
					self._segments.append(newseg)
			else: # !t0
				if(turnstart):
					turnend = i
					newturn = turn(turnstart, turnend, X, nh)
					self._turns.append(newturn)
					turnstart = 0
				else:
					pass

		# open turn
		if(turnstart):
			newturn = turn(turnstart, e, X, nh)
			self._turns.append(newturn)
			turnend = 0

#		if(not len(self._turns)):
#			print("# SEGMENT recurse")
#				
#			recursive_segment = segment(b+h, e-h, X, nh+1)
#			return recursive_segment



	def __init__(self, b, e, X, nh):
		self._b = b
		self._e = e
		self._segments=[]
		self._turns=[]

		while not len(self._turns):
			self.segment_it(X, nh)
			nh += 1
			if nh>NHMAX:
				break
#		print("# found", len(self._turns), " turns", b, e, h)

if __name__=="__main__":
	from sys import argv

	f = open(argv[1],'r')
	X = []

	for line in f.readlines():
		if '#' == line[0]:
			continue
		else:
			l = line.split(' ')
			c = float(l[2]), float(l[3]), float(l[4]), 0, 0
			X.append(c)

#	X = np.array(X[:1000])
	X = np.array(X)
	h = 10

	root = segment(0, len(X), X, 1)

	for i in X:
		outdata(i, i[3], i[4])


