from sys import argv

if len(argv) > 1:
    fn = open(argv[1], "r")

for line in fn:
    x = line.split()
    print len(x)
