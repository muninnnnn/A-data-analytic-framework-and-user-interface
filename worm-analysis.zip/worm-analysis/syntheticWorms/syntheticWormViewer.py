from matplotlib import pyplot as plt
from matplotlib import gridspec
from mpl_toolkits.mplot3d import Axes3D
import sys

if len(sys.argv) < 2:
    print "Please give file"
    sys.exit()

filename = sys.argv[1]
f = open(filename, "r")

Xpts = []
Ypts = []
Zpts = []

for line in f:
    x = line.split()
    Xpts.append(float(x[0]))
    Ypts.append(float(x[1]))
    Zpts.append(float(x[2]))


fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.plot(Xpts, Ypts, Zpts)

plt.show()
