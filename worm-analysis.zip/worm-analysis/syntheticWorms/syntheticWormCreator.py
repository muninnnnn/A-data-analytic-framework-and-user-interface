#!/usr/bin/env python

# Creates a vtu file from a parametric curve
# vtu has 128 equidistant points with total length 1
#
# Usage: python syntheticWormCreator.py
#
#
# Author: Patrick Fox
# 1/8/17
#

from __future__ import print_function

from sympy import *
from sympy.plotting import plot3d_parametric_line
from sympy.parsing.sympy_parser import parse_expr
from matplotlib import pyplot as plt
from matplotlib import gridspec
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from numpy.linalg import norm
from sys import argv
import sys
import os

header = '''<?xml version="1.0"?>
<VTKFile type="UnstructuredGrid" version="0.1" byte_order="LittleEndian">
  <UnstructuredGrid>
    <Piece NumberOfPoints="128" NumberOfCells="127">
      <PointData Scalars="W">
        <DataArray type="Float32" Name="W" NumberOfComponents="3">'''

section0 = '''        </DataArray>
        <DataArray type="Float32" Name="u" NumberOfComponents="1">'''
section1 = '''        </DataArray>
       </PointData>
       <CellData Scalars="P">
        <DataArray type="Float32" Name="P" NumberOfComponents="1">'''
section2 = '''        </DataArray>
       </CellData>
       <Points>
        <DataArray type="Float32" NumberOfComponents="3" format="ascii">'''
section3 = '''        </DataArray>
       </Points>
       <Cells>
        <DataArray type="Int32" Name="connectivity" format="ascii">'''
section4 = '''        </DataArray>
        <DataArray type="Int32" Name="offsets" format="ascii">'''
section5 = '''        </DataArray>
        <DataArray type="Int32" Name="types" format="ascii">'''
section6 = '''        </DataArray>
        </Cells>
    </Piece>
  </UnstructuredGrid>
</VTKFile>
'''


def XtoW(X):
    wl = len(X)
    q = np.array( [0] + [ norm( X[i+1] - X[i] ) for i in range(wl-1) ] + [0] )
    M = np.array( [ .5*(q[i] + q[i+1]) for i in range(wl) ] )
    SX = np.array( [ (X[i] - X[i-1])/q[i] - (X[i+1] - X[i]) / q[i+1] for i in range(1, wl-1) ] )

    W = np.zeros((wl,3))
    for i in range(1, wl-1):
        W[i] = - SX[i-1]/M[i]

    return W

def syntheticVTU(pts, name):

    fn = open(name, "w")

    X1 = [np.array(pts[3*j:3*(j+1)]) for j in range(len(pts)//3)]
    print("have", len(X1))
    W = XtoW(X1)

    fn.write(header)
    fn.write(os.linesep)
    s = "\t"
    for i in W:
        for k in i:
            s += repr(k) + " "

    fn.write(s+"\n")

    fn.write(section0)
    fn.write(os.linesep)
    fn.write(section1)
    fn.write(os.linesep)
    fn.write(section2)
    fn.write(os.linesep)
    s = "\t"
    for i in pts:
        s += repr(i) + " "
    fn.write(s)
    fn.write(os.linesep)
    fn.write(section3)
    fn.write(os.linesep)


    connectivity= "\t0"
    for i in range(1, len(pts),1):

        connectivity += " "+repr(i-1)+" "+repr(i)

    fn.write(connectivity)
    fn.write(os.linesep)
    fn.write(section4)
    fn.write(os.linesep)
    offset = ""
    celltype = ""
    for i in range(1, len(pts)//3, 1):
        offset += repr(i*2) + " "
        celltype += "3 "

    fn.write(offset)
    fn.write(os.linesep)
    fn.write(section5)
    fn.write(os.linesep)
    fn.write(celltype)
    fn.write(os.linesep)
    fn.write(section6)

def curveToArray(X, Y, Z):
    Xpts = []
    Ypts = []
    Zpts = []
    for i in np.arange(0, 3, 0.1):
        x = X.subs(u, i).evalf()
        y = Y.subs(u, i).evalf()
        z = Z.subs(u, i).evalf()
        Xpts.append(x)
        Ypts.append(y)
        Zpts.append(z)

    return [Xpts, Ypts, Zpts]

def toArray(X, Y, Z, k, h):
    Xpts = []
    Ypts = []
    Zpts = []
    print("toarray", k, h)
    for i in np.arange(0.01+h, k, float((k-0.01-h)/128.)):
        x = X.subs(u, i).evalf()
        y = Y.subs(u, i).evalf()
        z = Z.subs(u, i).evalf()
        Xpts.append(x)
        Ypts.append(y)
        Zpts.append(z)

    print("L", len(Xpts))
    assert len(Xpts) == 128

    return [Xpts, Ypts, Zpts]

def plot(f, k):
    Xpts, Ypts, Zpts = toArray(f[0], f[1], f[2], k)

    # Plot 3d parametric curve
    fig = plt.figure(figsize=(8,8))
    ax = fig.add_subplot(1, 1, 1, projection='3d')
    #ax.view_init(elev=10, azim=-90)
    ax.plot(Xpts, Ypts, Zpts)

    plt.show()

if __name__=="__main__":
    if len(argv) < 4:
        print("**** this program does not work at all ****")
        print("Usage: python syntheticWormCreator.py")
        print("components should be in terms of parameter 'u'")
        # incomplete

    u, t, s = symbols('u t s', positive=True)
    X = 0.1*u
    Y = 0.1*sin(u)
    # Z = parse_expr('0')
    Z = 0.1*cos(u)
    f = [X, Y, Z]
    print("Parametric curve: ")
    pprint(f, use_unicode=True)

    Xp = X.evalf(subs={u: 0})
    Yp = Y.evalf(subs={u: 0})
    Zp = Z.evalf(subs={u: 0})
    s = 0
    name = "synthetic.vtu"

    for k in range(0, 100, 1):
        print(name)
        h = k//10.
        for i in np.arange(0.01+h, 20+h, 0.002):
#            print("nprange", i)
            Xp = X.evalf(subs={u: i})
            Yp = Y.evalf(subs={u: i})
            Zp = Z.evalf(subs={u: i})
            Xn = X.evalf(subs={u: i+0.002})
            Yn = Y.evalf(subs={u: i+0.002})
            Zn = Z.evalf(subs={u: i+0.002})

            s += ((Xn-Xp)**2 + (Yn-Yp)**2 + (Zn-Zp)**2)**0.5

            if (s > 0.99 and s < 1.01):
                print("s", s)
                points = toArray(X, Y, Z, i, h)
                pts = []
                for j in range(len(points[0])):
                    pts.append(float(points[0][j]))
                    pts.append(float(points[1][j]))
                    pts.append(float(points[2][j]))

                assert len(pts) == 128*3
                syntheticVTU(pts, name)
                break
            if s > 3:
                print("Length of worm not 1, abandoning vtu")

                print("Worm ", str(k), " Created")
                s = 0
                #plot(f, i)

# vim:ts=4:sw=4:et
