#!/usr/bin/env python3

from matplotlib import cm
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import os
import parameters
import sys
from sys import argv
from error import eprint

from matplotlib import rcParams
rcParams['axes.labelsize'] = 21
rcParams['xtick.labelsize'] = 21
rcParams['ytick.labelsize'] = 21
rcParams['legend.fontsize'] = 10

from matplotlib import rcParams
rcParams['font.family'] = 'sans'
rcParams['font.serif'] = ['Computer Modern Roman']
rcParams['text.usetex'] = True

golden_ratio  = (np.sqrt(5) - 1.0) / 2.0  # because it looks good

fig_width_in  = 5.90551
fig_height_in = fig_width_in * golden_ratio   # figure height in inches
fig_dims    = [fig_width_in, fig_height_in] # fig dims as a list

from matplotlib.ticker import MaxNLocator
my_locator = MaxNLocator(4)

from dataparse import datafile_by_index

HMAX=5
def turncolor(t):
	if t==1:
		return "red"
	elif t==2:
		return "blue"
	elif t==3:
		return "green"
	elif t==4:
		return "cyan"
	elif t==5:
		return "yellow"
	if t==0:
		return (0,0,0)
	if t<=HMAX:
#		return cm.hsv(t/HMAX)
		return (1-t/HMAX,t/HMAX,1-t/HMAX)
	elif t==20:
		return "green"

	elif t==50:
		return "cyan"

	return "red"

if __name__ == "__main__":

	b = 0
	e = -1

	i=1
	base="."
	while(argv[i][0]=="-"):
		a = argv[i]
		if a=="-b":
			i += 1
			b = int(argv[i])
		elif a=="-e":
			i += 1
			e = int(argv[i])

		i += 1




	filename = sys.argv[i]

	# data = datafile_by_index(filename, [0,1,2,3,4,5])
	rawdata = datafile_by_index(filename, [0,"centroidx", "centroidy", "centroidz"])
	data=[]
	for t in rawdata:
		data.append(t)

	data = data[b:e]

	fig = plt.figure(figsize=fig_dims)
	ax = fig.gca(projection='3d')
	t=0;
	print("number of points", len(data))
	L = len(data)
	for di, tuple in enumerate(data):
				frame_number,x,y,z = tuple
				t=c=0
				t_color=di/L
				if(di==0):

					oldx, oldy, oldz = [ x,y,z ]
					ax.scatter( oldx, oldy, oldz, color='blue' )
					continue

				if(c):
					ax.scatter( x, y, z, color=turncolor(c), s=40 )
		
		# nPlots = len(times) / min(500,len(times)) + 1
				c = di/250.
				while c > 1: c = c - 1
#				ax.plot( [oldx, x], [oldy, y], [oldz, z], color=cm.hsv( c ) )
				ax.plot( [oldx, x], [oldy, y], [oldz, z], color=cm.winter(t_color) )
				oldx, oldy, oldz = [ x,y,z ]
#            # plt.title( trialId + ':' + 'trajectory' )
#
				ax.set_xlabel('(mm)')
				ax.set_ylabel('(mm)')
				ax.set_zlabel('(mm)')
#
				ax.xaxis.set_major_locator( MaxNLocator(4) )
				ax.yaxis.set_major_locator( MaxNLocator(4) )
				ax.zaxis.set_major_locator( MaxNLocator(4) )
#
#
	outdir = "." # does not work??!
	trialId = "0"
#	plt.show()
	fn = os.path.join( outdir , trialId + '_' + str(b) + '-' + str(e) + '_trajectory.pdf' )
	print('saving', fn)

	plt.savefig( fn )
# 	plt.savefig( os.path.join(  trialId + '_' + 'trajectory.png' ) )
