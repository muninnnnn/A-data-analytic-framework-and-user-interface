#!/usr/bin/env python
from error import eprint
from sys import argv
from msToXw import msToXw
import numpy as np
from math import sqrt

from util import normalize_peakplane
from numpy import iscomplexobj

from eigenworm import readEwMs
from worm_pca import dump_pca

if __name__=="__main__":
	INCOMPLETE
	filename = argv[1]
	prefix = filename
	P = readEwMs(filename)

	Q = []

	if(iscomplexobj(P)):
		eprint("peakplane complex pca")
	for p in P:
		q = normalize_peakplane(p)
		Q.append(q)

	dump_pca(Q)
