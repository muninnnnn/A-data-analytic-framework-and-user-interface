#!/usr/bin/env python
from worm_parse import pvdparse, ptsFromVtu, worm
from matplotlib import pyplot as plt
from matplotlib import gridspec
from mpl_toolkits.mplot3d import Axes3D
import sys
from sys import argv
import os
import warnings
import matplotlib.cbook
warnings.filterwarnings("ignore",category=matplotlib.cbook.mplDeprecation)


def handle_close(evt):
    """Handles the close button clicked event."""
    sys.exit()

if len(argv) < 2:
    print "pvd file not specified"
    sys.exit()

pvdfn=argv[1]

vtuindex=pvdparse(pvdfn)
dir=os.path.dirname(pvdfn)

vtu=iter(vtuindex)
t=next(vtu)

fig = plt.figure(facecolor='white')
fig.canvas.mpl_connect('close_event', handle_close)

gs = gridspec.GridSpec(3, 4)
ax = fig.add_subplot(111, projection='3d')
plt.ion()

i = 0
end = 70

while (i<end):
    try:
        t=next(vtu)
    except StopIteration:
        break
    f = t.get('file')
    myworm = worm(dir+'/'+f)

    X = myworm.pts()

    x=[]
    y=[]
    z=[]
    for j in range(len(X)):
        x.append(X[j][0])
        y.append(X[j][1])
        z.append(X[j][2])

    plt.cla()
    ax.plot(x,y,z, color='g')

    plt.pause(0.05)
    i += 1
