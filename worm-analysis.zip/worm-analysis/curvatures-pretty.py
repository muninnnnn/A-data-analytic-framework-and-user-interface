from matplotlib import pyplot as plt
from matplotlib import _cntr as cntr
import colormaps
plt.close('all')

import numpy as np
import sys
import os

import scipy as sp
import scipy.interpolate
from scipy.ndimage import filters

from matplotlib import rcParams
rcParams['axes.labelsize'] = 21
rcParams['xtick.labelsize'] = 21
rcParams['ytick.labelsize'] = 21
rcParams['legend.fontsize'] = 10

from matplotlib import rcParams
rcParams['font.family'] = 'sans'
rcParams['font.serif'] = ['Computer Modern Roman']
rcParams['text.usetex'] = True

golden_ratio  = (np.sqrt(5) - 1.0) / 2.0  # because it looks good

fig_width_in  = 5.90551
fig_height_in = fig_width_in * golden_ratio   # figure height in inches
fig_dims    = [fig_width_in, fig_height_in] # fig dims as a list


import parameters
parameters = parameters.parserDict( sys.argv )

basename = parameters['pvd_dir'] + '/'
outdir = parameters['output_dir'] + '/'
start_frame = int(parameters['start_frame'])
end_frame = int(parameters['end_frame'])

testContours=False

if not os.path.exists(outdir):
    os.makedirs(outdir)
trial_id = os.path.basename( os.path.normpath( basename ) )

import worm_parse
mainPvd = worm_parse.pvdparse( basename + 'skeletons_worm.pvd')
if start_frame < 0:
    start_frame = 0
if end_frame < 0 or end_frame >= len(mainPvd):
    end_frame = len(mainPvd)
timeStepRange = [ _  for _ in xrange( start_frame, end_frame ) ]
timeSteps = end_frame - start_frame

print 'read pvd file:', basename + 'skeletons_worm.pvd'

def norm( v ):
    s = sum( [_*_ for _ in v] )
    return np.sqrt(s)

# do plotting here
nPts = 128
nTimes = len(mainPvd)
p = np.zeros( (nPts, nTimes) )
pk = np.zeros( (nPts, nTimes, 2) )
wMaxMin = [False,False]

print 'computing curvature'
#for i in range(nTimes):
for i in timeStepRange:
    if i % timeSteps == 0:
        print i,'/',nTimes

    try:
        time = float(mainPvd[i].get('timestep'))
        fn = basename + mainPvd[i].get('file')
        pts,W,U = worm_parse.ptsFromVtu( fn )
    except:
        print i, 'not in range'
        continue

    wMags = []

    for j,w in enumerate(W):
        wMag = np.sqrt( w[0]*w[0] + w[1]*w[1] + w[2]*w[2] )
        p[ j, i ] = wMag
        wMags.append( wMag )
    wMags.sort()

    m = wMags[9*len(wMags)/10]
    if wMaxMin[0]:
        wMaxMin[0] = max( wMaxMin[0], m )
    else:
        wMaxMin[0] = m

nPlts = 1
print 'saving curvature-time heat maps'
if 1:
    fig = plt.figure(1,figsize=fig_dims)
    # 307.28987 pt
    f, axarr = plt.subplots( nPlts )

    if nPlts == 1: axarr = [axarr]

    fullRange = timeSteps
    myExtent = [ start_frame/25.0, end_frame/25.0, 0, 1 ]

    for pp in range(nPlts):
        cax = axarr[pp].imshow( p[:,start_frame:end_frame],
                                interpolation='bilinear',
                                extent=[0,6,0,1], cmap=colormaps.viridis, aspect='auto',
                                vmin=0, vmax=wMaxMin[0] )
        axarr[pp].set_ylabel('Body coordinate')
    axarr[pp].set_xlabel('Time (s)')

    plt.colorbar(cax)

    plt.tight_layout(pad=0.2)
    plt.savefig( os.path.join( outdir , 'curvatures_{}_{}_{}.pdf'.format( trial_id, start_frame, end_frame ) ) )
    plt.savefig( os.path.join( outdir , 'curvatures_{}_{}_{}.png'.format( trial_id, start_frame, end_frame ) ) )
