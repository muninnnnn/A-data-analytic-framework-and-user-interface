#
# Calculates error in msToXw and cMsToXw
# msToXw creates position starting from head
# cMsToXw creates position starting from center
#
# Note: errorH is error using msToXw, errorC is error in cMsToXw
#
# Author: Patrick Fox
#


import numpy as np
from numpy.linalg import norm
from sys import argv
import os
from xwToMs import xwToMs, cXwToMs
from worm_parse import pvdparse, ptsFromVtu
from msToXw import msToXw, cMsToXw
from matplotlib import pyplot as plt
from matplotlib import gridspec
from mpl_toolkits.mplot3d import Axes3D

if __name__=="__main__":

    if(len(argv) < 2):
        print "Usage: python errorMsToXw.py <pvd file>"
        exit()

    pvdfn=argv[1]

    vtuindex=pvdparse(pvdfn)
    dir=os.path.dirname(pvdfn)

    x=iter(vtuindex)
    t=x.next()

    f=t.get('file')

    X,W,ign = ptsFromVtu(dir+'/'+f)

    m1, m2, nu = xwToMs(X, W)
    m11, m22, angle = cXwToMs(X, W)
    nPts = len(m1)
    print "nPts of worm: ", nPts

    tau=X[1]-X[0]
    tau *= float(nPts)

    ctau=X[(nPts/2)]-X[(nPts/2)-1]
    ctau *= float(nPts)

    ctau2 = X[(nPts/2)-2]-X[(nPts/2)-1]
    ctau2 *= float(nPts)

    center = (X[(nPts/2)-1] + X[nPts/2]) / 2

    Xh = msToXw(m1, m2, tau, nu, X[0])[0]
    Xc = cMsToXw(m1, m2, ctau, angle, center)[0]

    fig = plt.figure(facecolor='white')

    gs = gridspec.GridSpec(3, 4)
    ax = fig.add_subplot(111)

    if(len(Xh) != len(Xc)):
        print "msToXw and cMsToXw do not match num of worm points"
        exit()

    position = []
    errorH = []
    errorC = []
    print len(Xh)
    print len(Xc)
    for i in range(len(X)):
        position.append(float(i))
        errorH.append(float(np.linalg.norm(X[i]-Xh[i])))
        errorC.append(float(np.linalg.norm(X[i]-Xc[i])))

    print "Error in msToXw: ", sum(errorH)
    print "Error in cMsToXw: ", sum(errorC)

    ax.plot(position, errorH, color='g')
    ax.plot(position, errorC, color='r')
    # draw vertical line where center of worm is
    ax.plot([64, 64], [min(errorH), max(errorC)])

    fig2 = plt.figure()
    ax2 = fig2.add_subplot(111, projection='3d')
    ax2.set_title('Original worm (cyan)')

    for j in range(61, 64, 1):
        ax2.plot( [X[j][0], X[j+1][0]], \
                      [X[j][1], X[j+1][1]], \
                      [X[j][2], X[j+1][2]], \
                        color = 'c' , linewidth=1)
        ax2.scatter( [X[j][0], X[j+1][0]], \
                          [X[j][1], X[j+1][1]], \
                          [X[j][2], X[j+1][2]], \
                            color = 'c' , linewidth=1)
    for j in range(61,64,1):
        ax2.plot( [Xc[j][0], Xc[j+1][0]], \
                      [Xc[j][1], Xc[j+1][1]], \
                      [Xc[j][2], Xc[j+1][2]], \
                        color = 'g' , linewidth=1)
        ax2.scatter( [Xc[j][0], Xc[j+1][0]], \
                      [Xc[j][1], Xc[j+1][1]], \
                      [Xc[j][2], Xc[j+1][2]], \
                        color = 'g' , linewidth=1)



    plt.show()
