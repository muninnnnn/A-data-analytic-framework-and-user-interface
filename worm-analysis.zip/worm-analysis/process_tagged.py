#!/usr/bin/env python

from __future__ import print_function
import getopt
from sys import argv
import sys
from error import eprint, printn
from frame_tags import frame_tags
from frame_tags import tagindicator
from worm_collect import append_pvdworm
from worm_pca import print_pca
from worm_collect import worm_collect
from numpy import iscomplexobj, dot
from numpy.linalg import norm

def usage():
	print("usage (incomplete)")
	print("-P PCA    use pcaworms from PCA")
	print("-q        print quality")
	print("-r        print rigid quality")
	print("-t        print twist")
	print("-X        print trajectory")
	print("-a        include all data")
	print("-w        intrinsic wave speed")
	print("-Z        print centroid")
	print("-d        centroid displacement")
	print("-m        max curv")
	print("-p        print planarity")
	print("-f        framecomm")

def printn_ri(x):
	if iscomplexobj(x):
		printn(x.real," " ,x.imag)
	else:
		printn(x)


videodir="/nobackup/scsfsa/output-curve/000000"

try:
    # the first few have been done by "parameter"
	opts, args = getopt.getopt(argv[1:], "CXZadmgrqftevpscwP:V:",
	  ["pvddir=", "framesdir=", "outdir=", "tags="])
	# print "opts", opts, "args", args
except getopt.GetoptError as err:
    #incomplete
    # print help information and exit:
    print(str(err))  # will print something like "option -a not recognized"
    usage()
    sys.exit(2)

printpca=False
quality=False
untagged=False
rigid_quality=False
coeffs=False
cplx=False
pcafile=False
planarity=False
framecomm=False
handedness=False
twist=False
i = 1

columns=[]

all_frames = False

for o, a in opts:
	i += 1
	if o == "-v":
		verbose=True
	elif o == "-c":
		eprint("COMPLEX")
		cplx=True
	elif o == "-P":
		i += 1
		pcafile = a
	elif o == "-f":
		framecomm = True
		columns.append("framecomm")
	elif o == "-r":
		rigid_quality = True
		columns.append("rigid_quality")
	elif o == "-V":
		videodir = a
		i += 1
	elif o == "-q":
		quality = True
		columns.append("quality")
	elif o == "-a":
		untagged = True
		all_frames = True
	elif o == "-X":
		columns.append("X")
	elif o == "-w":
		columns.append("wave_speed")
	elif o == "-Z":
		columns.append("centroid")
	elif o == "-d":
		columns.append("cd")
	elif o == "-e":
		planarity = True
		columns.append("planarity")
	elif o == "-g":
		columns.append("gait")
	elif o == "-s":
		columns.append("good_cog")
	elif o == "-p":
		printpca = True
	elif o == "-C":
		coeffs = True
	elif o == "-m":
		columns.append("maxcurv")
	elif o == "-b":
		columns.append("curvmags")
	elif o == "-t":
		columns.append("twist")
	elif o == "-e":
		eprint("planar")
		planarity = True
	else:
		pass


if(quality):
	assert(pcafile)
if(rigid_quality):
	assert(pcafile)

Ms=[]

if len(argv) <= i:
	eprint("need tagfiles\n")

ti=0
#	Ms.append(np.zeros(256))

for fi in argv[i:]:
#	print("# " +fi)
	printn("# framenumber")
	for c in columns:
		if(c=="centroid"):
			printn(" centroidx centroidy centroidz")
		else:
			printn(" ", c)
	print()
	def all_indicator(x):
		return True

	try:
		T = frame_tags(fi)
		I = tagindicator(T)
		if(all_frames):
			I.select_all()
	except FileNotFoundError:
		I = all_indicator

	wormpvd = videodir+"/"+T.videofilename()+"/skeletons_worm.pvd"
	eprint("reading in " + wormpvd)
	# append_pvdworm(Ms, wormpvd, 0, 99999, I)

	WL = worm_collect(wormpvd, 0, 999999, I, all_frames=all_frames)

	a = 0
# BUG: reentrant WL?
# 	for i in WL:
# 		Ms.append(i.Ms())
# 		a+=1
# 	eprint("numberofworms " + str(a) )

	#######
	if(len(Ms)):
		eprint("read in " + str(len(Ms[-1])) + "\n")

	if printpca:
		# eprint(type(WL))
		for i in WL:
			Ms.append(i.Mt(cplx)[0])

	if pcafile:
		eprint("have pcafile " + pcafile + "\n")
		from eigenworm import readEwMs
		pcasys=readEwMs(pcafile)
		pcamean=pcasys[0]
		PCA=pcasys[1]
		eprint("have " + str(len(PCA)) + " eigenworms\n")
		eprint(coeffs)
		if coeffs:
			eprint("dumpcoeffs")
			for i in WL:
				printn( ti, " ", i.get_framenumber())
				printn( " ", i.direction())
				printn( " ", i.gait())
				ti+=1
				coeffs=i.pca_coeffs(pcasys, cplx);
				printn(" 1e99")
				for c in coeffs:
					printn(" ")
					printn_ri(c)
				printn(" ", i.gait() )
				print()

# old mess. see below
	if twist or planarity or framecomm or quality or rigid_quality or len(columns):
		x1 = []
		i1 = None
		n0 = 0
		for i in WL:
			n1 = n0
			n0 = i.get_framenumber()
			if (n0==n1+1):
				# subsequent frames...
				pass
			else:
				print("#====================")
				# new chunk. reset
				x1 = []
				i1 = None

			printn( ti, " ", n0)
			if framecomm:
				printn(" ")
				if i1:
					v1, v2 = i.framecomm(i1)
					printn( " ", dot(v1,v2) )
					printn( " ", norm(v1-v2) )
				else:
					printn("0. 0. 0.")
			if rigid_quality:
				printn(" 1e88")
				for n in range(len(PCA)):
					i.pca_reconstruct([pcamean, PCA[0:n+1]]);
					q = i.rigid_quality([pcamean, PCA[0:n+1]]);
					printn(" ", q)
				i.pca_reconstruct([[],[]]);
				q = i.rigid_quality([[],[]]);
				printn(" ", q)
			if quality:
				printn(" 1e98")
				for n in range(len(PCA)):
					i.pca_reconstruct([pcamean, PCA[0:n+1]]);
					q = i.rigid_quality([pcamean, PCA[0:n+1]]);
					printn(" ", q)
				i.pca_reconstruct([[],[]]);
				q = i.pca_quality([]);
				printn(" ", q)
			for c in columns:
				# if dispatcher[c]?
				if c=="curvmags":
					for j in i.curvmags():
						printn(" ", j)
				elif c=="maxcurv":
					printn(" ", i.max_curvature() )
				elif c=="gait":
					printn(" ", i.gait() )
				elif c=="wave_speed":
					if(i1):
						printn(" ", i.wave_speed(i1) )
					else:
						printn(" 0")
				elif c=="planarity":
					printn(" ", i.planarity() )
				elif c=="centroid":
					x = i.centroid(all_frames)
					printn(" ", x[0], " ", x[1], " ", x[2] )
				elif c=="good_cog":
					try:
						i.centroid()
						x = 1
					except:
						x = 0
					printn(" ", x )
				elif c=="cd":
					x0 = i.center_of_gravity()
					if len(x1):
						n = norm(x1 - x0)
					else:
						n = 0.
					x1 = x0
					printn(" ", n)
				elif c=="X":
					# does not really work
					for j in i.pts():
						printn(" ", j)
				elif c=="twist":
					printn(" ", i.total_twist() )

			print()
			ti+=1
			i1=i

if printpca:
	print_pca(Ms, cplx=cplx)
