#!/usr/bin/env python

from worm_parse import ptsFromVtu
from worm_parse import pvdparse
from sys import argv
import os
import numpy as np
from math import sqrt


import numpy as np
import numpy.random

# Generate some test data
x = np.random.randn(8873)
y = np.random.randn(8873)

heatmap, xedges, yedges = np.histogram2d(x, y, bins=50)
extent = [xedges[0], xedges[-1], yedges[0], yedges[-1]]

def self_dist_min(x, grace=20):
	distance=1000.
	for i in range(len(x)):
		for j in range(i+grace, len(x)):
			dist = np.linalg.norm(x[i]-x[j])


			if dist<distance:
				distance=dist

	return distance

def self_distance(x):
	return self_dist_min(x)

def self_dist(x):
	t=[]
	for i in range(len(x)):
		l=[]
		for j in range(len(x)):
			l.append(np.linalg.norm(x[i]-x[j])) #( + abs(i-j)/128.)
		t.append(l)


	return t

if __name__=="__main__":

	import matplotlib.pyplot as plt

	pvdfn=argv[1]

	vtuindex=pvdparse(pvdfn)
	dir=os.path.dirname(pvdfn)

	x=iter(vtuindex)
	t=x.next()
	f=t.get('file')

	w0=ptsFromVtu(dir+'/'+f)[0]
	i=0
	TV=0.

	T = self_dist(w0)
	#print len(T)
	#print len(T[0])

	Plt.clf()
	plt.imshow(T, extent=[0,128,128,0], origin='lower')
	plt.show()

	for i in range(800):
		x.next()

	while(True):
		try:
			t=x.next()
		except StopIteration:
			break

		f=t.get('file')
		w0=ptsFromVtu(dir+'/'+f)[0]

		T = self_dist(w0)
		plt.clf()
		T[0][127]=1
		T[127][0]=1

		plt.imshow(T, extent=[0,128,128,0], origin='lower')
		plt.show()


		i+=1
		# print i, T


