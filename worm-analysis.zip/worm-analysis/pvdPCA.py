#!/usr/bin/env python

from __future__ import print_function

from estimateK import estimateK
from worm_parse import pvdparse, ptsFromVtu
from sys import argv
import os
import numpy as np
from numpy.linalg import norm
from math import sqrt
from sklearn.decomposition import PCA
from xwToMs import xwToMs, xwToM
from msToXw import msToXw
from pvdSD import self_distance

import sys
from error import eprint

DIMENSION = 10


def printn(*args, **kwargs):
	sys.stdout.write(*args, **kwargs)

from worm_collect import append_pvdworm


if __name__=="__main__":
	pvdfn=argv[1]

	i = 0
	end = 99999
	if(len(argv)>2):
		i = int(argv[2])
	if(len(argv)>3):
		end=int(argv[3])

	Ms=[]

#	Ms.append(np.zeros(256))
	append_pvdworm(Ms, pvdfn, i, end)


	pca = PCA(n_components=DIMENSION)
	pca.fit(Ms)
	print("# PCA from ", len(Ms)) # "precision", pca.get_precision())
	print("# cov from ", pca.get_covariance())

#	print(pca.explained_variance_ratio_)
#	print(pca.components_)

	for c in pca.components_:
#		print("# norm", norm(c))

		space=""
		for i in c:
			printn(space)
			printn(str(i))
			space=" "
		print("")

#	print()
#	print()
#	for c in pca.components_:
#		for d in pca.components_:
#			printn(str(np.dot(c,d))+" ")
#
#		print()
#
			
