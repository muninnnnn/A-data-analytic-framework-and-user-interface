import matplotlib as mpl
# mpl.use('agg')

from matplotlib import pyplot as plt
from matplotlib import gridspec
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from matplotlib.backend_bases import NavigationToolbar2, Event
import matplotlib.image as mpimg
import xml.etree.ElementTree
import sys
import scipy as sp
import scipy.interpolate

import parameters
parameters = parameters.parserDict( sys.argv )

curvePvdDir = parameters['curve_pvd_dir'] + '/'
carvePvdDir =  parameters['carve_pvd_dir'] + '/'
outdir = parameters['output_dir'] + '/'

# Set up axes and plot some awesome science

nCam = 3
camRange = range( 0, nCam )

fig = plt.figure( 1, facecolor='white')

gs = gridspec.GridSpec(3, 4)
ax0 = fig.add_subplot(gs[0:3,0:3], projection='3d')
camAxs = [ fig.add_subplot(gs[c,3]) for c in camRange ]

def setupAxis( cam, ax, i ):
    if cam < 0:
        ax0.set_xlabel( 'mm' )
        ax0.set_ylabel( 'mm' )
        ax0.set_zlabel( 'mm' )
        # ax.view_init(elev=20., azim=70 + i)
        # ax.grid(False)
    else:
        ax.set_xlabel( 'Pixels' )
        ax.set_ylabel( 'Pixels' )
        # ax.set_title( "Camera View {0}".format(cam+1), fontsize=9 )

gs.update(wspace=0.5, hspace=0.5)

carveMainPvd = xml.etree.ElementTree.parse( carvePvdDir + '3d-points.pvd').getroot()[0].findall('DataSet')
carveOtherPvds = [ xml.etree.ElementTree.parse( carvePvdDir + '3d-points_cam{0}-projection.pvd'.format(c)).getroot() for c in camRange ]

curveMainPvd = xml.etree.ElementTree.parse( curvePvdDir + 'skeletons_worm.pvd').getroot()[0].findall('DataSet')
curveOtherPvds = [ xml.etree.ElementTree.parse( curvePvdDir + 'projected_skeletons_cam{0}worm.pvd'.format(c)).getroot() for c in camRange ]

spline_smoothness = 50

def ptsFromVtu( filename ):
    file = open(filename)

    readingPoints = False
    ptsData = []

    for line in file.readlines():
        if '<Points>' in line:
            readingPoints = True
            continue
        if '</Points>' in line:
            readingPoints = False
            continue

        if '</DataArray>' in line:
            readingPoints = False
            continue

        if readingPoints and not 'DataArray' in line:
            for d in line.split():
                ptsData.append( float(d) )

    nPts = len(ptsData)//3

    X = [ np.array(ptsData[3*j:3*(j+1)]) for j in range(nPts) ]
    return X

def curveFromVtu( filename ):
    file = open(filename)

    readingPoints = False
    ptsData = []
    readingW = False
    WData = []
    readingU = False
    UData = []

    for line in file.readlines():
        if '<Points>' in line:
            readingPoints = True
            continue
        if '</Points>' in line:
            readingPoints = False
            continue

        if '<DataArray type="Float32" Name="W" NumberOfComponents="3">' in line:
            readingW = True
            continue

        if '<DataArray type="Float32" Name="u" NumberOfComponents="1">' in line:
            readingU = True
            continue

        if '</DataArray>' in line:
            readingPoints = False
            readingW = False
            readingU = False
            continue

        if readingPoints and not 'DataArray' in line:
            for d in line.split():
                ptsData.append( float(d) )

        if readingW and not 'DataArray' in line:
            for d in line.split():
                WData.append( float(d) )

        if readingU and not 'DataArray' in line:
            for d in line.split():
                UData.append( float(d) )

    nPts = len(ptsData)//3

    X = [ np.array(ptsData[3*j:3*(j+1)]) for j in range(nPts) ]
    W = [ np.array(WData[3*j:3*(j+1)]) for j in range(nPts) ]
    U = UData

    return [ X, W, U ]

# set initial values
minx = 0
maxx = 0
miny = 0
maxy = 0
minz = 0
maxz = 0
xmiddle = 0
ymiddle = 0
xyrange = 0

# mismatches
mismatches = []
missings = [ [] for _ in camRange ]

for i,a in enumerate(zip(carveMainPvd,curveMainPvd)):
    plt.figure(1)

    # get main points
    ax0.cla()
    setupAxis( -1, ax0, i )

    time = carveMainPvd[i].get('timestep')

    print 'frame', i, 'time', time

    fn = carvePvdDir + carveMainPvd[i].get('file')
    pts = ptsFromVtu( fn )

    try:
        x,y,z = zip(*pts)
    except:
        x,y,z = [],[],[]

    ax0.set_title('Time: {0}'.format(time) )
    ax0.plot( x, y, z, 'r.', alpha=0.3 )

    tck, u = sp.interpolate.splprep([x,y,z], s=spline_smoothness)
    u_spline = np.linspace(0,1,128)
    x_spline, y_spline, z_spline = sp.interpolate.splev(u_spline, tck)
    ax0.plot( x_spline, y_spline, z_spline, 'g' )

    time = curveMainPvd[i].get('timestep')
    fn = curvePvdDir + curveMainPvd[i].get('file')
    pts2, W, U = curveFromVtu( fn )

    try:
        x,y,z = zip(*pts2)
    except:
        x,y,z = [],[],[]

    ax0.plot( x, y, z, 'b' )

    mismatch = min( [ max( [ np.sqrt( (xs-xp)**2 + (ys-yp)**2 + (zs-zp)**2 )
                             for xp,yp,zp,xs,ys,zs in zip(x,y,z,x_spline,y_spline,z_spline) ] ),
                      max( [ np.sqrt( (xs-xp)**2 + (ys-yp)**2 + (zs-zp)**2 )
                             for xp,yp,zp,xs,ys,zs in zip(x,y,z,reversed(x_spline),reversed(y_spline),reversed(z_spline)) ] ) ] )
    mismatches.append(mismatch)
    print 'mismatch fitted curve to spline', mismatch

    # update bounding region if possible
    if( len(pts) > 0 ):
        minx = min( [ pt[0] for pt in pts ] )
        maxx = max( [ pt[0] for pt in pts ] )
        miny = min( [ pt[1] for pt in pts ] )
        maxy = max( [ pt[1] for pt in pts ] )
        minz = min( [ pt[2] for pt in pts ] )
        maxz = max( [ pt[2] for pt in pts ] )

    maxRange = max( [ maxx-minx, maxy-miny, maxz-minz] ) / 2.0

    newxRange = [ (minx+maxx)/2.0 - maxRange,  (minx+maxx)/2.0 + maxRange ]
    newyRange = [ (miny+maxy)/2.0 - maxRange,  (miny+maxy)/2.0 + maxRange ]
    newzRange = [ (minz+maxz)/2.0 - maxRange,  (minz+maxz)/2.0 + maxRange ]

    for xb, yb, zb in zip( newxRange, newyRange, newzRange ):
        ax0.plot( [xb], [yb], [zb], 'w' )

    ax0.set_xticks( np.linspace( np.ceil( newxRange[0]/0.25)*0.25,
                                 np.floor( newxRange[1]/0.25)*0.25,
                                 int( np.floor( newxRange[1]/0.25) - np.ceil( newxRange[0]/0.25) )+1,
                                 endpoint=True ) )
    ax0.set_yticks( np.linspace( np.ceil( newyRange[0]/0.25)*0.25,
                                 np.floor( newyRange[1]/0.25)*0.25,
                                 int( np.floor( newyRange[1]/0.25) - np.ceil( newyRange[0]/0.25) )+1,
                                 endpoint=True ) )
    ax0.set_zticks( np.linspace( np.ceil( newzRange[0]/0.25)*0.25,
                                 np.floor( newzRange[1]/0.25)*0.25,
                                 int( np.floor( newzRange[1]/0.25) - np.ceil( newzRange[0]/0.25) )+1,
                                 endpoint=True ) )

    # 2d projections
    allCamNoneMissing = True
    for cam, carvePvds, curvePvds, ax in zip( camRange, carveOtherPvds, curveOtherPvds, camAxs ):
        ax.cla()
        setupAxis( cam, ax, i )

        # read silhouettes
        silhouette = set()
        with open( carvePvdDir + '/3d-points_cam_silhouette{0}_{1}.csv'.format(cam,i)) as file:
            for line in file.readlines():
                d = line.split(',')
                x,y = [int(d[0]),int(d[1])]
                ax.plot( x, y, 'k.', alpha=0.25 )
                silhouette.add( (x,y) )

        pvd = carvePvds[0].findall('DataSet')[i]
        fn =  carvePvdDir + pvd.get('file')
        pts = ptsFromVtu( fn )
        try:
            x,y,z = zip(*pts)
        except:
            continue

        ax.plot( x, y, 'r.', alpha=0.1 )

        pvd = curvePvds[0].findall('DataSet')[i]
        fn =  curvePvdDir + pvd.get('file')
        pts2, W, U = curveFromVtu( fn )
        try:
            x,y,z = zip(*pts2)
            pts = pts + pts2
        except:
            continue

        ax.plot( x, y, 'b')

        missing = []
        for xx, yy in zip(x,y):
            if ( int(xx),int(yy) ) not in silhouette:
                missing.append( (int(xx),int(yy)) )
                allCamNoneMissing = False
        print 'camera', cam, ':', len(missing)
        missings[cam].append(len(missing))

        if len(pts) > 0:
            xmiddle = (max(x)+min(x)) / 2
            ymiddle = (max(y)+min(y)) / 2
            xyrange = max( [ max(x) - min(x), max(y) - min(y) ] ) + 10
            xxrange = [ xmiddle - xyrange, xmiddle + xyrange ]
            yyrange = [ ymiddle - xyrange, ymiddle + xyrange ]

        ax0.set_title('Time: {0}'.format(time) )

#        for xx,yy in zip(x,y):
#            frame[ int(yy), int(xx) ] = [1.0,0.0,0.0]

        if 2*xyrange > 100:
            ax.xaxis.set_ticks( np.arange(0, 2048, 100) )
            ax.yaxis.set_ticks( np.arange(0, 2048, 100) )
        elif 2*xyrange > 50:
            ax.xaxis.set_ticks( np.arange(0, 2048, 50) )
            ax.yaxis.set_ticks( np.arange(0, 2048, 50) )
        else:
            ax.xaxis.set_ticks( np.arange(0, 2048, 25) )
            ax.yaxis.set_ticks( np.arange(0, 2048, 25) )

        ax.axis( xxrange + yyrange )

    plt.draw()

    # fig.tight_layout()
    plt.savefig('{1}/frame_{0:06d}.png'.format(i,outdir) )
    print 'saved', '{1}/frame_{0:06d}.png'.format(i,outdir)

    plt.figure(2)
    if allCamNoneMissing:
        plt.plot( [time], [mismatch], 'ro' )
    else:
        plt.plot( [time], [mismatch], 'bo' )

plt.xlabel('Time (s)')
plt.ylabel('Mismatch')
plt.savefig('{}/time-mismatch.png'.format(outdir))

plt.figure(3)
# the histogram of the mismatches
plt.xlabel('Mismatch')
plt.ylabel('Frequency')
plt.hist( mismatches, int(len(mismatches)), normed=1, facecolor='green', alpha=0.75)
plt.savefig('{}/histogram-mismatch.png'.format(outdir))

file = open('{}/errors.txt'.format(outdir),'w')
file.write('Mismatch,')
for cam in camRange:
    file.write('Missing Cam {},'.format(cam))
file.write('\n')

for mismatch, missing in zip(mismatches,map(list, zip(*missings))):
    file.write('{},'.format(mismatch))
    for m in missing:
        file.write('{},'.format(m))
    file.write('\n')

file.close()
