#!/usr/bin/env python

from estimateK import estimateK
from worm_parse import pvdparse, ptsFromVtu
from sys import argv
import os
from pvdTD import total_displacement
from util import tail
import numpy as np

from scipy import signal
import scipy

## FSCK. cannot import without X??
# import matplotlib.pyplot as plt
DO_PLOT=0

import sys
import cv2
import numpy as np

pvdfn=argv[1]

LAST=-1
FIRST=0

if len(argv)>2:
	FIRST = int(argv[2])
if len(argv)>3:
	LAST = int(argv[3])

vtuindex=pvdparse(pvdfn)
dir=os.path.dirname(pvdfn)
name=os.path.basename(pvdfn)

if __name__=="__main__":
	NW = len(vtuindex)
	# print "have", NW, "worms"

	x=iter(vtuindex)
	t=x.next()

	f=t.get('file')
	w0=ptsFromVtu(dir+'/'+f)[0]

	WS=len(w0)

	# print "wormsamples", WS
	print "#number, td_raw, td_den, result[0][0], result[0][1], result[1][0], result[1][1]"

	
	worm_image = np.zeros((NW,WS,3), np.float64)

	i=0
	while( True ):

		j=0
		for px in w0:
			worm_image[i,j]=px
			j+=1

		try:
			t=x.next()
		except StopIteration:
			break

		f=t.get('file')
		w0=ptsFromVtu(dir+'/'+f)[0]
		i+=1
	
	if DO_PLOT:
		plt.subplot(211)
		#cv2.display(worm_image)j
		plt.imshow(worm_image,'Dark2')
		plt.title('WORM')

		plt.subplot(212)
	#worm_denoised = cv2.fastNlMeansDenoisingColored(worm_image,None,10,10,7,21)
	#worm_denoised = cv2.boxFilter(worm_image, -1, (5,5))
	#worm_denoised = cv2.blur(worm_image, (3,3))
#	worm_denoised = cv2.GaussianBlur(worm_image, (9,5), 1.5, 1.)
#	worm_denoised = cv2.GaussianBlur(worm_image, (5,9), 1., .1)

   # X=midline coordinate
   # Y=time axis
	worm_denoised = cv2.GaussianBlur(worm_image, (9,9), .5, None, .3)
	#worm_denoised = cv2.GaussianBlur(worm_image, (9,5), .5, None, 1)
	# worm_denoised = cv2.medianBlur(worm_image, 5)

	if DO_PLOT:
		plt.imshow(worm_denoised,'Dark2')
		plt.title('DENOISED')
	#	plt.show()

		plt.clf()

#	print worm_image[10][30]

	if 0:
		for wn in range(300, 303):
			w1=[ worm_image[wn,j][1] for j in range(WS) ]
			w2=[ worm_denoised[wn,j][1] for j in range(WS) ]
			plt.plot(range(WS), w2, "x", range(WS), w1, "s")
			plt.show()
			plt.clf()

		for cn in [0,1,2,20]:
			w1=[ worm_image[j,cn][0] for j in range(NW) ]
			w2=[ worm_denoised[j,cn][0] for j in range(NW) ]
			plt.plot(range(NW), w2, "x", range(NW), w1, "s")
			plt.show()
			plt.clf()


	Ks=[]
	if(LAST<0):
		LAST=NW-1

	for i in range(700, NW-1):
		td_raw=total_displacement(worm_image[i], worm_image[i+1])
		res_raw=estimateK(worm_image[i], worm_image[i+1])

		td_den=total_displacement(worm_denoised[i], worm_denoised[i+1])
		res_den=estimateK(worm_denoised[i], worm_denoised[i+1])


		K, KT = res_den[0]
		Kc, KTc = res_den[1]
	
		if(KT < 0):
			# what is happening?
			pass
		elif(Kc > .5):
			Ks.append(K)

		print td_raw, td_den, res_den[0][0], res_den[0][1], res_den[1][0], res_den[1][1]

	# print "numpoints:", len(Ks)
	E=np.mean(Ks)
	V=np.var(Ks)

	# print "exp:", E
	# print "var:", V
	# print "rva:", V/E


	if 0:
		n, bins, patches = plt.hist(Ks, len(Ks), normed=1, facecolor='green', alpha=0.75)
		#plt.plot(bins)
		plt.show()
	
