#!/usr/bin/env python3
from sys import argv
from msToXw import msToXw
import numpy as np
from math import sqrt
from matplotlib import cm


MAX_CURV=.2
EXT=".png"
EXT=".pdf"


def freq(m):
	counter=0;

	oldm=m[0]
	olddm=m[1]-m[0]
	for i in m[1:-2]:
		dm = i - oldm
		if olddm*dm < 0:
			counter+=1

		olddm=dm
		oldm=i
	
	return counter

#colors=['red', 'green'`xx`, '
mycolors = 'rgbmcyk'
def color(index):
#	return mycolors[index%7]
	number = -index/20.
	return (sqrt(number+1.), -number+.5, -number+.5)

from eigenworm import readEwMs

if __name__=="__main__":
	from matplotlib import pyplot as plt
	from matplotlib import gridspec
	from mpl_toolkits.mplot3d import Axes3D
	from numpy.linalg import norm

	from matplotlib import rcParams
	rcParams['axes.labelsize'] = 21
	rcParams['xtick.labelsize'] = 21
	rcParams['ytick.labelsize'] = 21
	rcParams['legend.fontsize'] = 10

	from matplotlib import rcParams
	rcParams['font.family'] = 'sans'
	rcParams['font.serif'] = ['Computer Modern Roman']
	rcParams['text.usetex'] = True


	# golden_ratio  = (np.sqrt(5) - 1.0) / 2.0  # because it looks good

	# fig_width_in  = 5.90551
	# fig_height_in = fig_width_in * golden_ratio   # figure height in inches
	# fig_dims    = [fig_width_in, fig_height_in] # fig dims as a list


	font = {'family' : "Times New Roman",
		        'weight' : 'normal',
				          'size'   : 12}

	import matplotlib
#	matplotlib.rc('font', **font)
#	matplotlib.rc('font',**{'family':'serif','serif':['Times']})


	gs = gridspec.GridSpec(3, 4)
	fig = plt.figure(facecolor='white')
	ax0 = fig.add_subplot(111, projection='3d')
	print(gs[0:3,0:3]) 

	fig_m1m2 = plt.figure(facecolor='white')
#	supt=fig_m1m2.suptitle("TEST")
#	supt.set_text( "TEST" )

	fig_m1 = plt.figure(facecolor='white') # , label="m1")
	fig_m2 = plt.figure(facecolor='white') # , label="m2")
	fig_um = plt.figure(facecolor='white') # , label="magnitude")

	ax_m1m2 = fig_m1m2.add_subplot(gs[0:3,0:3])
	ax_m1m2.set_xlim( -MAX_CURV, MAX_CURV)
	ax_m1m2.set_ylim( -MAX_CURV, MAX_CURV)
	ax_m1m2.set_xlabel("m1 curvature [mm$^{-1}$]")
	ax_m1m2.set_ylabel("m2 curvature [mm$^{-1}$]")

	fig_m1m2u = plt.figure(facecolor='white')
	ax_m1m2u = fig_m1m2u.add_subplot(gs[0:3,0:3], projection='3d')
	ax_m1m2u.set_xlim( -MAX_CURV, MAX_CURV)
	ax_m1m2u.set_ylim( -MAX_CURV, MAX_CURV)
	ax_m1m2u.set_xlabel("m1 curvature [mm$^{-1}$]")
	ax_m1m2u.set_ylabel("m2 curvature [mm$^{-1}$]")
	ax_m1m2u.set_zlabel("length along worm [mm]")
	ax_m1m2u.xaxis.set_ticks([.2,.1,.0,-.1,-.2])
	ax_m1m2u.yaxis.set_ticks([.2,.1,.0,-.1,-.2])

	ax_m1 = fig_m1.add_subplot(gs[0:3,0:3])
	ax_m1.set_ylim( -MAX_CURV, MAX_CURV)
	ax_m1.set_xlabel("length along worm [mm]")
	ax_m1.set_ylabel("m1 curvature [mm$^{-1}$]")

	ax_m2 = fig_m2.add_subplot(gs[0:3,0:3])
	ax_m2.set_ylim( -MAX_CURV, MAX_CURV)
	ax_m2.set_xlabel("length along worm [mm]")
	ax_m2.set_ylabel("m2 curvature [mm$^{-1}$]")

	ax_um = fig_um.add_subplot(gs[0:3,0:3])
#	ax_um.set_xlim( -MAX_CURV*sqrt(2), MAX_CURV*sqrt(2))
	ax_um.set_ylim( -MAX_CURV*sqrt(2), MAX_CURV*sqrt(2))
	ax_um.set_xlabel("length along worm [mm]")
	ax_um.set_ylabel("total curvature [mm$^{-1}$]")

	if(len(argv)<2):
		print("need pcafile")
		sys.exit(1)
	filename = argv[1]
	prefix = filename
	print("plotting from", filename)
	pcasys = readEwMs(filename)
	P=pcasys[1]
	mean=pcasys[0]
	PP=[]

	if not np.iscomplexobj(P):
		for p in P:
			m1 = np.array(p[0:128])
			m2 = np.array(p[128:257])
			PP.append( [ m1, m2 ] )
	else:
		for p in P:
			PP.append( [ p.real, p.imag ] )

	index=len(PP)
	N = 6
	for n,p in enumerate(PP[:N][::-1]):
	# for p in PP[::-1]:
		# print p

		m1 = p[0]
		m2 = p[1]
		colormap=cm.winter
		colorindex=1.- n / (N-1.)
		color=colormap(colorindex)

		print("LEN", len(m1), len(m2))

		assert(len(m2) == len(m1))

		X, W = msToXw(m1, m2)
		k=0

		for j in range(len(X)-1):
			ax0.plot( [X[j][0], X[j+1][0]], \
						  [X[j][1], X[j+1][1]], \
						  [X[j][2], X[j+1][2]], \
							color=color , linewidth=3)
		index-=1

		coord=[ x/127. for x in range(128) ]
		#print len(m1)

		ax_m1m2.plot(m1, m2, color=color)
#		ax_m1m2.set_title("m1m2 plot")

#		ax_m1.set_title("m1 plot")
		ax_m1.plot(coord, m1, color=color)

#		ax_m2.set_title("m2 plot")
		ax_m2.plot(coord, m2, color=color)

		ax_m1m2u.plot(m1, m2, coord, color=color)

		magnitudes = [ sqrt( a**2 + b**2 ) for a, b in zip (m1, m2) ]
		ax_um.plot(coord, magnitudes, color=color)

		print("freq", freq(magnitudes))


	fig_m1m2.savefig(prefix+"m1m2"+EXT)
	fig_m1m2u.savefig(prefix+"m1m2u"+EXT)
	fig_m1.savefig(prefix+"m1"+EXT)
	fig_m2.savefig(prefix+"m2"+EXT)
	fig_um.savefig(prefix+"um"+EXT)

	f = open(prefix+"stats", "w")
	f.write("test")



	#plt.show()

		# for x in X:
		# 	k+=1
		# 	print k, x[0], x[1], x[2]

		# print
		# print
